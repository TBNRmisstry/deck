package me.deck.decksmp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarFlag;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010#\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0010\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0013H\u0007R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\n\u001a\b\u0012\u0004\u0012\u00020\b0\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\r0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\u000f0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0014"},
   d2 = {"Lme/deck/decksmp/DragonEggAbility;", "Lorg/bukkit/event/Listener;", "plugin", "Lorg/bukkit/plugin/java/JavaPlugin;", "<init>", "(Lorg/bukkit/plugin/java/JavaPlugin;)V", "playerCooldowns", "", "Lorg/bukkit/entity/Player;", "", "cooldownNotified", "", "affectedPlayers", "", "bossBars", "Lorg/bukkit/boss/BossBar;", "onDragonEggUse", "", "event", "Lorg/bukkit/event/player/PlayerInteractEvent;", "decksmp"}
)
public final class DragonEggAbility implements Listener {
   @NotNull
   private final JavaPlugin plugin;
   @NotNull
   private final Map<Player, Integer> playerCooldowns;
   @NotNull
   private final Set<Player> cooldownNotified;
   @NotNull
   private final Map<Player, Long> affectedPlayers;
   @NotNull
   private final Map<Player, BossBar> bossBars;

   public DragonEggAbility(@NotNull JavaPlugin plugin) {
      Intrinsics.checkNotNullParameter(plugin, "plugin");
      super();
      this.plugin = plugin;
      this.playerCooldowns = (Map)(new LinkedHashMap());
      this.cooldownNotified = (Set)(new LinkedHashSet());
      this.affectedPlayers = (Map)(new LinkedHashMap());
      this.bossBars = (Map)(new LinkedHashMap());
      this.plugin.getServer().getPluginManager().registerEvents(this, (Plugin)this.plugin);
      (new BukkitRunnable() {
         public void run() {
            List toRemove = (List)(new ArrayList());

            for(Map.Entry var3 : DragonEggAbility.this.playerCooldowns.entrySet()) {
               Player player = (Player)var3.getKey();
               int cd = ((Number)var3.getValue()).intValue();
               if (cd <= 1) {
                  toRemove.add(player);
                  if (!DragonEggAbility.this.cooldownNotified.contains(player)) {
                     player.sendMessage("§dDragon Egg ability is ready!");
                     DragonEggAbility.this.cooldownNotified.add(player);
                  }
               } else {
                  DragonEggAbility.this.playerCooldowns.put(player, cd - 1);
               }
            }

            Iterable var9 = (Iterable)toRemove;
            DragonEggAbility var10 = DragonEggAbility.this;
            int $i$f$forEach = 0;

            for(Object element$iv : var9) {
               Player it = (Player)element$iv;
               int var8 = 0;
               var10.playerCooldowns.remove(it);
               var10.cooldownNotified.remove(it);
            }

         }
      }).runTaskTimer((Plugin)this.plugin, 20L, 20L);
      (new BukkitRunnable() {
         public void run() {
            long now = System.currentTimeMillis();
            Iterator iterator = DragonEggAbility.this.affectedPlayers.entrySet().iterator();

            while(iterator.hasNext()) {
               Map.Entry var4 = (Map.Entry)iterator.next();
               Player player = (Player)var4.getKey();
               long endTime = ((Number)var4.getValue()).longValue();
               if (player.isOnline() && now <= endTime) {
                  player.damage((double)1.0F);
                  player.getWorld().spawnParticle(Particle.DRAGON_BREATH, player.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 10, 0.3, 0.6, 0.3, 0.01);
                  BossBar var14 = (BossBar)DragonEggAbility.this.bossBars.get(player);
                  if (var14 != null) {
                     BossBar bar = var14;
                     int var9 = 0;
                     long millisLeft = endTime - now;
                     double secondsLeft = RangesKt.coerceAtLeast((double)millisLeft / (double)1000.0F, (double)0.0F);
                     bar.setProgress(RangesKt.coerceIn(secondsLeft / (double)6.0F, (double)0.0F, (double)1.0F));
                     bar.setTitle("§cDragon Curse §7(" + (int)secondsLeft + "s left)");
                  }
               } else {
                  iterator.remove();
                  BossBar var10000 = (BossBar)DragonEggAbility.this.bossBars.get(player);
                  if (var10000 != null) {
                     var10000.removeAll();
                  }

                  DragonEggAbility.this.bossBars.remove(player);
               }
            }

         }
      }).runTaskTimer((Plugin)this.plugin, 0L, 1L);
   }

   @EventHandler
   public final void onDragonEggUse(@NotNull PlayerInteractEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      Player var10000 = event.getPlayer();
      Intrinsics.checkNotNullExpressionValue(var10000, "getPlayer(...)");
      final Player player = var10000;
      ItemStack var6 = player.getInventory().getItemInMainHand();
      Intrinsics.checkNotNullExpressionValue(var6, "getItemInMainHand(...)");
      ItemStack item = var6;
      if (item.getType() == Material.DRAGON_EGG) {
         if (StringsKt.contains$default((CharSequence)event.getAction().name(), (CharSequence)"LEFT_CLICK", false, 2, (Object)null)) {
            Integer var7 = (Integer)this.playerCooldowns.get(player);
            int cooldown = var7 != null ? var7 : 0;
            if (cooldown > 0) {
               player.sendMessage("§cDragon Egg ability on cooldown: §e" + cooldown + "§cs left.");
            } else {
               this.playerCooldowns.put(player, 60);
               this.cooldownNotified.remove(player);
               World var8 = player.getWorld();
               Intrinsics.checkNotNullExpressionValue(var8, "getWorld(...)");
               final World world = var8;
               world.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 1.0F, 1.2F);
               (new BukkitRunnable() {
                  private double yOffset = (double)2.0F;
                  private int stage;
                  private double expandRadius = (double)1.0F;

                  public final double getYOffset() {
                     return this.yOffset;
                  }

                  public final void setYOffset(double var1) {
                     this.yOffset = var1;
                  }

                  public final int getStage() {
                     return this.stage;
                  }

                  public final void setStage(int var1) {
                     this.stage = var1;
                  }

                  public final double getExpandRadius() {
                     return this.expandRadius;
                  }

                  public final void setExpandRadius(double var1) {
                     this.expandRadius = var1;
                  }

                  public void run() {
                     if (!player.isOnline()) {
                        this.cancel();
                     } else {
                        Location var10000 = player.getLocation().clone().add((double)0.0F, this.yOffset, (double)0.0F);
                        Intrinsics.checkNotNullExpressionValue(var10000, "add(...)");
                        Location loc = var10000;
                        switch (this.stage) {
                           case 0:
                              for(int i = 0; i < 41; ++i) {
                                 double angle = (Math.PI * 2D) * (double)i / (double)40;
                                 double x = Math.cos(angle);
                                 double z = Math.sin(angle);
                                 world.spawnParticle(Particle.DRAGON_BREATH, loc.clone().add(x, (double)0.0F, z), 1, 0.02, 0.02, 0.02, (double)0.0F);
                              }

                              this.yOffset -= 0.15;
                              if (this.yOffset <= (double)0.5F) {
                                 this.stage = 1;
                                 world.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1.0F, 0.8F);
                              }
                              break;
                           case 1:
                              for(int i = 0; i < 81; ++i) {
                                 double angle = (Math.PI * 2D) * (double)i / (double)80;
                                 double x = Math.cos(angle) * this.expandRadius;
                                 double z = Math.sin(angle) * this.expandRadius;
                                 world.spawnParticle(Particle.DRAGON_BREATH, player.getLocation().clone().add(x, 0.1, z), 2, 0.05, 0.05, 0.05, (double)0.0F);
                              }

                              for(Player nearby : world.getNearbyPlayers(player.getLocation(), this.expandRadius)) {
                                 if (!Intrinsics.areEqual((Object)nearby, (Object)player)) {
                                    Vector var16 = nearby.getLocation().toVector().subtract(player.getLocation().toVector()).normalize();
                                    Intrinsics.checkNotNullExpressionValue(var16, "normalize(...)");
                                    Vector pushDir = var16;
                                    nearby.setVelocity(pushDir.multiply((double)0.5F).setY(0.3));
                                    DragonEggAbility.this.affectedPlayers.put(nearby, System.currentTimeMillis() + (long)6000);
                                    if (!DragonEggAbility.this.bossBars.containsKey(nearby)) {
                                       BossBar var17 = Bukkit.createBossBar("§cDragon Curse §7(6s left)", BarColor.RED, BarStyle.SOLID, new BarFlag[0]);
                                       Intrinsics.checkNotNullExpressionValue(var17, "createBossBar(...)");
                                       BossBar bar = var17;
                                       bar.addPlayer(nearby);
                                       DragonEggAbility.this.bossBars.put(nearby, bar);
                                    }
                                 }
                              }

                              this.expandRadius += 0.3;
                              if (this.expandRadius >= (double)7.0F) {
                                 world.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_SHOOT, 1.0F, 1.0F);
                                 this.cancel();
                              }
                        }

                     }
                  }
               }).runTaskTimer((Plugin)this.plugin, 0L, 1L);
            }
         }
      }
   }
}
