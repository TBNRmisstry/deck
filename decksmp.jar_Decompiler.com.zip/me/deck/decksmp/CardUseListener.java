package me.deck.decksmp;

import java.util.Collection;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0010\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0007R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\n"},
   d2 = {"Lme/deck/decksmp/CardUseListener;", "Lorg/bukkit/event/Listener;", "plugin", "Lme/deck/decksmp/Decksmp;", "<init>", "(Lme/deck/decksmp/Decksmp;)V", "onCardUse", "", "event", "Lorg/bukkit/event/player/PlayerInteractEvent;", "decksmp"}
)
@SourceDebugExtension({"SMAP\nDecksmp.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Decksmp.kt\nme/deck/decksmp/CardUseListener\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n+ 4 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,556:1\n1761#2,3:557\n382#3,7:560\n1772#4,6:567\n*S KotlinDebug\n*F\n+ 1 Decksmp.kt\nme/deck/decksmp/CardUseListener\n*L\n228#1:557,3\n231#1:560,7\n238#1:567,6\n*E\n"})
public final class CardUseListener implements Listener {
   @NotNull
   private final Decksmp plugin;

   public CardUseListener(@NotNull Decksmp plugin) {
      Intrinsics.checkNotNullParameter(plugin, "plugin");
      super();
      this.plugin = plugin;
   }

   @EventHandler
   public final void onCardUse(@NotNull PlayerInteractEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      Player var10000 = event.getPlayer();
      Intrinsics.checkNotNullExpressionValue(var10000, "getPlayer(...)");
      Player player = var10000;
      ItemStack item = event.getItem();
      if (item != null && item.getType() == Material.NETHER_STAR && event.getHand() == EquipmentSlot.HAND) {
         ItemMeta var28 = item.getItemMeta();
         if (var28 != null) {
            ItemMeta meta = var28;
            if (meta.hasDisplayName()) {
               String var29 = meta.getDisplayName();
               Intrinsics.checkNotNullExpressionValue(var29, "getDisplayName(...)");
               String cardName = var29;
               Iterable $this$any$iv = (Iterable)Cards.INSTANCE.allCards().values();
               int $i$f$any = 0;
               boolean var31;
               if ($this$any$iv instanceof Collection && ((Collection)$this$any$iv).isEmpty()) {
                  var31 = false;
               } else {
                  label114: {
                     for(Object element$iv : $this$any$iv) {
                        ItemStack it = (ItemStack)element$iv;
                        int var11 = 0;
                        ItemMeta var30 = it.getItemMeta();
                        if (Intrinsics.areEqual((Object)(var30 != null ? var30.getDisplayName() : null), (Object)cardName)) {
                           var31 = true;
                           break label114;
                        }
                     }

                     var31 = false;
                  }
               }

               if (var31) {
                  String var32 = player.getUniqueId().toString();
                  Intrinsics.checkNotNullExpressionValue(var32, "toString(...)");
                  String uuid = var32;
                  Map slotIndex = CardVariables.INSTANCE.getEquippedCards();
                  int $i$f$getOrPut = 0;
                  Object value$iv = slotIndex.get(uuid);
                  Object var33;
                  if (value$iv == null) {
                     int var12 = 0;
                     Object answer$iv = new String[2];
                     slotIndex.put(uuid, answer$iv);
                     var33 = answer$iv;
                  } else {
                     var33 = value$iv;
                  }

                  String[] slots = (String[])var33;
                  if (ArraysKt.contains(slots, cardName)) {
                     player.sendMessage("§cYou have already equipped " + cardName + "!");
                  } else {
                     Object[] $this$indexOfFirst$iv = slots;
                     $i$f$getOrPut = 0;
                     int index$iv = 0;
                     int var27 = slots.length;

                     while(true) {
                        if (index$iv >= var27) {
                           var34 = -1;
                           break;
                        }

                        String it = (String)$this$indexOfFirst$iv[index$iv];
                        int var14 = 0;
                        if (it == null) {
                           var34 = index$iv;
                           break;
                        }

                        ++index$iv;
                     }

                     int slotIndex = var34;
                     if (slotIndex == -1) {
                        player.sendMessage("§cYou can only equip up to 2 cards!");
                     } else {
                        int amount = item.getAmount();
                        if (amount > 1) {
                           item.setAmount(amount - 1);
                        } else {
                           player.getInventory().remove(item);
                        }

                        slots[slotIndex] = cardName;
                        CardVariables.INSTANCE.getEquippedCards().put(uuid, slots);
                        this.plugin.saveCardVariables();
                        DecksmpKt.access$playCardEquipAnimation(player, this.plugin);
                        player.sendMessage("§aYou have equipped " + cardName);
                        if (var23 != null) {
                           switch (var23) {
                              case "Health Card":
                                 AttributeInstance var35 = player.getAttribute(Attribute.MAX_HEALTH);
                                 if (var35 != null) {
                                    var35.setBaseValue((double)30.0F);
                                 }

                                 if (player.getHealth() > (double)30.0F) {
                                    player.setHealth((double)30.0F);
                                 }
                           }
                        }

                     }
                  }
               }
            }
         }
      }
   }
}
