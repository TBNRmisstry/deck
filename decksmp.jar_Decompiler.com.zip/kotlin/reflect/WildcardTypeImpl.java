package kotlin.reflect;

import java.lang.reflect.Type;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import kotlin.ExperimentalStdlibApi;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0011\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\b\u0003\u0018\u0000 \u00152\u00020\u00012\u00020\u0002:\u0001\u0015B\u001b\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u0013\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00040\tH\u0016¢\u0006\u0002\u0010\nJ\u0013\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00040\tH\u0016¢\u0006\u0002\u0010\nJ\b\u0010\f\u001a\u00020\rH\u0016J\u0013\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0096\u0002J\b\u0010\u0012\u001a\u00020\u0013H\u0016J\b\u0010\u0014\u001a\u00020\rH\u0016R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0016"},
   d2 = {"Lkotlin/reflect/WildcardTypeImpl;", "Ljava/lang/reflect/WildcardType;", "Lkotlin/reflect/TypeImpl;", "upperBound", "Ljava/lang/reflect/Type;", "lowerBound", "<init>", "(Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;)V", "getUpperBounds", "", "()[Ljava/lang/reflect/Type;", "getLowerBounds", "getTypeName", "", "equals", "", "other", "", "hashCode", "", "toString", "Companion", "kotlin-stdlib"}
)
@ExperimentalStdlibApi
final class WildcardTypeImpl implements WildcardType, TypeImpl {
   @NotNull
   public static final Companion Companion = new Companion((DefaultConstructorMarker)null);
   @Nullable
   private final Type upperBound;
   @Nullable
   private final Type lowerBound;
   @NotNull
   private static final WildcardTypeImpl STAR = new WildcardTypeImpl((Type)null, (Type)null);

   public WildcardTypeImpl(@Nullable Type upperBound, @Nullable Type lowerBound) {
      this.upperBound = upperBound;
      this.lowerBound = lowerBound;
   }

   @NotNull
   public Type[] getUpperBounds() {
      Type[] var1 = new Type[1];
      Type var10002 = this.upperBound;
      if (var10002 == null) {
         var10002 = (Type)Object.class;
      }

      var1[0] = var10002;
      return var1;
   }

   @NotNull
   public Type[] getLowerBounds() {
      Type[] var10000;
      if (this.lowerBound == null) {
         var10000 = new Type[0];
      } else {
         Type[] var1 = new Type[]{this.lowerBound};
         var10000 = var1;
      }

      return var10000;
   }

   @NotNull
   public String getTypeName() {
      return this.lowerBound != null ? "? super " + TypesJVMKt.access$typeToString(this.lowerBound) : (this.upperBound != null && !Intrinsics.areEqual((Object)this.upperBound, (Object)Object.class) ? "? extends " + TypesJVMKt.access$typeToString(this.upperBound) : "?");
   }

   public boolean equals(@Nullable Object other) {
      return other instanceof WildcardType && Arrays.equals(this.getUpperBounds(), ((WildcardType)other).getUpperBounds()) && Arrays.equals(this.getLowerBounds(), ((WildcardType)other).getLowerBounds());
   }

   public int hashCode() {
      return Arrays.hashCode(this.getUpperBounds()) ^ Arrays.hashCode(this.getLowerBounds());
   }

   @NotNull
   public String toString() {
      return this.getTypeName();
   }

   @Metadata(
      mv = {2, 2, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"},
      d2 = {"Lkotlin/reflect/WildcardTypeImpl$Companion;", "", "<init>", "()V", "STAR", "Lkotlin/reflect/WildcardTypeImpl;", "getSTAR", "()Lkotlin/reflect/WildcardTypeImpl;", "kotlin-stdlib"}
   )
   public static final class Companion {
      private Companion() {
      }

      @NotNull
      public final WildcardTypeImpl getSTAR() {
         return WildcardTypeImpl.STAR;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
