package kotlin;

import kotlin.internal.InlineOnly;
import kotlin.jvm.JvmName;

@Metadata(
   mv = {2, 2, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000&\n\u0000\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u000b\u001a\u0014\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u0087\b¢\u0006\u0004\b\u0003\u0010\u0004\u001a\u0014\u0010\u0005\u001a\u00020\u0001*\u00020\u0002H\u0087\b¢\u0006\u0004\b\u0006\u0010\u0004\u001a\u0014\u0010\u0007\u001a\u00020\u0001*\u00020\u0002H\u0087\b¢\u0006\u0004\b\b\u0010\u0004\u001a\u0014\u0010\t\u001a\u00020\u0002*\u00020\u0002H\u0087\b¢\u0006\u0004\b\n\u0010\u0004\u001a\u0014\u0010\u000b\u001a\u00020\u0002*\u00020\u0002H\u0087\b¢\u0006\u0004\b\f\u0010\u0004\u001a\u001c\u0010\r\u001a\u00020\u0002*\u00020\u00022\u0006\u0010\u000e\u001a\u00020\u0001H\u0087\b¢\u0006\u0004\b\u000f\u0010\u0010\u001a\u001c\u0010\u0011\u001a\u00020\u0002*\u00020\u00022\u0006\u0010\u000e\u001a\u00020\u0001H\u0087\b¢\u0006\u0004\b\u0012\u0010\u0010\u001a\u0014\u0010\u0000\u001a\u00020\u0001*\u00020\u0013H\u0087\b¢\u0006\u0004\b\u0014\u0010\u0015\u001a\u0014\u0010\u0005\u001a\u00020\u0001*\u00020\u0013H\u0087\b¢\u0006\u0004\b\u0016\u0010\u0015\u001a\u0014\u0010\u0007\u001a\u00020\u0001*\u00020\u0013H\u0087\b¢\u0006\u0004\b\u0017\u0010\u0015\u001a\u0014\u0010\t\u001a\u00020\u0013*\u00020\u0013H\u0087\b¢\u0006\u0004\b\u0018\u0010\u0019\u001a\u0014\u0010\u000b\u001a\u00020\u0013*\u00020\u0013H\u0087\b¢\u0006\u0004\b\u001a\u0010\u0019\u001a\u001c\u0010\r\u001a\u00020\u0013*\u00020\u00132\u0006\u0010\u000e\u001a\u00020\u0001H\u0087\b¢\u0006\u0004\b\u001b\u0010\u001c\u001a\u001c\u0010\u0011\u001a\u00020\u0013*\u00020\u00132\u0006\u0010\u000e\u001a\u00020\u0001H\u0087\b¢\u0006\u0004\b\u001d\u0010\u001c\u001a\u0014\u0010\u0000\u001a\u00020\u0001*\u00020\u001eH\u0087\b¢\u0006\u0004\b\u001f\u0010 \u001a\u0014\u0010\u0005\u001a\u00020\u0001*\u00020\u001eH\u0087\b¢\u0006\u0004\b!\u0010 \u001a\u0014\u0010\u0007\u001a\u00020\u0001*\u00020\u001eH\u0087\b¢\u0006\u0004\b\"\u0010 \u001a\u0014\u0010\t\u001a\u00020\u001e*\u00020\u001eH\u0087\b¢\u0006\u0004\b#\u0010$\u001a\u0014\u0010\u000b\u001a\u00020\u001e*\u00020\u001eH\u0087\b¢\u0006\u0004\b%\u0010$\u001a\u001c\u0010\r\u001a\u00020\u001e*\u00020\u001e2\u0006\u0010\u000e\u001a\u00020\u0001H\u0087\b¢\u0006\u0004\b&\u0010'\u001a\u001c\u0010\u0011\u001a\u00020\u001e*\u00020\u001e2\u0006\u0010\u000e\u001a\u00020\u0001H\u0087\b¢\u0006\u0004\b(\u0010'\u001a\u0014\u0010\u0000\u001a\u00020\u0001*\u00020)H\u0087\b¢\u0006\u0004\b*\u0010+\u001a\u0014\u0010\u0005\u001a\u00020\u0001*\u00020)H\u0087\b¢\u0006\u0004\b,\u0010+\u001a\u0014\u0010\u0007\u001a\u00020\u0001*\u00020)H\u0087\b¢\u0006\u0004\b-\u0010+\u001a\u0014\u0010\t\u001a\u00020)*\u00020)H\u0087\b¢\u0006\u0004\b.\u0010/\u001a\u0014\u0010\u000b\u001a\u00020)*\u00020)H\u0087\b¢\u0006\u0004\b0\u0010/\u001a\u001c\u0010\r\u001a\u00020)*\u00020)2\u0006\u0010\u000e\u001a\u00020\u0001H\u0087\b¢\u0006\u0004\b1\u00102\u001a\u001c\u0010\u0011\u001a\u00020)*\u00020)2\u0006\u0010\u000e\u001a\u00020\u0001H\u0087\b¢\u0006\u0004\b3\u00102¨\u00064"},
   d2 = {"countOneBits", "", "Lkotlin/UInt;", "countOneBits-WZ4Q5Ns", "(I)I", "countLeadingZeroBits", "countLeadingZeroBits-WZ4Q5Ns", "countTrailingZeroBits", "countTrailingZeroBits-WZ4Q5Ns", "takeHighestOneBit", "takeHighestOneBit-WZ4Q5Ns", "takeLowestOneBit", "takeLowestOneBit-WZ4Q5Ns", "rotateLeft", "bitCount", "rotateLeft-V7xB4Y4", "(II)I", "rotateRight", "rotateRight-V7xB4Y4", "Lkotlin/ULong;", "countOneBits-VKZWuLQ", "(J)I", "countLeadingZeroBits-VKZWuLQ", "countTrailingZeroBits-VKZWuLQ", "takeHighestOneBit-VKZWuLQ", "(J)J", "takeLowestOneBit-VKZWuLQ", "rotateLeft-JSWoG40", "(JI)J", "rotateRight-JSWoG40", "Lkotlin/UByte;", "countOneBits-7apg3OU", "(B)I", "countLeadingZeroBits-7apg3OU", "countTrailingZeroBits-7apg3OU", "takeHighestOneBit-7apg3OU", "(B)B", "takeLowestOneBit-7apg3OU", "rotateLeft-LxnNnR4", "(BI)B", "rotateRight-LxnNnR4", "Lkotlin/UShort;", "countOneBits-xj2QHRw", "(S)I", "countLeadingZeroBits-xj2QHRw", "countTrailingZeroBits-xj2QHRw", "takeHighestOneBit-xj2QHRw", "(S)S", "takeLowestOneBit-xj2QHRw", "rotateLeft-olVBNx4", "(SI)S", "rotateRight-olVBNx4", "kotlin-stdlib"}
)
@JvmName(
   name = "UNumbersKt"
)
public final class UNumbersKt {
   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final int countOneBits_WZ4Q5Ns/* $FF was: countOneBits-WZ4Q5Ns*/(int var0) {
      return Integer.bitCount(var0);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final int countLeadingZeroBits_WZ4Q5Ns/* $FF was: countLeadingZeroBits-WZ4Q5Ns*/(int var0) {
      return Integer.numberOfLeadingZeros(var0);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final int countTrailingZeroBits_WZ4Q5Ns/* $FF was: countTrailingZeroBits-WZ4Q5Ns*/(int var0) {
      return Integer.numberOfTrailingZeros(var0);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final int takeHighestOneBit_WZ4Q5Ns/* $FF was: takeHighestOneBit-WZ4Q5Ns*/(int var0) {
      return UInt.constructor-impl(Integer.highestOneBit(var0));
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final int takeLowestOneBit_WZ4Q5Ns/* $FF was: takeLowestOneBit-WZ4Q5Ns*/(int var0) {
      return UInt.constructor-impl(Integer.lowestOneBit(var0));
   }

   @SinceKotlin(
      version = "1.6"
   )
   @InlineOnly
   private static final int rotateLeft_V7xB4Y4/* $FF was: rotateLeft-V7xB4Y4*/(int var0, int bitCount) {
      return UInt.constructor-impl(Integer.rotateLeft(var0, bitCount));
   }

   @SinceKotlin(
      version = "1.6"
   )
   @InlineOnly
   private static final int rotateRight_V7xB4Y4/* $FF was: rotateRight-V7xB4Y4*/(int var0, int bitCount) {
      return UInt.constructor-impl(Integer.rotateRight(var0, bitCount));
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final int countOneBits_VKZWuLQ/* $FF was: countOneBits-VKZWuLQ*/(long var0) {
      return Long.bitCount(var0);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final int countLeadingZeroBits_VKZWuLQ/* $FF was: countLeadingZeroBits-VKZWuLQ*/(long var0) {
      return Long.numberOfLeadingZeros(var0);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final int countTrailingZeroBits_VKZWuLQ/* $FF was: countTrailingZeroBits-VKZWuLQ*/(long var0) {
      return Long.numberOfTrailingZeros(var0);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final long takeHighestOneBit_VKZWuLQ/* $FF was: takeHighestOneBit-VKZWuLQ*/(long var0) {
      return ULong.constructor-impl(Long.highestOneBit(var0));
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final long takeLowestOneBit_VKZWuLQ/* $FF was: takeLowestOneBit-VKZWuLQ*/(long var0) {
      return ULong.constructor-impl(Long.lowestOneBit(var0));
   }

   @SinceKotlin(
      version = "1.6"
   )
   @InlineOnly
   private static final long rotateLeft_JSWoG40/* $FF was: rotateLeft-JSWoG40*/(long var0, int bitCount) {
      return ULong.constructor-impl(Long.rotateLeft(var0, bitCount));
   }

   @SinceKotlin(
      version = "1.6"
   )
   @InlineOnly
   private static final long rotateRight_JSWoG40/* $FF was: rotateRight-JSWoG40*/(long var0, int bitCount) {
      return ULong.constructor-impl(Long.rotateRight(var0, bitCount));
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final int countOneBits_7apg3OU/* $FF was: countOneBits-7apg3OU*/(byte var0) {
      return Integer.bitCount(UInt.constructor-impl(var0 & 255));
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final int countLeadingZeroBits_7apg3OU/* $FF was: countLeadingZeroBits-7apg3OU*/(byte var0) {
      return Integer.numberOfLeadingZeros(var0 & 255) - 24;
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final int countTrailingZeroBits_7apg3OU/* $FF was: countTrailingZeroBits-7apg3OU*/(byte var0) {
      return Integer.numberOfTrailingZeros(var0 | 256);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final byte takeHighestOneBit_7apg3OU/* $FF was: takeHighestOneBit-7apg3OU*/(byte var0) {
      return UByte.constructor-impl((byte)Integer.highestOneBit(var0 & 255));
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final byte takeLowestOneBit_7apg3OU/* $FF was: takeLowestOneBit-7apg3OU*/(byte var0) {
      return UByte.constructor-impl((byte)Integer.lowestOneBit(var0 & 255));
   }

   @SinceKotlin(
      version = "1.6"
   )
   @InlineOnly
   private static final byte rotateLeft_LxnNnR4/* $FF was: rotateLeft-LxnNnR4*/(byte var0, int bitCount) {
      return UByte.constructor-impl(NumbersKt.rotateLeft(var0, bitCount));
   }

   @SinceKotlin(
      version = "1.6"
   )
   @InlineOnly
   private static final byte rotateRight_LxnNnR4/* $FF was: rotateRight-LxnNnR4*/(byte var0, int bitCount) {
      return UByte.constructor-impl(NumbersKt.rotateRight(var0, bitCount));
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final int countOneBits_xj2QHRw/* $FF was: countOneBits-xj2QHRw*/(short var0) {
      return Integer.bitCount(UInt.constructor-impl(var0 & '\uffff'));
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final int countLeadingZeroBits_xj2QHRw/* $FF was: countLeadingZeroBits-xj2QHRw*/(short var0) {
      return Integer.numberOfLeadingZeros(var0 & '\uffff') - 16;
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final int countTrailingZeroBits_xj2QHRw/* $FF was: countTrailingZeroBits-xj2QHRw*/(short var0) {
      return Integer.numberOfTrailingZeros(var0 | 65536);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final short takeHighestOneBit_xj2QHRw/* $FF was: takeHighestOneBit-xj2QHRw*/(short var0) {
      return UShort.constructor-impl((short)Integer.highestOneBit(var0 & '\uffff'));
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final short takeLowestOneBit_xj2QHRw/* $FF was: takeLowestOneBit-xj2QHRw*/(short var0) {
      return UShort.constructor-impl((short)Integer.lowestOneBit(var0 & '\uffff'));
   }

   @SinceKotlin(
      version = "1.6"
   )
   @InlineOnly
   private static final short rotateLeft_olVBNx4/* $FF was: rotateLeft-olVBNx4*/(short var0, int bitCount) {
      return UShort.constructor-impl(NumbersKt.rotateLeft(var0, bitCount));
   }

   @SinceKotlin(
      version = "1.6"
   )
   @InlineOnly
   private static final short rotateRight_olVBNx4/* $FF was: rotateRight-olVBNx4*/(short var0, int bitCount) {
      return UShort.constructor-impl(NumbersKt.rotateRight(var0, bitCount));
   }
}
