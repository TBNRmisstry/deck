package kotlin.internal;

import java.lang.reflect.Method;
import java.util.List;
import java.util.regex.MatchResult;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmField;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.random.FallbackThreadLocalRandom;
import kotlin.random.Random;
import kotlin.text.MatchGroup;
import kotlin.time.Clock;
import kotlin.time.ExperimentalTime;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0003\n\u0002\b\u0002\n\u0002\u0010 \n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0010\u0018\u00002\u00020\u0001:\u0001\u0015B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0018\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0007H\u0016J\u0016\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00070\n2\u0006\u0010\b\u001a\u00020\u0007H\u0016J\u001a\u0010\u000b\u001a\u0004\u0018\u00010\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016J\b\u0010\u0011\u001a\u00020\u0012H\u0016J\b\u0010\u0013\u001a\u00020\u0014H\u0017¨\u0006\u0016"},
   d2 = {"Lkotlin/internal/PlatformImplementations;", "", "<init>", "()V", "addSuppressed", "", "cause", "", "exception", "getSuppressed", "", "getMatchResultNamedGroup", "Lkotlin/text/MatchGroup;", "matchResult", "Ljava/util/regex/MatchResult;", "name", "", "defaultPlatformRandom", "Lkotlin/random/Random;", "getSystemClock", "Lkotlin/time/Clock;", "ReflectThrowable", "kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nPlatformImplementations.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PlatformImplementations.kt\nkotlin/internal/PlatformImplementations\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,86:1\n1#2:87\n*E\n"})
public class PlatformImplementations {
   public void addSuppressed(@NotNull Throwable cause, @NotNull Throwable exception) {
      Intrinsics.checkNotNullParameter(cause, "cause");
      Intrinsics.checkNotNullParameter(exception, "exception");
      Method var10000 = PlatformImplementations.ReflectThrowable.addSuppressed;
      if (var10000 != null) {
         Object[] var3 = new Object[]{exception};
         var10000.invoke(cause, var3);
      }

   }

   @NotNull
   public List<Throwable> getSuppressed(@NotNull Throwable exception) {
      Intrinsics.checkNotNullParameter(exception, "exception");
      Method var10000 = PlatformImplementations.ReflectThrowable.getSuppressed;
      List var5;
      if (var10000 != null) {
         Object var4 = var10000.invoke(exception);
         if (var4 != null) {
            Object it = var4;
            int var3 = 0;
            var5 = ArraysKt.asList((Throwable[])it);
            if (var5 != null) {
               return var5;
            }
         }
      }

      var5 = CollectionsKt.emptyList();
      return var5;
   }

   @Nullable
   public MatchGroup getMatchResultNamedGroup(@NotNull MatchResult matchResult, @NotNull String name) {
      Intrinsics.checkNotNullParameter(matchResult, "matchResult");
      Intrinsics.checkNotNullParameter(name, "name");
      throw new UnsupportedOperationException("Retrieving groups by name is not supported on this platform.");
   }

   @NotNull
   public Random defaultPlatformRandom() {
      return new FallbackThreadLocalRandom();
   }

   @ExperimentalTime
   @NotNull
   public Clock getSystemClock() {
      throw new UnsupportedOperationException("getSystemClock should not be called on the base PlatformImplementations.");
   }

   @Metadata(
      mv = {2, 2, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\bÂ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0012\u0010\u0004\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\u0006\u001a\u0004\u0018\u00010\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006\u0007"},
      d2 = {"Lkotlin/internal/PlatformImplementations$ReflectThrowable;", "", "<init>", "()V", "addSuppressed", "Ljava/lang/reflect/Method;", "getSuppressed", "kotlin-stdlib"}
   )
   @SourceDebugExtension({"SMAP\nPlatformImplementations.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PlatformImplementations.kt\nkotlin/internal/PlatformImplementations$ReflectThrowable\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,86:1\n1#2:87\n*E\n"})
   private static final class ReflectThrowable {
      @NotNull
      public static final ReflectThrowable INSTANCE = new ReflectThrowable();
      @JvmField
      @Nullable
      public static final Method addSuppressed;
      @JvmField
      @Nullable
      public static final Method getSuppressed;

      static {
         Class throwableClass = Throwable.class;
         Method[] throwableMethods = throwableClass.getMethods();
         Intrinsics.checkNotNull(throwableMethods);
         Method[] var2 = throwableMethods;
         int var3 = 0;
         int var4 = throwableMethods.length;

         Method var14;
         while(true) {
            if (var3 >= var4) {
               var14 = null;
               break;
            }

            Method it;
            label36: {
               it = var2[var3];
               int var7 = 0;
               if (Intrinsics.areEqual((Object)it.getName(), (Object)"addSuppressed")) {
                  Class[] var10000 = it.getParameterTypes();
                  Intrinsics.checkNotNullExpressionValue(var10000, "getParameterTypes(...)");
                  if (Intrinsics.areEqual((Object)ArraysKt.singleOrNull(var10000), (Object)throwableClass)) {
                     var13 = true;
                     break label36;
                  }
               }

               var13 = false;
            }

            if (var13) {
               var14 = it;
               break;
            }

            ++var3;
         }

         addSuppressed = var14;
         var2 = throwableMethods;
         var3 = 0;
         var4 = throwableMethods.length;

         while(true) {
            if (var3 >= var4) {
               var14 = null;
               break;
            }

            Method it = var2[var3];
            int var12 = 0;
            if (Intrinsics.areEqual((Object)it.getName(), (Object)"getSuppressed")) {
               var14 = it;
               break;
            }

            ++var3;
         }

         getSuppressed = var14;
      }
   }
}
