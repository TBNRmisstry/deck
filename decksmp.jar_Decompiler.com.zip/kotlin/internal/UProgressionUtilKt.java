package kotlin.internal;

import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.SinceKotlin;
import kotlin.UInt;
import kotlin.ULong;

@Metadata(
   mv = {2, 2, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000 \n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\u001a'\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u0001H\u0002¢\u0006\u0004\b\u0005\u0010\u0006\u001a'\u0010\u0000\u001a\u00020\u00072\u0006\u0010\u0002\u001a\u00020\u00072\u0006\u0010\u0003\u001a\u00020\u00072\u0006\u0010\u0004\u001a\u00020\u0007H\u0002¢\u0006\u0004\b\b\u0010\t\u001a'\u0010\n\u001a\u00020\u00012\u0006\u0010\u000b\u001a\u00020\u00012\u0006\u0010\f\u001a\u00020\u00012\u0006\u0010\r\u001a\u00020\u000eH\u0001¢\u0006\u0004\b\u000f\u0010\u0006\u001a'\u0010\n\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\u00072\u0006\u0010\f\u001a\u00020\u00072\u0006\u0010\r\u001a\u00020\u0010H\u0001¢\u0006\u0004\b\u0011\u0010\t¨\u0006\u0012"},
   d2 = {"differenceModulo", "Lkotlin/UInt;", "a", "b", "c", "differenceModulo-WZ9TVnA", "(III)I", "Lkotlin/ULong;", "differenceModulo-sambcqE", "(JJJ)J", "getProgressionLastElement", "start", "end", "step", "", "getProgressionLastElement-Nkh28Cs", "", "getProgressionLastElement-7ftBX0g", "kotlin-stdlib"}
)
public final class UProgressionUtilKt {
   private static final int differenceModulo_WZ9TVnA/* $FF was: differenceModulo-WZ9TVnA*/(int var0, int var1, int var2) {
      int ac = Integer.remainderUnsigned(var0, var2);
      int bc = Integer.remainderUnsigned(var1, var2);
      return Integer.compareUnsigned(ac, bc) >= 0 ? UInt.constructor-impl(ac - bc) : UInt.constructor-impl(UInt.constructor-impl(ac - bc) + var2);
   }

   private static final long differenceModulo_sambcqE/* $FF was: differenceModulo-sambcqE*/(long var0, long var2, long var4) {
      long ac = Long.remainderUnsigned(var0, var4);
      long bc = Long.remainderUnsigned(var2, var4);
      return Long.compareUnsigned(ac, bc) >= 0 ? ULong.constructor-impl(ac - bc) : ULong.constructor-impl(ULong.constructor-impl(ac - bc) + var4);
   }

   @PublishedApi
   @SinceKotlin(
      version = "1.3"
   )
   public static final int getProgressionLastElement_Nkh28Cs/* $FF was: getProgressionLastElement-Nkh28Cs*/(int var0, int var1, int step) {
      int var10000;
      if (step > 0) {
         var10000 = Integer.compareUnsigned(var0, var1) >= 0 ? var1 : UInt.constructor-impl(var1 - differenceModulo-WZ9TVnA(var1, var0, UInt.constructor-impl(step)));
      } else {
         if (step >= 0) {
            throw new IllegalArgumentException("Step is zero.");
         }

         var10000 = Integer.compareUnsigned(var0, var1) <= 0 ? var1 : UInt.constructor-impl(var1 + differenceModulo-WZ9TVnA(var0, var1, UInt.constructor-impl(-step)));
      }

      return var10000;
   }

   @PublishedApi
   @SinceKotlin(
      version = "1.3"
   )
   public static final long getProgressionLastElement_7ftBX0g/* $FF was: getProgressionLastElement-7ftBX0g*/(long var0, long var2, long step) {
      long var10000;
      if (step > 0L) {
         var10000 = Long.compareUnsigned(var0, var2) >= 0 ? var2 : ULong.constructor-impl(var2 - differenceModulo-sambcqE(var2, var0, ULong.constructor-impl(step)));
      } else {
         if (step >= 0L) {
            throw new IllegalArgumentException("Step is zero.");
         }

         var10000 = Long.compareUnsigned(var0, var2) <= 0 ? var2 : ULong.constructor-impl(var2 + differenceModulo-sambcqE(var0, var2, ULong.constructor-impl(-step)));
      }

      return var10000;
   }
}
