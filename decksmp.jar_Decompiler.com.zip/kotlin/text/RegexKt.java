package kotlin.text;

import java.util.Collections;
import java.util.EnumSet;
import java.util.Set;
import java.util.regex.Matcher;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.IntRange;
import kotlin.ranges.RangesKt;

@Metadata(
   mv = {2, 2, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000>\n\u0000\n\u0002\u0010\b\n\u0002\u0010\u001c\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\"\n\u0000\n\u0002\u0010\u0010\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\r\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u0012\u0010\u0000\u001a\u00020\u0001*\b\u0012\u0004\u0012\u00020\u00030\u0002H\u0002\u001a-\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\u00060\u0005\"\u0014\b\u0000\u0010\u0006\u0018\u0001*\u00020\u0003*\b\u0012\u0004\u0012\u0002H\u00060\u00072\u0006\u0010\b\u001a\u00020\u0001H\u0082\b\u001a\u001e\u0010\t\u001a\u0004\u0018\u00010\n*\u00020\u000b2\u0006\u0010\f\u001a\u00020\u00012\u0006\u0010\r\u001a\u00020\u000eH\u0002\u001a\u0016\u0010\u000f\u001a\u0004\u0018\u00010\n*\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000eH\u0002\u001a\f\u0010\u0010\u001a\u00020\u0011*\u00020\u0012H\u0002\u001a\u0014\u0010\u0010\u001a\u00020\u0011*\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0001H\u0002¨\u0006\u0014"},
   d2 = {"toInt", "", "", "Lkotlin/text/FlagEnum;", "fromInt", "", "T", "", "value", "findNext", "Lkotlin/text/MatchResult;", "Ljava/util/regex/Matcher;", "from", "input", "", "matchEntire", "range", "Lkotlin/ranges/IntRange;", "Ljava/util/regex/MatchResult;", "groupIndex", "kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nRegex.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Regex.kt\nkotlin/text/RegexKt\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,404:1\n1803#2,3:405\n*S KotlinDebug\n*F\n+ 1 Regex.kt\nkotlin/text/RegexKt\n*L\n21#1:405,3\n*E\n"})
public final class RegexKt {
   private static final int toInt(Iterable<? extends FlagEnum> $this$toInt) {
      int initial$iv = 0;
      int $i$f$fold = 0;
      int accumulator$iv = initial$iv;

      for(Object element$iv : $this$toInt) {
         FlagEnum option = (FlagEnum)element$iv;
         int var9 = 0;
         accumulator$iv |= option.getValue();
      }

      return accumulator$iv;
   }

   // $FF: synthetic method
   private static final <T extends Enum<T> & FlagEnum> Set<T> fromInt(final int value) {
      int $i$f$fromInt = 0;
      Intrinsics.reifiedOperationMarker(4, "T");
      EnumSet var2 = EnumSet.allOf(Enum.class);
      EnumSet $this$fromInt_u24lambda_u240 = var2;
      int var4 = 0;
      Intrinsics.checkNotNull($this$fromInt_u24lambda_u240);
      Iterable var10000 = (Iterable)$this$fromInt_u24lambda_u240;
      Intrinsics.needClassReification();
      CollectionsKt.retainAll(var10000, new Function1<T, Boolean>() {
         public final Boolean invoke(T it) {
            return (value & ((FlagEnum)it).getMask()) == ((FlagEnum)it).getValue();
         }
      });
      Set var5 = Collections.unmodifiableSet((Set)var2);
      Intrinsics.checkNotNullExpressionValue(var5, "unmodifiableSet(...)");
      return var5;
   }

   private static final MatchResult findNext(Matcher $this$findNext, int from, CharSequence input) {
      return !$this$findNext.find(from) ? null : (MatchResult)(new MatcherMatchResult($this$findNext, input));
   }

   private static final MatchResult matchEntire(Matcher $this$matchEntire, CharSequence input) {
      return !$this$matchEntire.matches() ? null : (MatchResult)(new MatcherMatchResult($this$matchEntire, input));
   }

   private static final IntRange range(java.util.regex.MatchResult $this$range) {
      return RangesKt.until($this$range.start(), $this$range.end());
   }

   private static final IntRange range(java.util.regex.MatchResult $this$range, int groupIndex) {
      return RangesKt.until($this$range.start(groupIndex), $this$range.end(groupIndex));
   }

   // $FF: synthetic method
   public static final int access$toInt(Iterable $receiver) {
      return toInt($receiver);
   }

   // $FF: synthetic method
   public static final MatchResult access$findNext(Matcher $receiver, int from, CharSequence input) {
      return findNext($receiver, from, input);
   }

   // $FF: synthetic method
   public static final MatchResult access$matchEntire(Matcher $receiver, CharSequence input) {
      return matchEntire($receiver, input);
   }

   // $FF: synthetic method
   public static final IntRange access$range(java.util.regex.MatchResult $receiver) {
      return range($receiver);
   }

   // $FF: synthetic method
   public static final IntRange access$range(java.util.regex.MatchResult $receiver, int groupIndex) {
      return range($receiver, groupIndex);
   }
}
