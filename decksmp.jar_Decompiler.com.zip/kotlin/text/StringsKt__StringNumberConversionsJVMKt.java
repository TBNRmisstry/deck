package kotlin.text;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.internal.InlineOnly;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 2, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000V\n\u0000\n\u0002\u0010\u000e\n\u0002\u0010\u0005\n\u0000\n\u0002\u0010\b\n\u0002\u0010\n\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\f\n\u0002\b\u000e\u001a\u0015\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\u0015\u0010\u0000\u001a\u00020\u0001*\u00020\u00052\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\u0015\u0010\u0000\u001a\u00020\u0001*\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\u0015\u0010\u0000\u001a\u00020\u0001*\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\u000f\u0010\u0007\u001a\u00020\b*\u0004\u0018\u00010\u0001H\u0087\b\u001a\r\u0010\t\u001a\u00020\u0002*\u00020\u0001H\u0087\b\u001a\u0015\u0010\t\u001a\u00020\u0002*\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\r\u0010\n\u001a\u00020\u0005*\u00020\u0001H\u0087\b\u001a\u0015\u0010\n\u001a\u00020\u0005*\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\r\u0010\u000b\u001a\u00020\u0004*\u00020\u0001H\u0087\b\u001a\u0015\u0010\u000b\u001a\u00020\u0004*\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\r\u0010\f\u001a\u00020\u0006*\u00020\u0001H\u0087\b\u001a\u0015\u0010\f\u001a\u00020\u0006*\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\r\u0010\r\u001a\u00020\u000e*\u00020\u0001H\u0087\b\u001a\r\u0010\u000f\u001a\u00020\u0010*\u00020\u0001H\u0087\b\u001a\u0013\u0010\u0011\u001a\u0004\u0018\u00010\u000e*\u00020\u0001H\u0007¢\u0006\u0002\u0010\u0012\u001a\u0013\u0010\u0013\u001a\u0004\u0018\u00010\u0010*\u00020\u0001H\u0007¢\u0006\u0002\u0010\u0014\u001a\r\u0010\u0015\u001a\u00020\u0016*\u00020\u0001H\u0087\b\u001a\u0015\u0010\u0015\u001a\u00020\u0016*\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\u000e\u0010\u0017\u001a\u0004\u0018\u00010\u0016*\u00020\u0001H\u0007\u001a\u0016\u0010\u0017\u001a\u0004\u0018\u00010\u0016*\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0004H\u0007\u001a\r\u0010\u0018\u001a\u00020\u0019*\u00020\u0001H\u0087\b\u001a\u0015\u0010\u0018\u001a\u00020\u0019*\u00020\u00012\u0006\u0010\u001a\u001a\u00020\u001bH\u0087\b\u001a\u000e\u0010\u001c\u001a\u0004\u0018\u00010\u0019*\u00020\u0001H\u0007\u001a\u0016\u0010\u001c\u001a\u0004\u0018\u00010\u0019*\u00020\u00012\u0006\u0010\u001a\u001a\u00020\u001bH\u0007\u001a4\u0010\u001d\u001a\u0004\u0018\u0001H\u001e\"\u0004\b\u0000\u0010\u001e2\u0006\u0010\u001f\u001a\u00020\u00012\u0012\u0010 \u001a\u000e\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u0002H\u001e0!H\u0082\b¢\u0006\u0004\b\"\u0010#\u001a\u0015\u0010$\u001a\u00020\b2\u0006\u0010%\u001a\u00020\u0001H\u0002¢\u0006\u0002\b&\u001a \u0010'\u001a\u0004\u0018\u00010\u00012\u0006\u0010(\u001a\u00020\u00042\u0006\u0010)\u001a\u00020\u0004H\u0083\b¢\u0006\u0002\b*\u001a\u0012\u0010+\u001a\u00020\b*\u00020,H\u0083\b¢\u0006\u0002\b-\u001a\u0012\u0010.\u001a\u00020\b*\u00020,H\u0083\b¢\u0006\u0002\b/\u001a\u0012\u00100\u001a\u00020\u0004*\u00020,H\u0083\b¢\u0006\u0002\b1\u001a6\u00102\u001a\u00020\u0004*\u00020\u00012\u0006\u0010(\u001a\u00020\u00042\u0006\u0010)\u001a\u00020\u00042\u0012\u00103\u001a\u000e\u0012\u0004\u0012\u00020,\u0012\u0004\u0012\u00020\b0!H\u0083\b¢\u0006\u0002\b4\u001a6\u00105\u001a\u00020\u0004*\u00020\u00012\u0006\u0010(\u001a\u00020\u00042\u0006\u0010)\u001a\u00020\u00042\u0012\u00103\u001a\u000e\u0012\u0004\u0012\u00020,\u0012\u0004\u0012\u00020\b0!H\u0083\b¢\u0006\u0002\b6\u001a>\u00107\u001a\u00020\u0004*\u00020\u00012\u0006\u0010(\u001a\u00020\u00042\u0006\u0010)\u001a\u00020\u00042\u0006\u00108\u001a\u00020\b2\u0012\u00103\u001a\u000e\u0012\u0004\u0012\u00020,\u0012\u0004\u0012\u00020\b0!H\u0083\b¢\u0006\u0002\b9¨\u0006:"},
   d2 = {"toString", "", "", "radix", "", "", "", "toBoolean", "", "toByte", "toShort", "toInt", "toLong", "toFloat", "", "toDouble", "", "toFloatOrNull", "(Ljava/lang/String;)Ljava/lang/Float;", "toDoubleOrNull", "(Ljava/lang/String;)Ljava/lang/Double;", "toBigInteger", "Ljava/math/BigInteger;", "toBigIntegerOrNull", "toBigDecimal", "Ljava/math/BigDecimal;", "mathContext", "Ljava/math/MathContext;", "toBigDecimalOrNull", "screenFloatValue", "T", "str", "parse", "Lkotlin/Function1;", "screenFloatValue$StringsKt__StringNumberConversionsJVMKt", "(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "isValidFloat", "s", "isValidFloat$StringsKt__StringNumberConversionsJVMKt", "guessNamedFloatConstant", "start", "endInclusive", "guessNamedFloatConstant$StringsKt__StringNumberConversionsJVMKt", "isAsciiDigit", "", "isAsciiDigit$StringsKt__StringNumberConversionsJVMKt", "isHexLetter", "isHexLetter$StringsKt__StringNumberConversionsJVMKt", "asciiLetterToLowerCaseCode", "asciiLetterToLowerCaseCode$StringsKt__StringNumberConversionsJVMKt", "advanceWhile", "predicate", "advanceWhile$StringsKt__StringNumberConversionsJVMKt", "backtrackWhile", "backtrackWhile$StringsKt__StringNumberConversionsJVMKt", "advanceAndValidateMantissa", "hexFormat", "advanceAndValidateMantissa$StringsKt__StringNumberConversionsJVMKt", "kotlin-stdlib"},
   xs = "kotlin/text/StringsKt"
)
@SourceDebugExtension({"SMAP\nStringNumberConversionsJVM.kt\nKotlin\n*S Kotlin\n*F\n+ 1 StringNumberConversionsJVM.kt\nkotlin/text/StringsKt__StringNumberConversionsJVMKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,512:1\n267#1,7:513\n267#1,7:520\n267#1,7:527\n267#1,7:534\n1#2:541\n*S KotlinDebug\n*F\n+ 1 StringNumberConversionsJVM.kt\nkotlin/text/StringsKt__StringNumberConversionsJVMKt\n*L\n166#1:513,7\n173#1:520,7\n253#1:527,7\n264#1:534,7\n*E\n"})
class StringsKt__StringNumberConversionsJVMKt extends StringsKt__StringBuilderKt {
   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final String toString(byte $this$toString, int radix) {
      String var10000 = Integer.toString($this$toString, CharsKt.checkRadix(radix));
      Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      return var10000;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final String toString(short $this$toString, int radix) {
      String var10000 = Integer.toString($this$toString, CharsKt.checkRadix(radix));
      Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      return var10000;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final String toString(int $this$toString, int radix) {
      String var10000 = Integer.toString($this$toString, CharsKt.checkRadix(radix));
      Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      return var10000;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final String toString(long $this$toString, int radix) {
      String var10000 = Long.toString($this$toString, CharsKt.checkRadix(radix));
      Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      return var10000;
   }

   @SinceKotlin(
      version = "1.4"
   )
   @InlineOnly
   private static final boolean toBoolean(String $this$toBoolean) {
      return Boolean.parseBoolean($this$toBoolean);
   }

   @InlineOnly
   private static final byte toByte(String $this$toByte) {
      Intrinsics.checkNotNullParameter($this$toByte, "<this>");
      return Byte.parseByte($this$toByte);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final byte toByte(String $this$toByte, int radix) {
      Intrinsics.checkNotNullParameter($this$toByte, "<this>");
      return Byte.parseByte($this$toByte, CharsKt.checkRadix(radix));
   }

   @InlineOnly
   private static final short toShort(String $this$toShort) {
      Intrinsics.checkNotNullParameter($this$toShort, "<this>");
      return Short.parseShort($this$toShort);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final short toShort(String $this$toShort, int radix) {
      Intrinsics.checkNotNullParameter($this$toShort, "<this>");
      return Short.parseShort($this$toShort, CharsKt.checkRadix(radix));
   }

   @InlineOnly
   private static final int toInt(String $this$toInt) {
      Intrinsics.checkNotNullParameter($this$toInt, "<this>");
      return Integer.parseInt($this$toInt);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final int toInt(String $this$toInt, int radix) {
      Intrinsics.checkNotNullParameter($this$toInt, "<this>");
      return Integer.parseInt($this$toInt, CharsKt.checkRadix(radix));
   }

   @InlineOnly
   private static final long toLong(String $this$toLong) {
      Intrinsics.checkNotNullParameter($this$toLong, "<this>");
      return Long.parseLong($this$toLong);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @InlineOnly
   private static final long toLong(String $this$toLong, int radix) {
      Intrinsics.checkNotNullParameter($this$toLong, "<this>");
      return Long.parseLong($this$toLong, CharsKt.checkRadix(radix));
   }

   @InlineOnly
   private static final float toFloat(String $this$toFloat) {
      Intrinsics.checkNotNullParameter($this$toFloat, "<this>");
      return Float.parseFloat($this$toFloat);
   }

   @InlineOnly
   private static final double toDouble(String $this$toDouble) {
      Intrinsics.checkNotNullParameter($this$toDouble, "<this>");
      return Double.parseDouble($this$toDouble);
   }

   @SinceKotlin(
      version = "1.1"
   )
   @Nullable
   public static final Float toFloatOrNull(@NotNull String $this$toFloatOrNull) {
      Intrinsics.checkNotNullParameter($this$toFloatOrNull, "<this>");
      String str$iv = $this$toFloatOrNull;
      int $i$f$screenFloatValue = 0;

      Float p0;
      try {
         Float var10000;
         if (isValidFloat$StringsKt__StringNumberConversionsJVMKt(str$iv)) {
            int var4 = 0;
            var10000 = Float.parseFloat(str$iv);
         } else {
            var10000 = null;
         }

         p0 = var10000;
      } catch (NumberFormatException var5) {
         p0 = null;
      }

      return p0;
   }

   @SinceKotlin(
      version = "1.1"
   )
   @Nullable
   public static final Double toDoubleOrNull(@NotNull String $this$toDoubleOrNull) {
      Intrinsics.checkNotNullParameter($this$toDoubleOrNull, "<this>");
      String str$iv = $this$toDoubleOrNull;
      int $i$f$screenFloatValue = 0;

      Double p0;
      try {
         Double var10000;
         if (isValidFloat$StringsKt__StringNumberConversionsJVMKt(str$iv)) {
            int var4 = 0;
            var10000 = Double.parseDouble(str$iv);
         } else {
            var10000 = null;
         }

         p0 = var10000;
      } catch (NumberFormatException var5) {
         p0 = null;
      }

      return p0;
   }

   @SinceKotlin(
      version = "1.2"
   )
   @InlineOnly
   private static final BigInteger toBigInteger(String $this$toBigInteger) {
      Intrinsics.checkNotNullParameter($this$toBigInteger, "<this>");
      return new BigInteger($this$toBigInteger);
   }

   @SinceKotlin(
      version = "1.2"
   )
   @InlineOnly
   private static final BigInteger toBigInteger(String $this$toBigInteger, int radix) {
      Intrinsics.checkNotNullParameter($this$toBigInteger, "<this>");
      return new BigInteger($this$toBigInteger, CharsKt.checkRadix(radix));
   }

   @SinceKotlin(
      version = "1.2"
   )
   @Nullable
   public static final BigInteger toBigIntegerOrNull(@NotNull String $this$toBigIntegerOrNull) {
      Intrinsics.checkNotNullParameter($this$toBigIntegerOrNull, "<this>");
      return StringsKt.toBigIntegerOrNull($this$toBigIntegerOrNull, 10);
   }

   @SinceKotlin(
      version = "1.2"
   )
   @Nullable
   public static final BigInteger toBigIntegerOrNull(@NotNull String $this$toBigIntegerOrNull, int radix) {
      Intrinsics.checkNotNullParameter($this$toBigIntegerOrNull, "<this>");
      CharsKt.checkRadix(radix);
      int length = $this$toBigIntegerOrNull.length();
      switch (length) {
         case 0:
            return null;
         case 1:
            if (CharsKt.digitOf($this$toBigIntegerOrNull.charAt(0), radix) < 0) {
               return null;
            }
            break;
         default:
            int start = $this$toBigIntegerOrNull.charAt(0) == '-' ? 1 : 0;

            for(int index = start; index < length; ++index) {
               if (CharsKt.digitOf($this$toBigIntegerOrNull.charAt(index), radix) < 0) {
                  return null;
               }
            }
      }

      return new BigInteger($this$toBigIntegerOrNull, CharsKt.checkRadix(radix));
   }

   @SinceKotlin(
      version = "1.2"
   )
   @InlineOnly
   private static final BigDecimal toBigDecimal(String $this$toBigDecimal) {
      Intrinsics.checkNotNullParameter($this$toBigDecimal, "<this>");
      return new BigDecimal($this$toBigDecimal);
   }

   @SinceKotlin(
      version = "1.2"
   )
   @InlineOnly
   private static final BigDecimal toBigDecimal(String $this$toBigDecimal, MathContext mathContext) {
      Intrinsics.checkNotNullParameter($this$toBigDecimal, "<this>");
      Intrinsics.checkNotNullParameter(mathContext, "mathContext");
      return new BigDecimal($this$toBigDecimal, mathContext);
   }

   @SinceKotlin(
      version = "1.2"
   )
   @Nullable
   public static final BigDecimal toBigDecimalOrNull(@NotNull String $this$toBigDecimalOrNull) {
      Intrinsics.checkNotNullParameter($this$toBigDecimalOrNull, "<this>");
      String str$iv = $this$toBigDecimalOrNull;
      int $i$f$screenFloatValue = 0;

      BigDecimal it;
      try {
         BigDecimal var10000;
         if (isValidFloat$StringsKt__StringNumberConversionsJVMKt(str$iv)) {
            int var4 = 0;
            var10000 = new BigDecimal(str$iv);
         } else {
            var10000 = null;
         }

         it = var10000;
      } catch (NumberFormatException var5) {
         it = null;
      }

      return it;
   }

   @SinceKotlin(
      version = "1.2"
   )
   @Nullable
   public static final BigDecimal toBigDecimalOrNull(@NotNull String $this$toBigDecimalOrNull, @NotNull MathContext mathContext) {
      Intrinsics.checkNotNullParameter($this$toBigDecimalOrNull, "<this>");
      Intrinsics.checkNotNullParameter(mathContext, "mathContext");
      String str$iv = $this$toBigDecimalOrNull;
      int $i$f$screenFloatValue = 0;

      BigDecimal var6;
      try {
         BigDecimal var10000;
         if (isValidFloat$StringsKt__StringNumberConversionsJVMKt(str$iv)) {
            int var5 = 0;
            var10000 = new BigDecimal(str$iv, mathContext);
         } else {
            var10000 = null;
         }

         var6 = var10000;
      } catch (NumberFormatException var7) {
         var6 = null;
      }

      return var6;
   }

   private static final <T> T screenFloatValue$StringsKt__StringNumberConversionsJVMKt(String str, Function1<? super String, ? extends T> parse) {
      int $i$f$screenFloatValue = 0;

      Object var3;
      try {
         var3 = isValidFloat$StringsKt__StringNumberConversionsJVMKt(str) ? parse.invoke(str) : null;
      } catch (NumberFormatException var5) {
         var3 = null;
      }

      return (T)var3;
   }

   private static final boolean isValidFloat$StringsKt__StringNumberConversionsJVMKt(String s) {
      int start = 0;
      int endInclusive = s.length() - 1;
      String var3 = s;

      int l;
      for(l = start; l <= endInclusive; ++l) {
         char it = var3.charAt(l);
         int var6 = 0;
         if (it > ' ') {
            break;
         }
      }

      start = l;
      if (l > endInclusive) {
         return false;
      } else {
         var3 = s;

         for(l = endInclusive; l > start; --l) {
            char it = var3.charAt(l);
            int var26 = 0;
            if (it > ' ') {
               break;
            }
         }

         endInclusive = l;
         if (s.charAt(start) == '+' || s.charAt(start) == '-') {
            ++start;
         }

         if (start > l) {
            return false;
         } else {
            boolean isHex = false;
            if (s.charAt(start) == '0') {
               ++start;
               if (start > l) {
                  return true;
               }

               if ((s.charAt(start) | 32) == 120) {
                  ++start;
                  String var8 = s;

                  int var9;
                  for(var9 = start; var9 <= endInclusive; ++var9) {
                     char it = var8.charAt(var9);
                     int var11 = 0;
                     if ((it - 48 & '\uffff') >= 10 && ((it | 32) - 97 & '\uffff') >= 6) {
                        break;
                     }
                  }

                  int var27 = var9;
                  boolean var34 = start != var9;
                  int var10000;
                  if (var9 > endInclusive) {
                     var10000 = -1;
                  } else {
                     var9 = 0;
                     if (s.charAt(var9) == '.') {
                        ++var27;
                        int var7 = var27;
                        String it = s;

                        int var45;
                        for(var45 = var27; var45 <= endInclusive; ++var45) {
                           char it = it.charAt(var45);
                           int var13 = 0;
                           if ((it - 48 & '\uffff') >= 10 && ((it | 32) - 97 & '\uffff') >= 6) {
                              break;
                           }
                        }

                        var27 = var45;
                        var9 = var7 != var45;
                     }

                     var10000 = !var34 && !var9 ? -1 : var27;
                  }

                  start = var10000;
                  if (start == -1 || start > endInclusive) {
                     return false;
                  }

                  isHex = true;
               } else {
                  --start;
               }
            }

            if (!isHex) {
               String var35 = s;

               int var39;
               for(var39 = start; var39 <= endInclusive; ++var39) {
                  char it = var35.charAt(var39);
                  int var46 = 0;
                  if ((it - 48 & '\uffff') >= 10) {
                     break;
                  }
               }

               int var29 = var39;
               boolean var36 = start != var39;
               int var50;
               if (var39 > endInclusive) {
                  var50 = var39;
               } else {
                  var39 = 0;
                  if (s.charAt(var39) == '.') {
                     ++var29;
                     int var32 = var29;
                     String var43 = s;

                     int var47;
                     for(var47 = var29; var47 <= endInclusive; ++var47) {
                        char it = var43.charAt(var47);
                        int var49 = 0;
                        if ((it - 48 & '\uffff') >= 10) {
                           break;
                        }
                     }

                     var29 = var47;
                     var39 = var32 != var47;
                  }

                  if (!var36 && !var39) {
                     String var44 = endInclusive == var29 + 3 - 1 ? "NaN" : (endInclusive == var29 + 8 - 1 ? "Infinity" : null);
                     var50 = var44 == null ? -1 : (StringsKt.indexOf((CharSequence)s, var44, var29, false) == var29 ? endInclusive + 1 : -1);
                  } else {
                     var50 = var29;
                  }
               }

               start = var50;
               if (start == -1) {
                  return false;
               }

               if (start > endInclusive) {
                  return true;
               }
            }

            l = s.charAt(start++) | 32;
            if (l != (isHex ? 112 : 101)) {
               return !isHex && (l == 102 || l == 100) && start > endInclusive;
            } else if (start > endInclusive) {
               return false;
            } else {
               if (s.charAt(start) == '+' || s.charAt(start) == '-') {
                  ++start;
                  if (start > endInclusive) {
                     return false;
                  }
               }

               String var25 = s;

               int var31;
               for(var31 = start; var31 <= endInclusive; ++var31) {
                  char it = var25.charAt(var31);
                  int var37 = 0;
                  if ((it - 48 & '\uffff') >= 10) {
                     break;
                  }
               }

               if (var31 > endInclusive) {
                  return true;
               } else if (var31 != endInclusive) {
                  return false;
               } else {
                  l = s.charAt(var31) | 32;
                  return l == 102 || l == 100;
               }
            }
         }
      }
   }

   @InlineOnly
   private static final String guessNamedFloatConstant$StringsKt__StringNumberConversionsJVMKt(int start, int endInclusive) {
      return endInclusive == start + 3 - 1 ? "NaN" : (endInclusive == start + 8 - 1 ? "Infinity" : null);
   }

   @InlineOnly
   private static final boolean isAsciiDigit$StringsKt__StringNumberConversionsJVMKt(char $this$isAsciiDigit) {
      return ($this$isAsciiDigit - 48 & '\uffff') < 10;
   }

   @InlineOnly
   private static final boolean isHexLetter$StringsKt__StringNumberConversionsJVMKt(char $this$isHexLetter) {
      return (($this$isHexLetter | 32) - 97 & '\uffff') < 6;
   }

   @InlineOnly
   private static final int asciiLetterToLowerCaseCode$StringsKt__StringNumberConversionsJVMKt(char $this$asciiLetterToLowerCaseCode) {
      return $this$asciiLetterToLowerCaseCode | 32;
   }

   @InlineOnly
   private static final int advanceWhile$StringsKt__StringNumberConversionsJVMKt(String $this$advanceWhile, int start, int endInclusive, Function1<? super Character, Boolean> predicate) {
      int start;
      for(start = start; start <= endInclusive && (Boolean)predicate.invoke($this$advanceWhile.charAt(start)); ++start) {
      }

      return start;
   }

   @InlineOnly
   private static final int backtrackWhile$StringsKt__StringNumberConversionsJVMKt(String $this$backtrackWhile, int start, int endInclusive, Function1<? super Character, Boolean> predicate) {
      int endInclusive;
      for(endInclusive = endInclusive; endInclusive > start && (Boolean)predicate.invoke($this$backtrackWhile.charAt(endInclusive)); --endInclusive) {
      }

      return endInclusive;
   }

   @InlineOnly
   private static final int advanceAndValidateMantissa$StringsKt__StringNumberConversionsJVMKt(String $this$advanceAndValidateMantissa, int start, int endInclusive, boolean hexFormat, Function1<? super Character, Boolean> predicate) {
      String var7 = $this$advanceAndValidateMantissa;

      boolean hasFractionalPart;
      for(hasFractionalPart = (boolean)start; hasFractionalPart <= endInclusive && (Boolean)predicate.invoke(var7.charAt(hasFractionalPart)); ++hasFractionalPart) {
      }

      int start = hasFractionalPart;
      boolean hasIntegerPart = start != hasFractionalPart;
      if (hasFractionalPart > endInclusive) {
         return hexFormat ? -1 : hasFractionalPart;
      } else {
         hasFractionalPart = (boolean)0;
         if ($this$advanceAndValidateMantissa.charAt(hasFractionalPart) == '.') {
            ++start;
            int checkpoint = start;
            String var9 = $this$advanceAndValidateMantissa;

            int var10;
            for(var10 = start; var10 <= endInclusive && (Boolean)predicate.invoke(var9.charAt(var10)); ++var10) {
            }

            start = var10;
            hasFractionalPart = checkpoint != var10;
         }

         if (!hasIntegerPart && !hasFractionalPart) {
            if (hexFormat) {
               return -1;
            } else {
               String constant = endInclusive == start + 3 - 1 ? "NaN" : (endInclusive == start + 8 - 1 ? "Infinity" : null);
               if (constant == null) {
                  return -1;
               } else {
                  return StringsKt.indexOf((CharSequence)$this$advanceAndValidateMantissa, constant, start, false) == start ? endInclusive + 1 : -1;
               }
            }
         } else {
            return start;
         }
      }
   }

   public StringsKt__StringNumberConversionsJVMKt() {
   }
}
