package kotlin.text;

import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import kotlin.Metadata;
import kotlin.collections.AbstractList;
import kotlin.collections.CollectionsKt;
import kotlin.internal.PlatformImplementationsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.IntRange;
import kotlin.sequences.SequencesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\r\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b\u0005\b\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\n\u0010\u001d\u001a\u0004\u0018\u00010\u0001H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\u00020\t8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\n\u0010\u000bR\u0014\u0010\f\u001a\u00020\r8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u000e\u0010\u000fR\u0014\u0010\u0010\u001a\u00020\u00118VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u0013R\u0014\u0010\u0014\u001a\u00020\u0015X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0016\u0010\u0018\u001a\n\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u00110\u00198VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u001b\u0010\u001c¨\u0006\u001e"},
   d2 = {"Lkotlin/text/MatcherMatchResult;", "Lkotlin/text/MatchResult;", "matcher", "Ljava/util/regex/Matcher;", "input", "", "<init>", "(Ljava/util/regex/Matcher;Ljava/lang/CharSequence;)V", "matchResult", "Ljava/util/regex/MatchResult;", "getMatchResult", "()Ljava/util/regex/MatchResult;", "range", "Lkotlin/ranges/IntRange;", "getRange", "()Lkotlin/ranges/IntRange;", "value", "", "getValue", "()Ljava/lang/String;", "groups", "Lkotlin/text/MatchGroupCollection;", "getGroups", "()Lkotlin/text/MatchGroupCollection;", "groupValues_", "", "groupValues", "getGroupValues", "()Ljava/util/List;", "next", "kotlin-stdlib"}
)
final class MatcherMatchResult implements MatchResult {
   @NotNull
   private final Matcher matcher;
   @NotNull
   private final CharSequence input;
   @NotNull
   private final MatchGroupCollection groups;
   @Nullable
   private List<String> groupValues_;

   public MatcherMatchResult(@NotNull Matcher matcher, @NotNull CharSequence input) {
      Intrinsics.checkNotNullParameter(matcher, "matcher");
      Intrinsics.checkNotNullParameter(input, "input");
      super();
      this.matcher = matcher;
      this.input = input;
      this.groups = new MatchNamedGroupCollection() {
         public int getSize() {
            return MatcherMatchResult.this.getMatchResult().groupCount() + 1;
         }

         public boolean isEmpty() {
            return false;
         }

         public Iterator<MatchGroup> iterator() {
            return SequencesKt.map(CollectionsKt.asSequence(CollectionsKt.getIndices(this)), <undefinedtype>::iterator$lambda$0).iterator();
         }

         public MatchGroup get(int index) {
            IntRange range = RegexKt.access$range(MatcherMatchResult.this.getMatchResult(), index);
            MatchGroup var10000;
            if (range.getStart() >= 0) {
               String var10002 = MatcherMatchResult.this.getMatchResult().group(index);
               Intrinsics.checkNotNullExpressionValue(var10002, "group(...)");
               var10000 = new MatchGroup(var10002, range);
            } else {
               var10000 = null;
            }

            return var10000;
         }

         public MatchGroup get(String name) {
            Intrinsics.checkNotNullParameter(name, "name");
            return PlatformImplementationsKt.IMPLEMENTATIONS.getMatchResultNamedGroup(MatcherMatchResult.this.getMatchResult(), name);
         }

         private static final MatchGroup iterator$lambda$0(Object this$0, int it) {
            return this$0.get(it);
         }
      };
   }

   private final java.util.regex.MatchResult getMatchResult() {
      return (java.util.regex.MatchResult)this.matcher;
   }

   @NotNull
   public IntRange getRange() {
      return RegexKt.access$range(this.getMatchResult());
   }

   @NotNull
   public String getValue() {
      String var10000 = this.getMatchResult().group();
      Intrinsics.checkNotNullExpressionValue(var10000, "group(...)");
      return var10000;
   }

   @NotNull
   public MatchGroupCollection getGroups() {
      return this.groups;
   }

   @NotNull
   public List<String> getGroupValues() {
      if (this.groupValues_ == null) {
         this.groupValues_ = new AbstractList<String>() {
            public int getSize() {
               return MatcherMatchResult.this.getMatchResult().groupCount() + 1;
            }

            public String get(int index) {
               String var10000 = MatcherMatchResult.this.getMatchResult().group(index);
               if (var10000 == null) {
                  var10000 = "";
               }

               return var10000;
            }
         };
      }

      List var10000 = this.groupValues_;
      Intrinsics.checkNotNull(var10000);
      return var10000;
   }

   @Nullable
   public MatchResult next() {
      int nextIndex = this.getMatchResult().end() + (this.getMatchResult().end() == this.getMatchResult().start() ? 1 : 0);
      MatchResult var2;
      if (nextIndex <= this.input.length()) {
         Matcher var10000 = this.matcher.pattern().matcher(this.input);
         Intrinsics.checkNotNullExpressionValue(var10000, "matcher(...)");
         var2 = RegexKt.access$findNext(var10000, nextIndex, this.input);
      } else {
         var2 = null;
      }

      return var2;
   }
}
