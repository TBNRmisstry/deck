package kotlin.text;

import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.SourceDebugExtension;

@Metadata(
   mv = {2, 2, 0},
   k = 3,
   xi = 48
)
@SourceDebugExtension({"SMAP\nRegex.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Regex.kt\nkotlin/text/RegexKt$fromInt$1$1\n*L\n1#1,404:1\n*E\n"})
public final class Regex$special$$inlined$fromInt$1 implements Function1<RegexOption, Boolean> {
   // $FF: synthetic field
   final int $value;

   public Regex$special$$inlined$fromInt$1(int $value) {
      this.$value = $value;
   }

   public final Boolean invoke(RegexOption it) {
      return (this.$value & ((FlagEnum)it).getMask()) == ((FlagEnum)it).getValue();
   }
}
