package kotlin;

@Metadata(
   mv = {2, 2, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/PreconditionsKt__AssertionsJVMKt", "kotlin/PreconditionsKt__PreconditionsKt"}
)
public final class PreconditionsKt extends PreconditionsKt__PreconditionsKt {
   private PreconditionsKt() {
   }
}
