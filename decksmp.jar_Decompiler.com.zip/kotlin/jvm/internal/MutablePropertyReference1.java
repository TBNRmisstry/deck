package kotlin.jvm.internal;

import kotlin.SinceKotlin;
import kotlin.reflect.KCallable;
import kotlin.reflect.KMutableProperty1;
import kotlin.reflect.KProperty1;

public abstract class MutablePropertyReference1 extends MutablePropertyReference implements KMutableProperty1 {
   public MutablePropertyReference1() {
   }

   @SinceKotlin(
      version = "1.1"
   )
   public MutablePropertyReference1(Object receiver) {
      super(receiver);
   }

   @SinceKotlin(
      version = "1.4"
   )
   public MutablePropertyReference1(Object receiver, Class owner, String name, String signature, int flags) {
      super(receiver, owner, name, signature, flags);
   }

   protected KCallable computeReflected() {
      return Reflection.mutableProperty1(this);
   }

   public Object invoke(Object receiver) {
      return this.get(receiver);
   }

   public KProperty1.Getter getGetter() {
      return ((KMutableProperty1)this.getReflected()).getGetter();
   }

   public KMutableProperty1.Setter getSetter() {
      return ((KMutableProperty1)this.getReflected()).getSetter();
   }

   @SinceKotlin(
      version = "1.1"
   )
   public Object getDelegate(Object receiver) {
      return ((KMutableProperty1)this.getReflected()).getDelegate(receiver);
   }
}
