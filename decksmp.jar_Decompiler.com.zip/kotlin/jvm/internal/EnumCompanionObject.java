package kotlin.jvm.internal;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\bÀ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"},
   d2 = {"Lkotlin/jvm/internal/EnumCompanionObject;", "", "<init>", "()V", "kotlin-stdlib"}
)
public final class EnumCompanionObject {
   @NotNull
   public static final EnumCompanionObject INSTANCE = new EnumCompanionObject();

   private EnumCompanionObject() {
   }
}
