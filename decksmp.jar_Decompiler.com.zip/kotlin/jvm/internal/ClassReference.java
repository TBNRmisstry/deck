package kotlin.jvm.internal;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import kotlin.Function;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.TuplesKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.JvmClassMappingKt;
import kotlin.jvm.KotlinReflectionNotSupportedError;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function10;
import kotlin.jvm.functions.Function11;
import kotlin.jvm.functions.Function12;
import kotlin.jvm.functions.Function13;
import kotlin.jvm.functions.Function14;
import kotlin.jvm.functions.Function15;
import kotlin.jvm.functions.Function16;
import kotlin.jvm.functions.Function17;
import kotlin.jvm.functions.Function18;
import kotlin.jvm.functions.Function19;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function20;
import kotlin.jvm.functions.Function21;
import kotlin.jvm.functions.Function22;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.functions.Function5;
import kotlin.jvm.functions.Function6;
import kotlin.jvm.functions.Function7;
import kotlin.jvm.functions.Function8;
import kotlin.jvm.functions.Function9;
import kotlin.reflect.KCallable;
import kotlin.reflect.KClass;
import kotlin.reflect.KFunction;
import kotlin.reflect.KType;
import kotlin.reflect.KTypeParameter;
import kotlin.reflect.KVisibility;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000r\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u001e\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0010\u001b\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0017\n\u0002\u0010\u0001\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\u0018\u0000 P2\b\u0012\u0004\u0012\u00020\u00020\u00012\u00020\u0003:\u0001PB\u0013\u0012\n\u0010\u0004\u001a\u0006\u0012\u0002\b\u00030\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u0012\u0010\"\u001a\u00020#2\b\u0010$\u001a\u0004\u0018\u00010\u0002H\u0017J\b\u0010I\u001a\u00020JH\u0002J\u0013\u0010K\u001a\u00020#2\b\u0010L\u001a\u0004\u0018\u00010\u0002H\u0096\u0002J\b\u0010M\u001a\u00020NH\u0016J\b\u0010O\u001a\u00020\u000bH\u0016R\u0018\u0010\u0004\u001a\u0006\u0012\u0002\b\u00030\u0005X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0016\u0010\n\u001a\u0004\u0018\u00010\u000b8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\f\u0010\rR\u0016\u0010\u000e\u001a\u0004\u0018\u00010\u000b8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u000f\u0010\rR\u001e\u0010\u0010\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00120\u00118VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0013\u0010\u0014R \u0010\u0015\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00160\u00118VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0017\u0010\u0014R\u001e\u0010\u0018\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00010\u00118VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0019\u0010\u0014R\u001a\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u001c0\u001b8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u001d\u0010\u001eR\u0016\u0010\u001f\u001a\u0004\u0018\u00010\u00028VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b \u0010!R \u0010%\u001a\b\u0012\u0004\u0012\u00020&0\u001b8VX\u0097\u0004¢\u0006\f\u0012\u0004\b'\u0010(\u001a\u0004\b)\u0010\u001eR \u0010*\u001a\b\u0012\u0004\u0012\u00020+0\u001b8VX\u0097\u0004¢\u0006\f\u0012\u0004\b,\u0010(\u001a\u0004\b-\u0010\u001eR(\u0010.\u001a\u0010\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\u00020\u00010\u001b8VX\u0097\u0004¢\u0006\f\u0012\u0004\b/\u0010(\u001a\u0004\b0\u0010\u001eR\u001c\u00101\u001a\u0004\u0018\u0001028VX\u0097\u0004¢\u0006\f\u0012\u0004\b3\u0010(\u001a\u0004\b4\u00105R\u001a\u00106\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\b7\u0010(\u001a\u0004\b6\u00108R\u001a\u00109\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\b:\u0010(\u001a\u0004\b9\u00108R\u001a\u0010;\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\b<\u0010(\u001a\u0004\b;\u00108R\u001a\u0010=\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\b>\u0010(\u001a\u0004\b=\u00108R\u001a\u0010?\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\b@\u0010(\u001a\u0004\b?\u00108R\u001a\u0010A\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\bB\u0010(\u001a\u0004\bA\u00108R\u001a\u0010C\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\bD\u0010(\u001a\u0004\bC\u00108R\u001a\u0010E\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\bF\u0010(\u001a\u0004\bE\u00108R\u001a\u0010G\u001a\u00020#8VX\u0097\u0004¢\u0006\f\u0012\u0004\bH\u0010(\u001a\u0004\bG\u00108¨\u0006Q"},
   d2 = {"Lkotlin/jvm/internal/ClassReference;", "Lkotlin/reflect/KClass;", "", "Lkotlin/jvm/internal/ClassBasedDeclarationContainer;", "jClass", "Ljava/lang/Class;", "<init>", "(Ljava/lang/Class;)V", "getJClass", "()Ljava/lang/Class;", "simpleName", "", "getSimpleName", "()Ljava/lang/String;", "qualifiedName", "getQualifiedName", "members", "", "Lkotlin/reflect/KCallable;", "getMembers", "()Ljava/util/Collection;", "constructors", "Lkotlin/reflect/KFunction;", "getConstructors", "nestedClasses", "getNestedClasses", "annotations", "", "", "getAnnotations", "()Ljava/util/List;", "objectInstance", "getObjectInstance", "()Ljava/lang/Object;", "isInstance", "", "value", "typeParameters", "Lkotlin/reflect/KTypeParameter;", "getTypeParameters$annotations", "()V", "getTypeParameters", "supertypes", "Lkotlin/reflect/KType;", "getSupertypes$annotations", "getSupertypes", "sealedSubclasses", "getSealedSubclasses$annotations", "getSealedSubclasses", "visibility", "Lkotlin/reflect/KVisibility;", "getVisibility$annotations", "getVisibility", "()Lkotlin/reflect/KVisibility;", "isFinal", "isFinal$annotations", "()Z", "isOpen", "isOpen$annotations", "isAbstract", "isAbstract$annotations", "isSealed", "isSealed$annotations", "isData", "isData$annotations", "isInner", "isInner$annotations", "isCompanion", "isCompanion$annotations", "isFun", "isFun$annotations", "isValue", "isValue$annotations", "error", "", "equals", "other", "hashCode", "", "toString", "Companion", "kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nClassReference.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ClassReference.kt\nkotlin/jvm/internal/ClassReference\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,290:1\n1573#2:291\n1604#2,4:292\n*S KotlinDebug\n*F\n+ 1 ClassReference.kt\nkotlin/jvm/internal/ClassReference\n*L\n107#1:291\n107#1:292,4\n*E\n"})
public final class ClassReference implements KClass<Object>, ClassBasedDeclarationContainer {
   @NotNull
   public static final Companion Companion = new Companion((DefaultConstructorMarker)null);
   @NotNull
   private final Class<?> jClass;
   @NotNull
   private static final Map<Class<? extends Function<?>>, Integer> FUNCTION_CLASSES;

   public ClassReference(@NotNull Class<?> jClass) {
      Intrinsics.checkNotNullParameter(jClass, "jClass");
      super();
      this.jClass = jClass;
   }

   @NotNull
   public Class<?> getJClass() {
      return this.jClass;
   }

   @Nullable
   public String getSimpleName() {
      return Companion.getClassSimpleName(this.getJClass());
   }

   @Nullable
   public String getQualifiedName() {
      return Companion.getClassQualifiedName(this.getJClass());
   }

   @NotNull
   public Collection<KCallable<?>> getMembers() {
      this.error();
      throw new KotlinNothingValueException();
   }

   @NotNull
   public Collection<KFunction<Object>> getConstructors() {
      this.error();
      throw new KotlinNothingValueException();
   }

   @NotNull
   public Collection<KClass<?>> getNestedClasses() {
      this.error();
      throw new KotlinNothingValueException();
   }

   @NotNull
   public List<Annotation> getAnnotations() {
      this.error();
      throw new KotlinNothingValueException();
   }

   @Nullable
   public Object getObjectInstance() {
      this.error();
      throw new KotlinNothingValueException();
   }

   @SinceKotlin(
      version = "1.1"
   )
   public boolean isInstance(@Nullable Object value) {
      return Companion.isInstance(value, this.getJClass());
   }

   @NotNull
   public List<KTypeParameter> getTypeParameters() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void getTypeParameters$annotations() {
   }

   @NotNull
   public List<KType> getSupertypes() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void getSupertypes$annotations() {
   }

   @NotNull
   public List<KClass<? extends Object>> getSealedSubclasses() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.3"
   )
   public static void getSealedSubclasses$annotations() {
   }

   @Nullable
   public KVisibility getVisibility() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void getVisibility$annotations() {
   }

   public boolean isFinal() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isFinal$annotations() {
   }

   public boolean isOpen() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isOpen$annotations() {
   }

   public boolean isAbstract() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isAbstract$annotations() {
   }

   public boolean isSealed() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isSealed$annotations() {
   }

   public boolean isData() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isData$annotations() {
   }

   public boolean isInner() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isInner$annotations() {
   }

   public boolean isCompanion() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.1"
   )
   public static void isCompanion$annotations() {
   }

   public boolean isFun() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.4"
   )
   public static void isFun$annotations() {
   }

   public boolean isValue() {
      this.error();
      throw new KotlinNothingValueException();
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.5"
   )
   public static void isValue$annotations() {
   }

   private final Void error() {
      throw new KotlinReflectionNotSupportedError();
   }

   public boolean equals(@Nullable Object other) {
      return other instanceof ClassReference && Intrinsics.areEqual((Object)JvmClassMappingKt.getJavaObjectType(this), (Object)JvmClassMappingKt.getJavaObjectType((KClass)other));
   }

   public int hashCode() {
      return JvmClassMappingKt.getJavaObjectType(this).hashCode();
   }

   @NotNull
   public String toString() {
      return this.getJClass().toString() + " (Kotlin reflection is not available)";
   }

   static {
      Class[] var0 = new Class[]{Function0.class, Function1.class, Function2.class, Function3.class, Function4.class, Function5.class, Function6.class, Function7.class, Function8.class, Function9.class, Function10.class, Function11.class, Function12.class, Function13.class, Function14.class, Function15.class, Function16.class, Function17.class, Function18.class, Function19.class, Function20.class, Function21.class, Function22.class};
      Iterable var13 = (Iterable)CollectionsKt.listOf(var0);
      int $i$f$mapIndexed = 0;
      Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault(var13, 10)));
      int $i$f$mapIndexedTo = 0;
      int index$iv$iv = 0;

      for(Object item$iv$iv : var13) {
         int var8 = index$iv$iv++;
         if (var8 < 0) {
            CollectionsKt.throwIndexOverflow();
         }

         Class clazz = (Class)item$iv$iv;
         int var11 = 0;
         destination$iv$iv.add(TuplesKt.to(clazz, var8));
      }

      FUNCTION_CLASSES = MapsKt.toMap((Iterable)((List)destination$iv$iv));
   }

   @Metadata(
      mv = {2, 2, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\t\u001a\u0004\u0018\u00010\n2\u0006\u0010\u000b\u001a\u00020\nH\u0002J\u0012\u0010\f\u001a\u0004\u0018\u00010\n2\u0006\u0010\u000b\u001a\u00020\nH\u0002J\u0014\u0010\r\u001a\u0004\u0018\u00010\n2\n\u0010\u000e\u001a\u0006\u0012\u0002\b\u00030\u0006J\u0014\u0010\u000f\u001a\u0004\u0018\u00010\n2\n\u0010\u000e\u001a\u0006\u0012\u0002\b\u00030\u0006J\u001c\u0010\u0010\u001a\u00020\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u00012\n\u0010\u000e\u001a\u0006\u0012\u0002\b\u00030\u0006R&\u0010\u0004\u001a\u001a\u0012\u0010\u0012\u000e\u0012\n\b\u0001\u0012\u0006\u0012\u0002\b\u00030\u00070\u0006\u0012\u0004\u0012\u00020\b0\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0013"},
      d2 = {"Lkotlin/jvm/internal/ClassReference$Companion;", "", "<init>", "()V", "FUNCTION_CLASSES", "", "Ljava/lang/Class;", "Lkotlin/Function;", "", "classFqNameOf", "", "type", "simpleNameOf", "getClassSimpleName", "jClass", "getClassQualifiedName", "isInstance", "", "value", "kotlin-stdlib"}
   )
   @SourceDebugExtension({"SMAP\nClassReference.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ClassReference.kt\nkotlin/jvm/internal/ClassReference$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,290:1\n1#2:291\n*E\n"})
   public static final class Companion {
      private Companion() {
      }

      private final String classFqNameOf(String type) {
         String var10000;
         switch (type) {
            case "kotlin.jvm.internal.DoubleCompanionObject":
               var10000 = "kotlin.Double.Companion";
               return var10000;
            case "java.lang.Integer":
               var10000 = "kotlin.Int";
               return var10000;
            case "java.lang.Cloneable":
               var10000 = "kotlin.Cloneable";
               return var10000;
            case "java.lang.annotation.Annotation":
               var10000 = "kotlin.Annotation";
               return var10000;
            case "kotlin.jvm.functions.Function10":
               var10000 = "kotlin.Function10";
               return var10000;
            case "kotlin.jvm.functions.Function11":
               var10000 = "kotlin.Function11";
               return var10000;
            case "kotlin.jvm.functions.Function12":
               var10000 = "kotlin.Function12";
               return var10000;
            case "kotlin.jvm.functions.Function13":
               var10000 = "kotlin.Function13";
               return var10000;
            case "kotlin.jvm.functions.Function14":
               var10000 = "kotlin.Function14";
               return var10000;
            case "kotlin.jvm.functions.Function15":
               var10000 = "kotlin.Function15";
               return var10000;
            case "kotlin.jvm.functions.Function16":
               var10000 = "kotlin.Function16";
               return var10000;
            case "kotlin.jvm.functions.Function17":
               var10000 = "kotlin.Function17";
               return var10000;
            case "kotlin.jvm.functions.Function18":
               var10000 = "kotlin.Function18";
               return var10000;
            case "kotlin.jvm.functions.Function19":
               var10000 = "kotlin.Function19";
               return var10000;
            case "kotlin.jvm.functions.Function20":
               var10000 = "kotlin.Function20";
               return var10000;
            case "kotlin.jvm.functions.Function21":
               var10000 = "kotlin.Function21";
               return var10000;
            case "kotlin.jvm.functions.Function22":
               var10000 = "kotlin.Function22";
               return var10000;
            case "java.lang.Comparable":
               var10000 = "kotlin.Comparable";
               return var10000;
            case "java.util.Map":
               var10000 = "kotlin.collections.Map";
               return var10000;
            case "java.util.Set":
               var10000 = "kotlin.collections.Set";
               return var10000;
            case "double":
               var10000 = "kotlin.Double";
               return var10000;
            case "kotlin.jvm.internal.ByteCompanionObject":
               var10000 = "kotlin.Byte.Companion";
               return var10000;
            case "java.lang.CharSequence":
               var10000 = "kotlin.CharSequence";
               return var10000;
            case "java.util.Collection":
               var10000 = "kotlin.collections.Collection";
               return var10000;
            case "java.lang.Float":
               var10000 = "kotlin.Float";
               return var10000;
            case "java.lang.Short":
               var10000 = "kotlin.Short";
               return var10000;
            case "kotlin.jvm.internal.CharCompanionObject":
               var10000 = "kotlin.Char.Companion";
               return var10000;
            case "kotlin.jvm.internal.LongCompanionObject":
               var10000 = "kotlin.Long.Companion";
               return var10000;
            case "java.util.Map$Entry":
               var10000 = "kotlin.collections.Map.Entry";
               return var10000;
            case "int":
               var10000 = "kotlin.Int";
               return var10000;
            case "byte":
               var10000 = "kotlin.Byte";
               return var10000;
            case "char":
               var10000 = "kotlin.Char";
               return var10000;
            case "long":
               var10000 = "kotlin.Long";
               return var10000;
            case "boolean":
               var10000 = "kotlin.Boolean";
               return var10000;
            case "java.util.List":
               var10000 = "kotlin.collections.List";
               return var10000;
            case "kotlin.jvm.internal.ShortCompanionObject":
               var10000 = "kotlin.Short.Companion";
               return var10000;
            case "kotlin.jvm.functions.Function0":
               var10000 = "kotlin.Function0";
               return var10000;
            case "kotlin.jvm.functions.Function1":
               var10000 = "kotlin.Function1";
               return var10000;
            case "kotlin.jvm.functions.Function2":
               var10000 = "kotlin.Function2";
               return var10000;
            case "kotlin.jvm.functions.Function3":
               var10000 = "kotlin.Function3";
               return var10000;
            case "kotlin.jvm.functions.Function4":
               var10000 = "kotlin.Function4";
               return var10000;
            case "kotlin.jvm.functions.Function5":
               var10000 = "kotlin.Function5";
               return var10000;
            case "kotlin.jvm.functions.Function6":
               var10000 = "kotlin.Function6";
               return var10000;
            case "kotlin.jvm.functions.Function7":
               var10000 = "kotlin.Function7";
               return var10000;
            case "kotlin.jvm.functions.Function8":
               var10000 = "kotlin.Function8";
               return var10000;
            case "kotlin.jvm.functions.Function9":
               var10000 = "kotlin.Function9";
               return var10000;
            case "float":
               var10000 = "kotlin.Float";
               return var10000;
            case "short":
               var10000 = "kotlin.Short";
               return var10000;
            case "java.lang.Character":
               var10000 = "kotlin.Char";
               return var10000;
            case "kotlin.jvm.internal.EnumCompanionObject":
               var10000 = "kotlin.Enum.Companion";
               return var10000;
            case "java.lang.Boolean":
               var10000 = "kotlin.Boolean";
               return var10000;
            case "java.lang.Byte":
               var10000 = "kotlin.Byte";
               return var10000;
            case "java.lang.Enum":
               var10000 = "kotlin.Enum";
               return var10000;
            case "java.lang.Long":
               var10000 = "kotlin.Long";
               return var10000;
            case "kotlin.jvm.internal.FloatCompanionObject":
               var10000 = "kotlin.Float.Companion";
               return var10000;
            case "java.util.Iterator":
               var10000 = "kotlin.collections.Iterator";
               return var10000;
            case "java.util.ListIterator":
               var10000 = "kotlin.collections.ListIterator";
               return var10000;
            case "kotlin.jvm.internal.StringCompanionObject":
               var10000 = "kotlin.String.Companion";
               return var10000;
            case "java.lang.Double":
               var10000 = "kotlin.Double";
               return var10000;
            case "java.lang.Number":
               var10000 = "kotlin.Number";
               return var10000;
            case "java.lang.Object":
               var10000 = "kotlin.Any";
               return var10000;
            case "java.lang.String":
               var10000 = "kotlin.String";
               return var10000;
            case "java.lang.Iterable":
               var10000 = "kotlin.collections.Iterable";
               return var10000;
            case "kotlin.jvm.internal.BooleanCompanionObject":
               var10000 = "kotlin.Boolean.Companion";
               return var10000;
            case "java.lang.Throwable":
               var10000 = "kotlin.Throwable";
               return var10000;
            case "kotlin.jvm.internal.IntCompanionObject":
               var10000 = "kotlin.Int.Companion";
               return var10000;
         }

         var10000 = null;
         return var10000;
      }

      private final String simpleNameOf(String type) {
         String var10000;
         switch (type) {
            case "kotlin.jvm.internal.DoubleCompanionObject":
               var10000 = "Companion";
               return var10000;
            case "java.lang.Integer":
               var10000 = "Int";
               return var10000;
            case "java.lang.Cloneable":
               var10000 = "Cloneable";
               return var10000;
            case "java.lang.annotation.Annotation":
               var10000 = "Annotation";
               return var10000;
            case "kotlin.jvm.functions.Function10":
               var10000 = "Function10";
               return var10000;
            case "kotlin.jvm.functions.Function11":
               var10000 = "Function11";
               return var10000;
            case "kotlin.jvm.functions.Function12":
               var10000 = "Function12";
               return var10000;
            case "kotlin.jvm.functions.Function13":
               var10000 = "Function13";
               return var10000;
            case "kotlin.jvm.functions.Function14":
               var10000 = "Function14";
               return var10000;
            case "kotlin.jvm.functions.Function15":
               var10000 = "Function15";
               return var10000;
            case "kotlin.jvm.functions.Function16":
               var10000 = "Function16";
               return var10000;
            case "kotlin.jvm.functions.Function17":
               var10000 = "Function17";
               return var10000;
            case "kotlin.jvm.functions.Function18":
               var10000 = "Function18";
               return var10000;
            case "kotlin.jvm.functions.Function19":
               var10000 = "Function19";
               return var10000;
            case "kotlin.jvm.functions.Function20":
               var10000 = "Function20";
               return var10000;
            case "kotlin.jvm.functions.Function21":
               var10000 = "Function21";
               return var10000;
            case "kotlin.jvm.functions.Function22":
               var10000 = "Function22";
               return var10000;
            case "java.lang.Comparable":
               var10000 = "Comparable";
               return var10000;
            case "java.util.Map":
               var10000 = "Map";
               return var10000;
            case "java.util.Set":
               var10000 = "Set";
               return var10000;
            case "double":
               var10000 = "Double";
               return var10000;
            case "kotlin.jvm.internal.ByteCompanionObject":
               var10000 = "Companion";
               return var10000;
            case "java.lang.CharSequence":
               var10000 = "CharSequence";
               return var10000;
            case "java.util.Collection":
               var10000 = "Collection";
               return var10000;
            case "java.lang.Float":
               var10000 = "Float";
               return var10000;
            case "java.lang.Short":
               var10000 = "Short";
               return var10000;
            case "kotlin.jvm.internal.CharCompanionObject":
               var10000 = "Companion";
               return var10000;
            case "kotlin.jvm.internal.LongCompanionObject":
               var10000 = "Companion";
               return var10000;
            case "java.util.Map$Entry":
               var10000 = "Entry";
               return var10000;
            case "int":
               var10000 = "Int";
               return var10000;
            case "byte":
               var10000 = "Byte";
               return var10000;
            case "char":
               var10000 = "Char";
               return var10000;
            case "long":
               var10000 = "Long";
               return var10000;
            case "boolean":
               var10000 = "Boolean";
               return var10000;
            case "java.util.List":
               var10000 = "List";
               return var10000;
            case "kotlin.jvm.internal.ShortCompanionObject":
               var10000 = "Companion";
               return var10000;
            case "kotlin.jvm.functions.Function0":
               var10000 = "Function0";
               return var10000;
            case "kotlin.jvm.functions.Function1":
               var10000 = "Function1";
               return var10000;
            case "kotlin.jvm.functions.Function2":
               var10000 = "Function2";
               return var10000;
            case "kotlin.jvm.functions.Function3":
               var10000 = "Function3";
               return var10000;
            case "kotlin.jvm.functions.Function4":
               var10000 = "Function4";
               return var10000;
            case "kotlin.jvm.functions.Function5":
               var10000 = "Function5";
               return var10000;
            case "kotlin.jvm.functions.Function6":
               var10000 = "Function6";
               return var10000;
            case "kotlin.jvm.functions.Function7":
               var10000 = "Function7";
               return var10000;
            case "kotlin.jvm.functions.Function8":
               var10000 = "Function8";
               return var10000;
            case "kotlin.jvm.functions.Function9":
               var10000 = "Function9";
               return var10000;
            case "float":
               var10000 = "Float";
               return var10000;
            case "short":
               var10000 = "Short";
               return var10000;
            case "java.lang.Character":
               var10000 = "Char";
               return var10000;
            case "kotlin.jvm.internal.EnumCompanionObject":
               var10000 = "Companion";
               return var10000;
            case "java.lang.Boolean":
               var10000 = "Boolean";
               return var10000;
            case "java.lang.Byte":
               var10000 = "Byte";
               return var10000;
            case "java.lang.Enum":
               var10000 = "Enum";
               return var10000;
            case "java.lang.Long":
               var10000 = "Long";
               return var10000;
            case "kotlin.jvm.internal.FloatCompanionObject":
               var10000 = "Companion";
               return var10000;
            case "java.util.Iterator":
               var10000 = "Iterator";
               return var10000;
            case "java.util.ListIterator":
               var10000 = "ListIterator";
               return var10000;
            case "kotlin.jvm.internal.StringCompanionObject":
               var10000 = "Companion";
               return var10000;
            case "java.lang.Double":
               var10000 = "Double";
               return var10000;
            case "java.lang.Number":
               var10000 = "Number";
               return var10000;
            case "java.lang.Object":
               var10000 = "Any";
               return var10000;
            case "java.lang.String":
               var10000 = "String";
               return var10000;
            case "java.lang.Iterable":
               var10000 = "Iterable";
               return var10000;
            case "kotlin.jvm.internal.BooleanCompanionObject":
               var10000 = "Companion";
               return var10000;
            case "java.lang.Throwable":
               var10000 = "Throwable";
               return var10000;
            case "kotlin.jvm.internal.IntCompanionObject":
               var10000 = "Companion";
               return var10000;
         }

         var10000 = null;
         return var10000;
      }

      @Nullable
      public final String getClassSimpleName(@NotNull Class<?> jClass) {
         Intrinsics.checkNotNullParameter(jClass, "jClass");
         String var10000;
         if (jClass.isAnonymousClass()) {
            var10000 = null;
         } else if (jClass.isLocalClass()) {
            String name = jClass.getSimpleName();
            Method var9 = jClass.getEnclosingMethod();
            if (var9 != null) {
               Method method = var9;
               int var5 = 0;
               Intrinsics.checkNotNull(name);
               var10000 = StringsKt.substringAfter$default(name, method.getName() + '$', (String)null, 2, (Object)null);
               if (var10000 != null) {
                  return var10000;
               }
            }

            Constructor var10 = jClass.getEnclosingConstructor();
            if (var10 != null) {
               Constructor constructor = var10;
               int var6 = 0;
               Intrinsics.checkNotNull(name);
               var10000 = StringsKt.substringAfter$default(name, constructor.getName() + '$', (String)null, 2, (Object)null);
            } else {
               Intrinsics.checkNotNull(name);
               var10000 = StringsKt.substringAfter$default(name, '$', (String)null, 2, (Object)null);
            }
         } else if (jClass.isArray()) {
            Class componentType = jClass.getComponentType();
            if (componentType.isPrimitive()) {
               String var10001 = componentType.getName();
               Intrinsics.checkNotNullExpressionValue(var10001, "getName(...)");
               String var3 = this.simpleNameOf(var10001);
               var10000 = var3 != null ? var3 + "Array" : null;
            } else {
               var10000 = null;
            }

            if (var10000 == null) {
               var10000 = "Array";
            }
         } else {
            String var11 = jClass.getName();
            Intrinsics.checkNotNullExpressionValue(var11, "getName(...)");
            var10000 = this.simpleNameOf(var11);
            if (var10000 == null) {
               var10000 = jClass.getSimpleName();
            }
         }

         return var10000;
      }

      @Nullable
      public final String getClassQualifiedName(@NotNull Class<?> jClass) {
         Intrinsics.checkNotNullParameter(jClass, "jClass");
         String var10000;
         if (jClass.isAnonymousClass()) {
            var10000 = null;
         } else if (jClass.isLocalClass()) {
            var10000 = null;
         } else if (jClass.isArray()) {
            Class componentType = jClass.getComponentType();
            if (componentType.isPrimitive()) {
               String var10001 = componentType.getName();
               Intrinsics.checkNotNullExpressionValue(var10001, "getName(...)");
               String var3 = this.classFqNameOf(var10001);
               var10000 = var3 != null ? var3 + "Array" : null;
            } else {
               var10000 = null;
            }

            if (var10000 == null) {
               var10000 = "kotlin.Array";
            }
         } else {
            String var4 = jClass.getName();
            Intrinsics.checkNotNullExpressionValue(var4, "getName(...)");
            var10000 = this.classFqNameOf(var4);
            if (var10000 == null) {
               var10000 = jClass.getCanonicalName();
            }
         }

         return var10000;
      }

      public final boolean isInstance(@Nullable Object value, @NotNull Class<?> jClass) {
         Intrinsics.checkNotNullParameter(jClass, "jClass");
         Map var10000 = ClassReference.FUNCTION_CLASSES;
         Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.MapsKt__MapsKt.get, V of kotlin.collections.MapsKt__MapsKt.get>");
         Integer var3 = (Integer)var10000.get(jClass);
         if (var3 != null) {
            int arity = ((Number)var3).intValue();
            int var5 = 0;
            return TypeIntrinsics.isFunctionOfArity(value, arity);
         } else {
            Class objectType = jClass.isPrimitive() ? JvmClassMappingKt.getJavaObjectType(JvmClassMappingKt.getKotlinClass(jClass)) : jClass;
            return objectType.isInstance(value);
         }
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
