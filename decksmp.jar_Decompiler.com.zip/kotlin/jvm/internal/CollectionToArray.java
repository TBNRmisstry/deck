package kotlin.jvm.internal;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import kotlin.Deprecated;
import kotlin.DeprecatedSinceKotlin;
import kotlin.Metadata;
import kotlin.jvm.JvmName;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 2, 0},
   k = 2,
   xi = 48,
   d1 = {"\u00002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u001e\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a#\u0010\u0006\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00012\n\u0010\u0007\u001a\u0006\u0012\u0002\b\u00030\bH\u0007¢\u0006\u0004\b\t\u0010\n\u001a5\u0010\u0006\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00012\n\u0010\u0007\u001a\u0006\u0012\u0002\b\u00030\b2\u0010\u0010\u000b\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0002\u0018\u00010\u0001H\u0007¢\u0006\u0004\b\t\u0010\f\u001a~\u0010\r\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00012\n\u0010\u0007\u001a\u0006\u0012\u0002\b\u00030\b2\u0014\u0010\u000e\u001a\u0010\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00010\u000f2\u001a\u0010\u0010\u001a\u0016\u0012\u0004\u0012\u00020\u0005\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00010\u00112(\u0010\u0012\u001a$\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u0001\u0012\u0004\u0012\u00020\u0005\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00010\u0013H\u0082\b¢\u0006\u0002\u0010\u0014\"\u0018\u0010\u0000\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u0001X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0003\"\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0015"},
   d2 = {"EMPTY", "", "", "[Ljava/lang/Object;", "MAX_SIZE", "", "collectionToArray", "collection", "", "toArray", "(Ljava/util/Collection;)[Ljava/lang/Object;", "a", "(Ljava/util/Collection;[Ljava/lang/Object;)[Ljava/lang/Object;", "toArrayImpl", "empty", "Lkotlin/Function0;", "alloc", "Lkotlin/Function1;", "trim", "Lkotlin/Function2;", "(Ljava/util/Collection;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function2;)[Ljava/lang/Object;", "kotlin-stdlib"}
)
@JvmName(
   name = "CollectionToArray"
)
@SourceDebugExtension({"SMAP\nCollectionToArray.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CollectionToArray.kt\nkotlin/jvm/internal/CollectionToArray\n*L\n1#1,88:1\n63#1,22:89\n63#1,22:111\n*S KotlinDebug\n*F\n+ 1 CollectionToArray.kt\nkotlin/jvm/internal/CollectionToArray\n*L\n22#1:89,22\n37#1:111,22\n*E\n"})
public final class CollectionToArray {
   @NotNull
   private static final Object[] EMPTY = new Object[0];
   private static final int MAX_SIZE = 2147483645;

   /** @deprecated */
   @Deprecated(
      message = "This function will be made internal in a future release"
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.9",
      errorSince = "2.1"
   )
   @JvmName(
      name = "toArray"
   )
   @NotNull
   public static final Object[] toArray(@NotNull Collection<?> collection) {
      Intrinsics.checkNotNullParameter(collection, "collection");
      int $i$f$toArrayImpl = 0;
      int size$iv = collection.size();
      Object[] var10000;
      if (size$iv == 0) {
         int var4 = 0;
         var10000 = EMPTY;
      } else {
         Iterator iter$iv = collection.iterator();
         if (!iter$iv.hasNext()) {
            int result = 0;
            var10000 = EMPTY;
         } else {
            int var6 = 0;
            Object[] result$iv = new Object[size$iv];
            var6 = 0;

            while(true) {
               result$iv[var6++] = iter$iv.next();
               if (var6 >= result$iv.length) {
                  if (!iter$iv.hasNext()) {
                     var10000 = result$iv;
                     break;
                  }

                  int newSize$iv = var6 * 3 + 1 >>> 1;
                  if (newSize$iv <= var6) {
                     if (var6 >= 2147483645) {
                        throw new OutOfMemoryError();
                     }

                     newSize$iv = 2147483645;
                  }

                  var10000 = Arrays.copyOf(result$iv, newSize$iv);
                  Intrinsics.checkNotNullExpressionValue(var10000, "copyOf(...)");
                  result$iv = var10000;
               } else if (!iter$iv.hasNext()) {
                  int var10 = 0;
                  var10000 = Arrays.copyOf(result$iv, var6);
                  Intrinsics.checkNotNullExpressionValue(var10000, "copyOf(...)");
                  break;
               }
            }
         }
      }

      return var10000;
   }

   /** @deprecated */
   @Deprecated(
      message = "This function will be made internal in a future release"
   )
   @DeprecatedSinceKotlin(
      warningSince = "1.9",
      errorSince = "2.1"
   )
   @JvmName(
      name = "toArray"
   )
   @NotNull
   public static final Object[] toArray(@NotNull Collection<?> collection, @Nullable Object[] a) {
      Intrinsics.checkNotNullParameter(collection, "collection");
      if (a == null) {
         throw new NullPointerException();
      } else {
         int $i$f$toArrayImpl = 0;
         int size$iv = collection.size();
         Object[] var10000;
         if (size$iv == 0) {
            int var5 = 0;
            if (a.length > 0) {
               a[0] = null;
            }

            var10000 = a;
         } else {
            Iterator iter$iv = collection.iterator();
            if (!iter$iv.hasNext()) {
               int var12 = 0;
               if (a.length > 0) {
                  a[0] = null;
               }

               var10000 = a;
            } else {
               int var7 = 0;
               if (size$iv <= a.length) {
                  var10000 = a;
               } else {
                  var10000 = Array.newInstance(a.getClass().getComponentType(), size$iv);
                  Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
                  var10000 = var10000;
               }

               Object[] result$iv = var10000;
               int i$iv = 0;

               while(true) {
                  result$iv[i$iv++] = iter$iv.next();
                  if (i$iv >= result$iv.length) {
                     if (!iter$iv.hasNext()) {
                        var10000 = result$iv;
                        break;
                     }

                     var7 = i$iv * 3 + 1 >>> 1;
                     if (var7 <= i$iv) {
                        if (i$iv >= 2147483645) {
                           throw new OutOfMemoryError();
                        }

                        var7 = 2147483645;
                     }

                     Object[] var17 = Arrays.copyOf(result$iv, var7);
                     Intrinsics.checkNotNullExpressionValue(var17, "copyOf(...)");
                     result$iv = var17;
                  } else if (!iter$iv.hasNext()) {
                     int var11 = 0;
                     if (result$iv == a) {
                        a[i$iv] = null;
                        var10000 = a;
                     } else {
                        var10000 = Arrays.copyOf(result$iv, i$iv);
                        Intrinsics.checkNotNullExpressionValue(var10000, "copyOf(...)");
                     }
                     break;
                  }
               }
            }
         }

         return (Object[])var10000;
      }
   }

   private static final Object[] toArrayImpl(Collection<?> collection, Function0<Object[]> empty, Function1<? super Integer, Object[]> alloc, Function2<? super Object[], ? super Integer, Object[]> trim) {
      int $i$f$toArrayImpl = 0;
      int size = collection.size();
      if (size == 0) {
         return empty.invoke();
      } else {
         Iterator iter = collection.iterator();
         if (!iter.hasNext()) {
            return empty.invoke();
         } else {
            Object[] result = alloc.invoke(size);
            int i = 0;

            while(true) {
               result[i++] = iter.next();
               if (i >= result.length) {
                  if (!iter.hasNext()) {
                     return result;
                  }

                  int newSize = i * 3 + 1 >>> 1;
                  if (newSize <= i) {
                     if (i >= 2147483645) {
                        throw new OutOfMemoryError();
                     }

                     newSize = 2147483645;
                  }

                  Object[] var10000 = Arrays.copyOf(result, newSize);
                  Intrinsics.checkNotNullExpressionValue(var10000, "copyOf(...)");
                  result = var10000;
               } else if (!iter.hasNext()) {
                  return trim.invoke(result, i);
               }
            }
         }
      }
   }
}
