package kotlin.jvm;

import java.lang.annotation.Annotation;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.ReplaceWith;
import kotlin.SinceKotlin;
import kotlin.internal.InlineOnly;
import kotlin.jvm.internal.ClassBasedDeclarationContainer;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 2, 0},
   k = 2,
   xi = 48,
   d1 = {"\u00004\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0000\n\u0002\b\u000b\n\u0002\u0010\u000b\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0010\u001b\n\u0002\b\u0004\n\u0002\u0010\u0010\n\u0002\b\u0005\u001a\u001f\u0010\u0014\u001a\u00020\u0015\"\n\b\u0000\u0010\u0002\u0018\u0001*\u00020\t*\u0006\u0012\u0002\b\u00030\u0016¢\u0006\u0002\u0010\u0017\"-\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002*\b\u0012\u0004\u0012\u0002H\u00020\u00038G¢\u0006\f\u0012\u0004\b\u0004\u0010\u0005\u001a\u0004\b\u0006\u0010\u0007\"-\u0010\b\u001a\n\u0012\u0004\u0012\u0002H\u0002\u0018\u00010\u0001\"\b\b\u0000\u0010\u0002*\u00020\t*\b\u0012\u0004\u0012\u0002H\u00020\u00038F¢\u0006\u0006\u001a\u0004\b\n\u0010\u0007\"+\u0010\u000b\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\b\b\u0000\u0010\u0002*\u00020\t*\b\u0012\u0004\u0012\u0002H\u00020\u00038F¢\u0006\u0006\u001a\u0004\b\f\u0010\u0007\"+\u0010\r\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0003\"\b\b\u0000\u0010\u0002*\u00020\t*\b\u0012\u0004\u0012\u0002H\u00020\u00018G¢\u0006\u0006\u001a\u0004\b\u000e\u0010\u000f\"&\u0010\u0010\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\b\b\u0000\u0010\u0002*\u00020\t*\u0002H\u00028Æ\u0002¢\u0006\u0006\u001a\u0004\b\u0006\u0010\u0011\";\u0010\u0010\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00020\u00030\u0001\"\b\b\u0000\u0010\u0002*\u00020\t*\b\u0012\u0004\u0012\u0002H\u00020\u00038Ç\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b\u0012\u0010\u0005\u001a\u0004\b\u0013\u0010\u0007\"'\u0010\u0018\u001a\n\u0012\u0006\b\u0001\u0012\u0002H\u00020\u0003\"\b\b\u0000\u0010\u0002*\u00020\u0019*\u0002H\u00028F¢\u0006\u0006\u001a\u0004\b\u001a\u0010\u001b\";\u0010\u001c\u001a\b\u0012\u0004\u0012\u0002H\u001d0\u0001\"\u000e\b\u0000\u0010\u001d*\b\u0012\u0004\u0012\u0002H\u001d0\u001e*\b\u0012\u0004\u0012\u0002H\u001d0\u001e8Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b\u001f\u0010 \u001a\u0004\b!\u0010\"¨\u0006#"},
   d2 = {"java", "Ljava/lang/Class;", "T", "Lkotlin/reflect/KClass;", "getJavaClass$annotations", "(Lkotlin/reflect/KClass;)V", "getJavaClass", "(Lkotlin/reflect/KClass;)Ljava/lang/Class;", "javaPrimitiveType", "", "getJavaPrimitiveType", "javaObjectType", "getJavaObjectType", "kotlin", "getKotlinClass", "(Ljava/lang/Class;)Lkotlin/reflect/KClass;", "javaClass", "(Ljava/lang/Object;)Ljava/lang/Class;", "getRuntimeClassOfKClassInstance$annotations", "getRuntimeClassOfKClassInstance", "isArrayOf", "", "", "([Ljava/lang/Object;)Z", "annotationClass", "", "getAnnotationClass", "(Ljava/lang/annotation/Annotation;)Lkotlin/reflect/KClass;", "declaringJavaClass", "E", "", "getDeclaringJavaClass$annotations", "(Ljava/lang/Enum;)V", "getDeclaringJavaClass", "(Ljava/lang/Enum;)Ljava/lang/Class;", "kotlin-stdlib"}
)
@JvmName(
   name = "JvmClassMappingKt"
)
public final class JvmClassMappingKt {
   @JvmName(
      name = "getJavaClass"
   )
   @NotNull
   public static final <T> Class<T> getJavaClass(@NotNull KClass<T> $this$java) {
      Intrinsics.checkNotNullParameter($this$java, "<this>");
      Class var10000 = ((ClassBasedDeclarationContainer)$this$java).getJClass();
      Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-java>>");
      return var10000;
   }

   /** @deprecated */
   // $FF: synthetic method
   public static void getJavaClass$annotations(KClass var0) {
   }

   @Nullable
   public static final <T> Class<T> getJavaPrimitiveType(@NotNull KClass<T> $this$javaPrimitiveType) {
      Intrinsics.checkNotNullParameter($this$javaPrimitiveType, "<this>");
      Class thisJClass = ((ClassBasedDeclarationContainer)$this$javaPrimitiveType).getJClass();
      if (thisJClass.isPrimitive()) {
         Intrinsics.checkNotNull(thisJClass, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-javaPrimitiveType>>");
         return thisJClass;
      } else {
         Class var10000;
         if (var2 != null) {
            switch (var2) {
               case "java.lang.Integer":
                  var10000 = Integer.TYPE;
                  return var10000;
               case "java.lang.Float":
                  var10000 = Float.TYPE;
                  return var10000;
               case "java.lang.Short":
                  var10000 = Short.TYPE;
                  return var10000;
               case "java.lang.Character":
                  var10000 = Character.TYPE;
                  return var10000;
               case "java.lang.Boolean":
                  var10000 = Boolean.TYPE;
                  return var10000;
               case "java.lang.Byte":
                  var10000 = Byte.TYPE;
                  return var10000;
               case "java.lang.Long":
                  var10000 = Long.TYPE;
                  return var10000;
               case "java.lang.Void":
                  var10000 = Void.TYPE;
                  return var10000;
               case "java.lang.Double":
                  var10000 = Double.TYPE;
                  return var10000;
            }
         }

         var10000 = null;
         return var10000;
      }
   }

   @NotNull
   public static final <T> Class<T> getJavaObjectType(@NotNull KClass<T> $this$javaObjectType) {
      Intrinsics.checkNotNullParameter($this$javaObjectType, "<this>");
      Class thisJClass = ((ClassBasedDeclarationContainer)$this$javaObjectType).getJClass();
      if (!thisJClass.isPrimitive()) {
         Intrinsics.checkNotNull(thisJClass, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-javaObjectType>>");
         return thisJClass;
      } else {
         Class var10000;
         label52: {
            if (var2 != null) {
               switch (var2) {
                  case "double":
                     var10000 = Double.class;
                     break label52;
                  case "int":
                     var10000 = Integer.class;
                     break label52;
                  case "byte":
                     var10000 = Byte.class;
                     break label52;
                  case "char":
                     var10000 = Character.class;
                     break label52;
                  case "long":
                     var10000 = Long.class;
                     break label52;
                  case "void":
                     var10000 = Void.class;
                     break label52;
                  case "boolean":
                     var10000 = Boolean.class;
                     break label52;
                  case "float":
                     var10000 = Float.class;
                     break label52;
                  case "short":
                     var10000 = Short.class;
                     break label52;
               }
            }

            var10000 = thisJClass;
         }

         Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-javaObjectType>>");
         return var10000;
      }
   }

   @JvmName(
      name = "getKotlinClass"
   )
   @NotNull
   public static final <T> KClass<T> getKotlinClass(@NotNull Class<T> $this$kotlin) {
      Intrinsics.checkNotNullParameter($this$kotlin, "<this>");
      return Reflection.getOrCreateKotlinClass($this$kotlin);
   }

   @NotNull
   public static final <T> Class<T> getJavaClass(@NotNull T $this$javaClass) {
      Intrinsics.checkNotNullParameter($this$javaClass, "<this>");
      int $i$f$getJavaClass = 0;
      Class var10000 = $this$javaClass.getClass();
      Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-javaClass>>");
      return var10000;
   }

   /** @deprecated */
   @JvmName(
      name = "getRuntimeClassOfKClassInstance"
   )
   @NotNull
   public static final <T> Class<KClass<T>> getRuntimeClassOfKClassInstance(@NotNull KClass<T> $this$javaClass) {
      Intrinsics.checkNotNullParameter($this$javaClass, "<this>");
      int $i$f$getRuntimeClassOfKClassInstance = 0;
      Class var10000 = ((Object)$this$javaClass).getClass();
      Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type java.lang.Class<kotlin.reflect.KClass<T of kotlin.jvm.JvmClassMappingKt.<get-javaClass>>>");
      return var10000;
   }

   /** @deprecated */
   // $FF: synthetic method
   @Deprecated(
      message = "Use 'java' property to get Java class corresponding to this Kotlin class or cast this instance to Any if you really want to get the runtime Java class of this implementation of KClass.",
      replaceWith = @ReplaceWith(
   expression = "(this as Any).javaClass",
   imports = {}
),
      level = DeprecationLevel.ERROR
   )
   public static void getRuntimeClassOfKClassInstance$annotations(KClass var0) {
   }

   // $FF: synthetic method
   public static final boolean isArrayOf(Object[] $this$isArrayOf) {
      Intrinsics.checkNotNullParameter($this$isArrayOf, "<this>");
      Intrinsics.reifiedOperationMarker(4, "T");
      return ((Class)Object.class).isAssignableFrom(((Class)$this$isArrayOf.getClass()).getComponentType());
   }

   @NotNull
   public static final <T extends Annotation> KClass<? extends T> getAnnotationClass(@NotNull T $this$annotationClass) {
      Intrinsics.checkNotNullParameter($this$annotationClass, "<this>");
      Class var10000 = $this$annotationClass.annotationType();
      Intrinsics.checkNotNullExpressionValue(var10000, "annotationType(...)");
      KClass var1 = getKotlinClass(var10000);
      Intrinsics.checkNotNull(var1, "null cannot be cast to non-null type kotlin.reflect.KClass<out T of kotlin.jvm.JvmClassMappingKt.<get-annotationClass>>");
      return var1;
   }

   private static final <E extends Enum<E>> Class<E> getDeclaringJavaClass(Enum<E> $this$declaringJavaClass) {
      Intrinsics.checkNotNullParameter($this$declaringJavaClass, "<this>");
      Class var10000 = $this$declaringJavaClass.getDeclaringClass();
      Intrinsics.checkNotNullExpressionValue(var10000, "getDeclaringClass(...)");
      return var10000;
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "1.7"
   )
   @InlineOnly
   public static void getDeclaringJavaClass$annotations(Enum var0) {
   }
}
