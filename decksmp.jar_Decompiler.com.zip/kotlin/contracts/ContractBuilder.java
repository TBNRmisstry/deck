package kotlin.contracts;

import kotlin.Function;
import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.internal.ContractsDsl;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\bg\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H'J\u0012\u0010\u0002\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u0001H'J\b\u0010\u0005\u001a\u00020\u0006H'J&\u0010\u0007\u001a\u00020\b\"\u0004\b\u0000\u0010\t2\f\u0010\n\u001a\b\u0012\u0004\u0012\u0002H\t0\u000b2\b\b\u0002\u0010\f\u001a\u00020\rH'J\u0015\u0010\u000e\u001a\u00020\u000f*\u00020\u00102\u0006\u0010\u0004\u001a\u00020\u0006H§\u0004J!\u0010\u0011\u001a\u00020\u0012\"\u0004\b\u0000\u0010\t*\u00020\u00102\f\u0010\n\u001a\b\u0012\u0004\u0012\u0002H\t0\u000bH§\u0004¨\u0006\u0013"},
   d2 = {"Lkotlin/contracts/ContractBuilder;", "", "returns", "Lkotlin/contracts/Returns;", "value", "returnsNotNull", "Lkotlin/contracts/ReturnsNotNull;", "callsInPlace", "Lkotlin/contracts/CallsInPlace;", "R", "lambda", "Lkotlin/Function;", "kind", "Lkotlin/contracts/InvocationKind;", "implies", "", "", "holdsIn", "Lkotlin/contracts/HoldsIn;", "kotlin-stdlib"}
)
@ContractsDsl
@ExperimentalContracts
@SinceKotlin(
   version = "1.3"
)
public interface ContractBuilder {
   @ContractsDsl
   @NotNull
   Returns returns();

   @ContractsDsl
   @NotNull
   Returns returns(@Nullable Object var1);

   @ContractsDsl
   @NotNull
   ReturnsNotNull returnsNotNull();

   @ContractsDsl
   @NotNull
   <R> CallsInPlace callsInPlace(@NotNull Function<? extends R> var1, @NotNull InvocationKind var2);

   @ExperimentalExtendedContracts
   @ContractsDsl
   void implies(boolean var1, @NotNull ReturnsNotNull var2);

   @ExperimentalExtendedContracts
   @ContractsDsl
   @NotNull
   <R> HoldsIn holdsIn(boolean var1, @NotNull Function<? extends R> var2);

   @Metadata(
      mv = {2, 2, 0},
      k = 3,
      xi = 48
   )
   public static final class DefaultImpls {
      // $FF: synthetic method
      public static CallsInPlace callsInPlace$default(ContractBuilder var0, Function var1, InvocationKind var2, int var3, Object var4) {
         if (var4 != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: callsInPlace");
         } else {
            if ((var3 & 2) != 0) {
               var2 = InvocationKind.UNKNOWN;
            }

            return var0.callsInPlace(var1, var2);
         }
      }
   }
}
