package kotlin.contracts;

import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.internal.ContractsDsl;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bg\u0018\u00002\u00020\u0001¨\u0006\u0002"},
   d2 = {"Lkotlin/contracts/ReturnsNotNull;", "Lkotlin/contracts/SimpleEffect;", "kotlin-stdlib"}
)
@ContractsDsl
@ExperimentalContracts
@SinceKotlin(
   version = "1.3"
)
public interface ReturnsNotNull extends SimpleEffect {
}
