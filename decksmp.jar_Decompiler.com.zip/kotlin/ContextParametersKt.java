package kotlin;

@Metadata(
   mv = {2, 2, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/ContextParametersKt__ContextKt", "kotlin/ContextParametersKt__ContextOfKt"}
)
public final class ContextParametersKt extends ContextParametersKt__ContextOfKt {
   private ContextParametersKt() {
   }
}
