package kotlin.concurrent.atomics;

import kotlin.Metadata;

@Metadata(
   mv = {2, 2, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/concurrent/atomics/AtomicArraysKt__AtomicArrays_commonKt", "kotlin/concurrent/atomics/AtomicArraysKt__AtomicArrays_jvmKt"}
)
public final class AtomicArraysKt extends AtomicArraysKt__AtomicArrays_jvmKt {
   private AtomicArraysKt() {
   }
}
