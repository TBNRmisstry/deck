package kotlin.concurrent.atomics;

import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.concurrent.atomic.AtomicLongArray;
import java.util.concurrent.atomic.AtomicReferenceArray;
import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.internal.InlineOnly;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 2, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000B\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0005\u001a\u0011\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u0007¢\u0006\u0002\u0010\u0003\u001a\u0011\u0010\u0004\u001a\u00020\u0002*\u00020\u0001H\u0007¢\u0006\u0002\u0010\u0003\u001a\u0011\u0010\u0000\u001a\u00020\u0005*\u00020\u0006H\u0007¢\u0006\u0002\u0010\u0007\u001a\u0011\u0010\u0004\u001a\u00020\u0006*\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0007\u001a#\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\t0\b\"\u0004\b\u0000\u0010\t*\b\u0012\u0004\u0012\u0002H\t0\nH\u0007¢\u0006\u0002\u0010\u000b\u001a#\u0010\u0004\u001a\b\u0012\u0004\u0012\u0002H\t0\n\"\u0004\b\u0000\u0010\t*\b\u0012\u0004\u0012\u0002H\t0\bH\u0007¢\u0006\u0002\u0010\u000b\u001a>\u0010\f\u001a\u00020\r*\u00020\u00022\u0006\u0010\u000e\u001a\u00020\u000f2\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u000f0\u0011H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0002¢\u0006\u0002\u0010\u0012\u001a>\u0010\u0013\u001a\u00020\u000f*\u00020\u00022\u0006\u0010\u000e\u001a\u00020\u000f2\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u000f0\u0011H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0002¢\u0006\u0002\u0010\u0014\u001a>\u0010\u0015\u001a\u00020\u000f*\u00020\u00022\u0006\u0010\u000e\u001a\u00020\u000f2\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u000f0\u0011H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0002¢\u0006\u0002\u0010\u0014\u001a>\u0010\f\u001a\u00020\r*\u00020\u00062\u0006\u0010\u000e\u001a\u00020\u000f2\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u00160\u0011H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0002¢\u0006\u0002\u0010\u0017\u001a>\u0010\u0013\u001a\u00020\u0016*\u00020\u00062\u0006\u0010\u000e\u001a\u00020\u000f2\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u00160\u0011H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0002¢\u0006\u0002\u0010\u0018\u001a>\u0010\u0015\u001a\u00020\u0016*\u00020\u00062\u0006\u0010\u000e\u001a\u00020\u000f2\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020\u00160\u0011H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0002¢\u0006\u0002\u0010\u0018\u001aJ\u0010\f\u001a\u00020\r\"\u0004\b\u0000\u0010\t*\b\u0012\u0004\u0012\u0002H\t0\n2\u0006\u0010\u000e\u001a\u00020\u000f2\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u0002H\t\u0012\u0004\u0012\u0002H\t0\u0011H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0002¢\u0006\u0002\u0010\u0019\u001aJ\u0010\u0013\u001a\u0002H\t\"\u0004\b\u0000\u0010\t*\b\u0012\u0004\u0012\u0002H\t0\n2\u0006\u0010\u000e\u001a\u00020\u000f2\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u0002H\t\u0012\u0004\u0012\u0002H\t0\u0011H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0002¢\u0006\u0002\u0010\u001a\u001aJ\u0010\u0015\u001a\u0002H\t\"\u0004\b\u0000\u0010\t*\b\u0012\u0004\u0012\u0002H\t0\n2\u0006\u0010\u000e\u001a\u00020\u000f2\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u0002H\t\u0012\u0004\u0012\u0002H\t0\u0011H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0002¢\u0006\u0002\u0010\u001a\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006\u001b"},
   d2 = {"asJavaAtomicArray", "Ljava/util/concurrent/atomic/AtomicIntegerArray;", "Lkotlin/concurrent/atomics/AtomicIntArray;", "(Ljava/util/concurrent/atomic/AtomicIntegerArray;)Ljava/util/concurrent/atomic/AtomicIntegerArray;", "asKotlinAtomicArray", "Ljava/util/concurrent/atomic/AtomicLongArray;", "Lkotlin/concurrent/atomics/AtomicLongArray;", "(Ljava/util/concurrent/atomic/AtomicLongArray;)Ljava/util/concurrent/atomic/AtomicLongArray;", "Ljava/util/concurrent/atomic/AtomicReferenceArray;", "T", "Lkotlin/concurrent/atomics/AtomicArray;", "(Ljava/util/concurrent/atomic/AtomicReferenceArray;)Ljava/util/concurrent/atomic/AtomicReferenceArray;", "updateAt", "", "index", "", "transform", "Lkotlin/Function1;", "(Ljava/util/concurrent/atomic/AtomicIntegerArray;ILkotlin/jvm/functions/Function1;)V", "updateAndFetchAt", "(Ljava/util/concurrent/atomic/AtomicIntegerArray;ILkotlin/jvm/functions/Function1;)I", "fetchAndUpdateAt", "", "(Ljava/util/concurrent/atomic/AtomicLongArray;ILkotlin/jvm/functions/Function1;)V", "(Ljava/util/concurrent/atomic/AtomicLongArray;ILkotlin/jvm/functions/Function1;)J", "(Ljava/util/concurrent/atomic/AtomicReferenceArray;ILkotlin/jvm/functions/Function1;)V", "(Ljava/util/concurrent/atomic/AtomicReferenceArray;ILkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "kotlin-stdlib"},
   xs = "kotlin/concurrent/atomics/AtomicArraysKt"
)
class AtomicArraysKt__AtomicArrays_jvmKt extends AtomicArraysKt__AtomicArrays_commonKt {
   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   @NotNull
   public static final AtomicIntegerArray asJavaAtomicArray(@NotNull AtomicIntegerArray $this$asJavaAtomicArray) {
      Intrinsics.checkNotNullParameter($this$asJavaAtomicArray, "<this>");
      return $this$asJavaAtomicArray;
   }

   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   @NotNull
   public static final AtomicIntegerArray asKotlinAtomicArray(@NotNull AtomicIntegerArray $this$asKotlinAtomicArray) {
      Intrinsics.checkNotNullParameter($this$asKotlinAtomicArray, "<this>");
      return $this$asKotlinAtomicArray;
   }

   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   @NotNull
   public static final AtomicLongArray asJavaAtomicArray(@NotNull AtomicLongArray $this$asJavaAtomicArray) {
      Intrinsics.checkNotNullParameter($this$asJavaAtomicArray, "<this>");
      return $this$asJavaAtomicArray;
   }

   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   @NotNull
   public static final AtomicLongArray asKotlinAtomicArray(@NotNull AtomicLongArray $this$asKotlinAtomicArray) {
      Intrinsics.checkNotNullParameter($this$asKotlinAtomicArray, "<this>");
      return $this$asKotlinAtomicArray;
   }

   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   @NotNull
   public static final <T> AtomicReferenceArray<T> asJavaAtomicArray(@NotNull AtomicReferenceArray<T> $this$asJavaAtomicArray) {
      Intrinsics.checkNotNullParameter($this$asJavaAtomicArray, "<this>");
      return $this$asJavaAtomicArray;
   }

   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalAtomicApi
   @NotNull
   public static final <T> AtomicReferenceArray<T> asKotlinAtomicArray(@NotNull AtomicReferenceArray<T> $this$asKotlinAtomicArray) {
      Intrinsics.checkNotNullParameter($this$asKotlinAtomicArray, "<this>");
      return $this$asKotlinAtomicArray;
   }

   @SinceKotlin(
      version = "2.2"
   )
   @ExperimentalAtomicApi
   @InlineOnly
   private static final void updateAt(AtomicIntegerArray $this$updateAt, int index, Function1<? super Integer, Integer> transform) {
      Intrinsics.checkNotNullParameter($this$updateAt, "<this>");
      Intrinsics.checkNotNullParameter(transform, "transform");
      AtomicIntegerArray var3 = $this$updateAt;

      int var4;
      int var5;
      do {
         var4 = var3.get(index);
         var5 = ((Number)transform.invoke(var4)).intValue();
      } while(!var3.compareAndSet(index, var4, var5));

   }

   @SinceKotlin(
      version = "2.2"
   )
   @ExperimentalAtomicApi
   @InlineOnly
   private static final int updateAndFetchAt(AtomicIntegerArray $this$updateAndFetchAt, int index, Function1<? super Integer, Integer> transform) {
      Intrinsics.checkNotNullParameter($this$updateAndFetchAt, "<this>");
      Intrinsics.checkNotNullParameter(transform, "transform");

      int old;
      int var4;
      do {
         old = $this$updateAndFetchAt.get(index);
         var4 = ((Number)transform.invoke(old)).intValue();
      } while(!$this$updateAndFetchAt.compareAndSet(index, old, var4));

      return var4;
   }

   @SinceKotlin(
      version = "2.2"
   )
   @ExperimentalAtomicApi
   @InlineOnly
   private static final int fetchAndUpdateAt(AtomicIntegerArray $this$fetchAndUpdateAt, int index, Function1<? super Integer, Integer> transform) {
      Intrinsics.checkNotNullParameter($this$fetchAndUpdateAt, "<this>");
      Intrinsics.checkNotNullParameter(transform, "transform");

      int old;
      int var4;
      do {
         old = $this$fetchAndUpdateAt.get(index);
         var4 = ((Number)transform.invoke(old)).intValue();
      } while(!$this$fetchAndUpdateAt.compareAndSet(index, old, var4));

      return old;
   }

   @SinceKotlin(
      version = "2.2"
   )
   @ExperimentalAtomicApi
   @InlineOnly
   private static final void updateAt(AtomicLongArray $this$updateAt, int index, Function1<? super Long, Long> transform) {
      Intrinsics.checkNotNullParameter($this$updateAt, "<this>");
      Intrinsics.checkNotNullParameter(transform, "transform");
      AtomicLongArray var3 = $this$updateAt;

      long var4;
      long var6;
      do {
         var4 = var3.get(index);
         var6 = ((Number)transform.invoke(var4)).longValue();
      } while(!var3.compareAndSet(index, var4, var6));

   }

   @SinceKotlin(
      version = "2.2"
   )
   @ExperimentalAtomicApi
   @InlineOnly
   private static final long updateAndFetchAt(AtomicLongArray $this$updateAndFetchAt, int index, Function1<? super Long, Long> transform) {
      Intrinsics.checkNotNullParameter($this$updateAndFetchAt, "<this>");
      Intrinsics.checkNotNullParameter(transform, "transform");

      long old;
      long var5;
      do {
         old = $this$updateAndFetchAt.get(index);
         var5 = ((Number)transform.invoke(old)).longValue();
      } while(!$this$updateAndFetchAt.compareAndSet(index, old, var5));

      return var5;
   }

   @SinceKotlin(
      version = "2.2"
   )
   @ExperimentalAtomicApi
   @InlineOnly
   private static final long fetchAndUpdateAt(AtomicLongArray $this$fetchAndUpdateAt, int index, Function1<? super Long, Long> transform) {
      Intrinsics.checkNotNullParameter($this$fetchAndUpdateAt, "<this>");
      Intrinsics.checkNotNullParameter(transform, "transform");

      long old;
      long var5;
      do {
         old = $this$fetchAndUpdateAt.get(index);
         var5 = ((Number)transform.invoke(old)).longValue();
      } while(!$this$fetchAndUpdateAt.compareAndSet(index, old, var5));

      return old;
   }

   @SinceKotlin(
      version = "2.2"
   )
   @ExperimentalAtomicApi
   @InlineOnly
   private static final <T> void updateAt(AtomicReferenceArray<T> $this$updateAt, int index, Function1<? super T, ? extends T> transform) {
      Intrinsics.checkNotNullParameter($this$updateAt, "<this>");
      Intrinsics.checkNotNullParameter(transform, "transform");
      AtomicReferenceArray var3 = $this$updateAt;

      Object var4;
      Object var5;
      do {
         var4 = var3.get(index);
         var5 = transform.invoke(var4);
      } while(!var3.compareAndSet(index, var4, var5));

   }

   @SinceKotlin(
      version = "2.2"
   )
   @ExperimentalAtomicApi
   @InlineOnly
   private static final <T> T updateAndFetchAt(AtomicReferenceArray<T> $this$updateAndFetchAt, int index, Function1<? super T, ? extends T> transform) {
      Intrinsics.checkNotNullParameter($this$updateAndFetchAt, "<this>");
      Intrinsics.checkNotNullParameter(transform, "transform");

      Object old;
      Object var4;
      do {
         old = $this$updateAndFetchAt.get(index);
         var4 = transform.invoke(old);
      } while(!$this$updateAndFetchAt.compareAndSet(index, old, var4));

      return (T)var4;
   }

   @SinceKotlin(
      version = "2.2"
   )
   @ExperimentalAtomicApi
   @InlineOnly
   private static final <T> T fetchAndUpdateAt(AtomicReferenceArray<T> $this$fetchAndUpdateAt, int index, Function1<? super T, ? extends T> transform) {
      Intrinsics.checkNotNullParameter($this$fetchAndUpdateAt, "<this>");
      Intrinsics.checkNotNullParameter(transform, "transform");

      Object old;
      Object var4;
      do {
         old = $this$fetchAndUpdateAt.get(index);
         var4 = transform.invoke(old);
      } while(!$this$fetchAndUpdateAt.compareAndSet(index, old, var4));

      return (T)old;
   }

   public AtomicArraysKt__AtomicArrays_jvmKt() {
   }
}
