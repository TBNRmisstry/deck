package kotlin.time;

import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.NotImplementedError;
import kotlin.ReplaceWith;
import kotlin.SinceKotlin;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u0000 '2\b\u0012\u0004\u0012\u00020\u00000\u00012\u00060\u0002j\u0002`\u0003:\u0001'B\u0019\b\u0000\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\u0006\u0010\u000e\u001a\u00020\u0005J\u0018\u0010\u000f\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\u0011H\u0086\u0002¢\u0006\u0004\b\u0012\u0010\u0013J\u0018\u0010\u0014\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\u0011H\u0086\u0002¢\u0006\u0004\b\u0015\u0010\u0013J\u0018\u0010\u0014\u001a\u00020\u00112\u0006\u0010\u0016\u001a\u00020\u0000H\u0086\u0002¢\u0006\u0004\b\u0017\u0010\u0018J\u0011\u0010\u0019\u001a\u00020\u00072\u0006\u0010\u0016\u001a\u00020\u0000H\u0096\u0002J\u0013\u0010\u001a\u001a\u00020\u001b2\b\u0010\u0016\u001a\u0004\u0018\u00010\u001cH\u0096\u0002J\b\u0010\u001d\u001a\u00020\u0007H\u0016J\b\u0010\u001e\u001a\u00020\u001fH\u0016J\b\u0010 \u001a\u00020\u001cH\u0002J\u0019\u0010!\u001a\u00020\"2\n\u0010#\u001a\u00060$j\u0002`%H\u0002¢\u0006\u0002\u0010&R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\r¨\u0006("},
   d2 = {"Lkotlin/time/Instant;", "", "Ljava/io/Serializable;", "Lkotlin/io/Serializable;", "epochSeconds", "", "nanosecondsOfSecond", "", "<init>", "(JI)V", "getEpochSeconds", "()J", "getNanosecondsOfSecond", "()I", "toEpochMilliseconds", "plus", "duration", "Lkotlin/time/Duration;", "plus-LRDsOJo", "(J)Lkotlin/time/Instant;", "minus", "minus-LRDsOJo", "other", "minus-UwyO8pc", "(Lkotlin/time/Instant;)J", "compareTo", "equals", "", "", "hashCode", "toString", "", "writeReplace", "readObject", "", "input", "Ljava/io/ObjectInputStream;", "Lkotlin/internal/ReadObjectParameterType;", "(Ljava/io/ObjectInputStream;)V", "Companion", "kotlin-stdlib"}
)
@SinceKotlin(
   version = "2.1"
)
@ExperimentalTime
@SourceDebugExtension({"SMAP\nInstant.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Instant.kt\nkotlin/time/Instant\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Instant.kt\nkotlin/time/InstantKt\n+ 4 Duration.kt\nkotlin/time/Duration\n*L\n1#1,864:1\n1#2:865\n803#3,14:866\n786#3,6:880\n803#3,14:886\n786#3,6:900\n786#3,6:907\n548#4:906\n*S KotlinDebug\n*F\n+ 1 Instant.kt\nkotlin/time/Instant\n*L\n150#1:866,14\n153#1:880,6\n161#1:886,14\n164#1:900,6\n188#1:907,6\n184#1:906\n*E\n"})
public final class Instant implements Comparable<Instant>, Serializable {
   @NotNull
   public static final Companion Companion = new Companion((DefaultConstructorMarker)null);
   private final long epochSeconds;
   private final int nanosecondsOfSecond;
   @NotNull
   private static final Instant MIN = new Instant(-31557014167219200L, 0);
   @NotNull
   private static final Instant MAX = new Instant(31556889864403199L, 999999999);

   public Instant(long epochSeconds, int nanosecondsOfSecond) {
      this.epochSeconds = epochSeconds;
      this.nanosecondsOfSecond = nanosecondsOfSecond;
      long var4 = this.epochSeconds;
      if (!(-31557014167219200L <= var4 ? var4 < 31556889864403200L : false)) {
         int var5 = 0;
         String var6 = "Instant exceeds minimum or maximum instant";
         throw new IllegalArgumentException(var6.toString());
      }
   }

   public final long getEpochSeconds() {
      return this.epochSeconds;
   }

   public final int getNanosecondsOfSecond() {
      return this.nanosecondsOfSecond;
   }

   public final long toEpochMilliseconds() {
      if (this.epochSeconds >= 0L) {
         long a$iv = this.epochSeconds;
         long b$iv = 1000L;
         int $i$f$safeMultiplyOrElse = 0;
         long var25;
         if (b$iv == 1L) {
            var25 = a$iv;
         } else if (a$iv == 1L) {
            var25 = b$iv;
         } else if (a$iv != 0L && b$iv != 0L) {
            long total$iv = a$iv * b$iv;
            if (total$iv / b$iv != a$iv || a$iv == Long.MIN_VALUE && b$iv == -1L || b$iv == Long.MIN_VALUE && a$iv == -1L) {
               int var23 = 0;
               return Long.MAX_VALUE;
            }

            var25 = total$iv;
         } else {
            var25 = 0L;
         }

         long millis = var25;
         b$iv = (long)(this.nanosecondsOfSecond / 1000000);
         $i$f$safeMultiplyOrElse = 0;
         long sum$iv = millis + b$iv;
         if ((millis ^ sum$iv) < 0L && (millis ^ b$iv) >= 0L) {
            int var24 = 0;
            return Long.MAX_VALUE;
         } else {
            return sum$iv;
         }
      } else {
         long a$iv = this.epochSeconds + 1L;
         long b$iv = 1000L;
         int $i$f$safeMultiplyOrElse = 0;
         long var10000;
         if (b$iv == 1L) {
            var10000 = a$iv;
         } else if (a$iv == 1L) {
            var10000 = b$iv;
         } else if (a$iv != 0L && b$iv != 0L) {
            long total$iv = a$iv * b$iv;
            if (total$iv / b$iv != a$iv || a$iv == Long.MIN_VALUE && b$iv == -1L || b$iv == Long.MIN_VALUE && a$iv == -1L) {
               int var10 = 0;
               return Long.MIN_VALUE;
            }

            var10000 = total$iv;
         } else {
            var10000 = 0L;
         }

         long millis = var10000;
         b$iv = (long)(this.nanosecondsOfSecond / 1000000 - 1000);
         $i$f$safeMultiplyOrElse = 0;
         long sum$iv = millis + b$iv;
         if ((millis ^ sum$iv) < 0L && (millis ^ b$iv) >= 0L) {
            int var22 = 0;
            return Long.MIN_VALUE;
         } else {
            return sum$iv;
         }
      }
   }

   @NotNull
   public final Instant plus_LRDsOJo/* $FF was: plus-LRDsOJo*/(long var1) {
      int var5 = 0;
      long var10000 = Duration.getInWholeSeconds-impl(var1);
      int nanosecondsToAdd = Duration.getNanosecondsComponent-impl(var1);
      long secondsToAdd = var10000;
      int var9 = 0;
      if (secondsToAdd == 0L && nanosecondsToAdd == 0) {
         return this;
      } else {
         long a$iv = this.epochSeconds;
         int $i$f$safeAddOrElse = 0;
         long sum$iv = a$iv + secondsToAdd;
         if ((a$iv ^ sum$iv) < 0L && (a$iv ^ secondsToAdd) >= 0L) {
            int var17 = 0;
            return Duration.isPositive-impl(var1) ? MAX : MIN;
         } else {
            int nanoAdjustment = this.nanosecondsOfSecond + nanosecondsToAdd;
            return Companion.fromEpochSeconds(sum$iv, nanoAdjustment);
         }
      }
   }

   @NotNull
   public final Instant minus_LRDsOJo/* $FF was: minus-LRDsOJo*/(long var1) {
      return this.plus-LRDsOJo(Duration.unaryMinus-UwyO8pc(var1));
   }

   public final long minus_UwyO8pc/* $FF was: minus-UwyO8pc*/(@NotNull Instant other) {
      Intrinsics.checkNotNullParameter(other, "other");
      Duration.Companion var10000 = Duration.Companion;
      long var2 = DurationKt.toDuration(this.epochSeconds - other.epochSeconds, DurationUnit.SECONDS);
      Duration.Companion var10001 = Duration.Companion;
      return Duration.plus-LRDsOJo(var2, DurationKt.toDuration(this.nanosecondsOfSecond - other.nanosecondsOfSecond, DurationUnit.NANOSECONDS));
   }

   public int compareTo(@NotNull Instant other) {
      Intrinsics.checkNotNullParameter(other, "other");
      int s = Intrinsics.compare(this.epochSeconds, other.epochSeconds);
      return s != 0 ? s : Intrinsics.compare(this.nanosecondsOfSecond, other.nanosecondsOfSecond);
   }

   public boolean equals(@Nullable Object other) {
      return this == other || other instanceof Instant && this.epochSeconds == ((Instant)other).epochSeconds && this.nanosecondsOfSecond == ((Instant)other).nanosecondsOfSecond;
   }

   public int hashCode() {
      return Long.hashCode(this.epochSeconds) + 51 * this.nanosecondsOfSecond;
   }

   @NotNull
   public String toString() {
      return InstantKt.access$formatIso(this);
   }

   private final Object writeReplace() {
      return InstantJvmKt.serializedInstant(this);
   }

   private final void readObject(ObjectInputStream input) {
      throw new InvalidObjectException("Deserialization is supported via proxy only");
   }

   @Metadata(
      mv = {2, 2, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\r\n\u0002\b\u000b\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0007J\u000e\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\bJ\u0018\u0010\t\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\b2\b\b\u0002\u0010\u000b\u001a\u00020\bJ\u0016\u0010\t\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\fJ\u000e\u0010\r\u001a\u00020\u00052\u0006\u0010\u000e\u001a\u00020\u000fJ\u0012\u0010\u0010\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u000e\u001a\u00020\u000fH\u0007R\u0011\u0010\u0011\u001a\u00020\u00058F¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0014\u001a\u00020\u00058F¢\u0006\u0006\u001a\u0004\b\u0015\u0010\u0013R\u0014\u0010\u0016\u001a\u00020\u0005X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0013R\u0014\u0010\u0018\u001a\u00020\u0005X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0013¨\u0006\u001a"},
      d2 = {"Lkotlin/time/Instant$Companion;", "", "<init>", "()V", "now", "Lkotlin/time/Instant;", "fromEpochMilliseconds", "epochMilliseconds", "", "fromEpochSeconds", "epochSeconds", "nanosecondAdjustment", "", "parse", "input", "", "parseOrNull", "DISTANT_PAST", "getDISTANT_PAST", "()Lkotlin/time/Instant;", "DISTANT_FUTURE", "getDISTANT_FUTURE", "MIN", "getMIN$kotlin_stdlib", "MAX", "getMAX$kotlin_stdlib", "kotlin-stdlib"}
   )
   @SourceDebugExtension({"SMAP\nInstant.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Instant.kt\nkotlin/time/Instant$Companion\n+ 2 Instant.kt\nkotlin/time/InstantKt\n*L\n1#1,864:1\n786#2,6:865\n*S KotlinDebug\n*F\n+ 1 Instant.kt\nkotlin/time/Instant$Companion\n*L\n312#1:865,6\n*E\n"})
   public static final class Companion {
      private Companion() {
      }

      /** @deprecated */
      @Deprecated(
         message = "Use Clock.System.now() instead",
         replaceWith = @ReplaceWith(
   expression = "Clock.System.now()",
   imports = {"kotlin.time.Clock"}
),
         level = DeprecationLevel.ERROR
      )
      @NotNull
      public final Instant now() {
         throw new NotImplementedError((String)null, 1, (DefaultConstructorMarker)null);
      }

      @NotNull
      public final Instant fromEpochMilliseconds(long epochMilliseconds) {
         long var7 = 1000L;
         long epochSeconds = epochMilliseconds / var7;
         if ((epochMilliseconds ^ var7) < 0L && epochSeconds * var7 != epochMilliseconds) {
            epochSeconds += -1L;
         }

         long var8 = 1000L;
         long var10 = epochMilliseconds % var8;
         int nanosecondsOfSecond = (int)((var10 + (var8 & ((var10 ^ var8) & (var10 | -var10)) >> 63)) * (long)1000000);
         return epochSeconds < -31557014167219200L ? this.getMIN$kotlin_stdlib() : (epochSeconds > 31556889864403199L ? this.getMAX$kotlin_stdlib() : this.fromEpochSeconds(epochSeconds, nanosecondsOfSecond));
      }

      @NotNull
      public final Instant fromEpochSeconds(long epochSeconds, long nanosecondAdjustment) {
         long var11 = 1000000000L;
         long var13 = nanosecondAdjustment / var11;
         if ((nanosecondAdjustment ^ var11) < 0L && var13 * var11 != nanosecondAdjustment) {
            var13 += -1L;
         }

         int $i$f$safeAddOrElse = 0;
         long sum$iv = epochSeconds + var13;
         if ((epochSeconds ^ sum$iv) < 0L && (epochSeconds ^ var13) >= 0L) {
            int var14 = 0;
            return epochSeconds > 0L ? Instant.Companion.getMAX$kotlin_stdlib() : Instant.Companion.getMIN$kotlin_stdlib();
         } else {
            long seconds = sum$iv;
            Instant var10000;
            if (sum$iv < -31557014167219200L) {
               var10000 = this.getMIN$kotlin_stdlib();
            } else if (sum$iv > 31556889864403199L) {
               var10000 = this.getMAX$kotlin_stdlib();
            } else {
               long var10 = 1000000000L;
               sum$iv = nanosecondAdjustment % var10;
               int nanoseconds = (int)(sum$iv + (var10 & ((sum$iv ^ var10) & (sum$iv | -sum$iv)) >> 63));
               var10000 = new Instant(seconds, nanoseconds);
            }

            return var10000;
         }
      }

      // $FF: synthetic method
      public static Instant fromEpochSeconds$default(Companion var0, long var1, long var3, int var5, Object var6) {
         if ((var5 & 2) != 0) {
            var3 = 0L;
         }

         return var0.fromEpochSeconds(var1, var3);
      }

      @NotNull
      public final Instant fromEpochSeconds(long epochSeconds, int nanosecondAdjustment) {
         return this.fromEpochSeconds(epochSeconds, (long)nanosecondAdjustment);
      }

      @NotNull
      public final Instant parse(@NotNull CharSequence input) {
         Intrinsics.checkNotNullParameter(input, "input");
         return InstantKt.access$parseIso(input).toInstant();
      }

      @SinceKotlin(
         version = "2.2"
      )
      @Nullable
      public final Instant parseOrNull(@NotNull CharSequence input) {
         Intrinsics.checkNotNullParameter(input, "input");
         return InstantKt.access$parseIso(input).toInstantOrNull();
      }

      @NotNull
      public final Instant getDISTANT_PAST() {
         return this.fromEpochSeconds(-3217862419201L, 999999999);
      }

      @NotNull
      public final Instant getDISTANT_FUTURE() {
         return this.fromEpochSeconds(3093527980800L, 0);
      }

      @NotNull
      public final Instant getMIN$kotlin_stdlib() {
         return Instant.MIN;
      }

      @NotNull
      public final Instant getMAX$kotlin_stdlib() {
         return Instant.MAX;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
