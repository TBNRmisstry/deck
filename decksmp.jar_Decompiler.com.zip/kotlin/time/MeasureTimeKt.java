package kotlin.time;

import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.Unit;
import kotlin.WasExperimental;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 2, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000(\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a,\u0010\u0000\u001a\u00020\u00012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001¢\u0006\u0002\u0010\u0005\u001a0\u0010\u0000\u001a\u00020\u0001*\u00020\u00062\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001¢\u0006\u0002\u0010\u0007\u001a0\u0010\u0000\u001a\u00020\u0001*\u00020\b2\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001¢\u0006\u0002\u0010\t\u001a3\u0010\n\u001a\b\u0012\u0004\u0012\u0002H\f0\u000b\"\u0004\b\u0000\u0010\f2\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u0002H\f0\u0003H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001\u001a7\u0010\n\u001a\b\u0012\u0004\u0012\u0002H\f0\u000b\"\u0004\b\u0000\u0010\f*\u00020\u00062\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u0002H\f0\u0003H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001\u001a7\u0010\n\u001a\b\u0012\u0004\u0012\u0002H\f0\u000b\"\u0004\b\u0000\u0010\f*\u00020\b2\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u0002H\f0\u0003H\u0087\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006\r"},
   d2 = {"measureTime", "Lkotlin/time/Duration;", "block", "Lkotlin/Function0;", "", "(Lkotlin/jvm/functions/Function0;)J", "Lkotlin/time/TimeSource;", "(Lkotlin/time/TimeSource;Lkotlin/jvm/functions/Function0;)J", "Lkotlin/time/TimeSource$Monotonic;", "(Lkotlin/time/TimeSource$Monotonic;Lkotlin/jvm/functions/Function0;)J", "measureTimedValue", "Lkotlin/time/TimedValue;", "T", "kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nmeasureTime.kt\nKotlin\n*S Kotlin\n*F\n+ 1 measureTime.kt\nkotlin/time/MeasureTimeKt\n*L\n1#1,139:1\n63#1,3:140\n135#1,3:143\n*S KotlinDebug\n*F\n+ 1 measureTime.kt\nkotlin/time/MeasureTimeKt\n*L\n24#1:140,3\n95#1:143,3\n*E\n"})
public final class MeasureTimeKt {
   @SinceKotlin(
      version = "1.9"
   )
   @WasExperimental(
      markerClass = {ExperimentalTime.class}
   )
   public static final long measureTime(@NotNull Function0<Unit> block) {
      Intrinsics.checkNotNullParameter(block, "block");
      int $i$f$measureTime = 0;
      TimeSource.Monotonic $this$measureTime$iv = TimeSource.Monotonic.INSTANCE;
      int $i$f$measureTime = 0;
      long mark$iv = $this$measureTime$iv.markNow-z9LOYto();
      block.invoke();
      return TimeSource.Monotonic.ValueTimeMark.elapsedNow-UwyO8pc(mark$iv);
   }

   @SinceKotlin(
      version = "1.9"
   )
   @WasExperimental(
      markerClass = {ExperimentalTime.class}
   )
   public static final long measureTime(@NotNull TimeSource $this$measureTime, @NotNull Function0<Unit> block) {
      Intrinsics.checkNotNullParameter($this$measureTime, "<this>");
      Intrinsics.checkNotNullParameter(block, "block");
      int $i$f$measureTime = 0;
      TimeMark mark = $this$measureTime.markNow();
      block.invoke();
      return mark.elapsedNow-UwyO8pc();
   }

   @SinceKotlin(
      version = "1.9"
   )
   @WasExperimental(
      markerClass = {ExperimentalTime.class}
   )
   public static final long measureTime(@NotNull TimeSource.Monotonic $this$measureTime, @NotNull Function0<Unit> block) {
      Intrinsics.checkNotNullParameter($this$measureTime, "<this>");
      Intrinsics.checkNotNullParameter(block, "block");
      int $i$f$measureTime = 0;
      long mark = $this$measureTime.markNow-z9LOYto();
      block.invoke();
      return TimeSource.Monotonic.ValueTimeMark.elapsedNow-UwyO8pc(mark);
   }

   @SinceKotlin(
      version = "1.9"
   )
   @WasExperimental(
      markerClass = {ExperimentalTime.class}
   )
   @NotNull
   public static final <T> TimedValue<T> measureTimedValue(@NotNull Function0<? extends T> block) {
      Intrinsics.checkNotNullParameter(block, "block");
      int $i$f$measureTimedValue = 0;
      TimeSource.Monotonic $this$measureTimedValue$iv = TimeSource.Monotonic.INSTANCE;
      int $i$f$measureTimedValue = 0;
      long mark$iv = $this$measureTimedValue$iv.markNow-z9LOYto();
      Object result$iv = block.invoke();
      return new TimedValue<T>(result$iv, TimeSource.Monotonic.ValueTimeMark.elapsedNow-UwyO8pc(mark$iv), (DefaultConstructorMarker)null);
   }

   @SinceKotlin(
      version = "1.9"
   )
   @WasExperimental(
      markerClass = {ExperimentalTime.class}
   )
   @NotNull
   public static final <T> TimedValue<T> measureTimedValue(@NotNull TimeSource $this$measureTimedValue, @NotNull Function0<? extends T> block) {
      Intrinsics.checkNotNullParameter($this$measureTimedValue, "<this>");
      Intrinsics.checkNotNullParameter(block, "block");
      int $i$f$measureTimedValue = 0;
      TimeMark mark = $this$measureTimedValue.markNow();
      Object result = block.invoke();
      return new TimedValue<T>(result, mark.elapsedNow-UwyO8pc(), (DefaultConstructorMarker)null);
   }

   @SinceKotlin(
      version = "1.9"
   )
   @WasExperimental(
      markerClass = {ExperimentalTime.class}
   )
   @NotNull
   public static final <T> TimedValue<T> measureTimedValue(@NotNull TimeSource.Monotonic $this$measureTimedValue, @NotNull Function0<? extends T> block) {
      Intrinsics.checkNotNullParameter($this$measureTimedValue, "<this>");
      Intrinsics.checkNotNullParameter(block, "block");
      int $i$f$measureTimedValue = 0;
      long mark = $this$measureTimedValue.markNow-z9LOYto();
      Object result = block.invoke();
      return new TimedValue<T>(result, TimeSource.Monotonic.ValueTimeMark.elapsedNow-UwyO8pc(mark), (DefaultConstructorMarker)null);
   }
}
