package kotlin.time;

import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.WasExperimental;
import kotlin.jvm.internal.SourceDebugExtension;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0006\u001a\u00020\u0005H\u0014J\u0018\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0086\u0002¢\u0006\u0004\b\u000b\u0010\fJ\u0017\u0010\r\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0002¢\u0006\u0004\b\u000e\u0010\fR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u000f"},
   d2 = {"Lkotlin/time/TestTimeSource;", "Lkotlin/time/AbstractLongTimeSource;", "<init>", "()V", "reading", "", "read", "plusAssign", "", "duration", "Lkotlin/time/Duration;", "plusAssign-LRDsOJo", "(J)V", "overflow", "overflow-LRDsOJo", "kotlin-stdlib"}
)
@SinceKotlin(
   version = "1.9"
)
@WasExperimental(
   markerClass = {ExperimentalTime.class}
)
@SourceDebugExtension({"SMAP\nTimeSources.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TimeSources.kt\nkotlin/time/TestTimeSource\n+ 2 longSaturatedMath.kt\nkotlin/time/LongSaturatedMathKt\n*L\n1#1,210:1\n80#2:211\n80#2:212\n*S KotlinDebug\n*F\n+ 1 TimeSources.kt\nkotlin/time/TestTimeSource\n*L\n184#1:211\n191#1:212\n*E\n"})
public final class TestTimeSource extends AbstractLongTimeSource {
   private long reading;

   public TestTimeSource() {
      super(DurationUnit.NANOSECONDS);
      this.markNow();
   }

   protected long read() {
      return this.reading;
   }

   public final void plusAssign_LRDsOJo/* $FF was: plusAssign-LRDsOJo*/(long var1) {
      long longDelta = Duration.toLong-impl(var1, this.getUnit());
      int $i$f$isSaturated = 0;
      if ((longDelta - 1L | 1L) != Long.MAX_VALUE) {
         long newReading = this.reading + longDelta;
         if ((this.reading ^ longDelta) >= 0L && (this.reading ^ newReading) < 0L) {
            this.overflow-LRDsOJo(var1);
         }

         this.reading = newReading;
      } else {
         long half = Duration.div-UwyO8pc(var1, 2);
         long $this$isSaturated$iv = Duration.toLong-impl(half, this.getUnit());
         int $i$f$isSaturated = 0;
         if (($this$isSaturated$iv - 1L | 1L) != Long.MAX_VALUE) {
            $this$isSaturated$iv = this.reading;

            try {
               this.plusAssign-LRDsOJo(half);
               this.plusAssign-LRDsOJo(Duration.minus-LRDsOJo(var1, half));
            } catch (IllegalStateException e) {
               this.reading = $this$isSaturated$iv;
               throw e;
            }
         } else {
            this.overflow-LRDsOJo(var1);
         }
      }

   }

   private final void overflow_LRDsOJo/* $FF was: overflow-LRDsOJo*/(long var1) {
      throw new IllegalStateException("TestTimeSource will overflow if its reading " + this.reading + DurationUnitKt.shortName(this.getUnit()) + " is advanced by " + Duration.toString-impl(var1) + '.');
   }
}
