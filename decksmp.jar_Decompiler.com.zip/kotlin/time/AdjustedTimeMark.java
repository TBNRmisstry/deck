package kotlin.time;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000e\b\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0001\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0004\b\u0005\u0010\u0006J\u000f\u0010\f\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\r\u0010\nJ\u0018\u0010\u000e\u001a\u00020\u00012\u0006\u0010\u000f\u001a\u00020\u0004H\u0096\u0002¢\u0006\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0002\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0013\u0010\u0003\u001a\u00020\u0004¢\u0006\n\n\u0002\u0010\u000b\u001a\u0004\b\t\u0010\n¨\u0006\u0012"},
   d2 = {"Lkotlin/time/AdjustedTimeMark;", "Lkotlin/time/TimeMark;", "mark", "adjustment", "Lkotlin/time/Duration;", "<init>", "(Lkotlin/time/TimeMark;JLkotlin/jvm/internal/DefaultConstructorMarker;)V", "getMark", "()Lkotlin/time/TimeMark;", "getAdjustment-UwyO8pc", "()J", "J", "elapsedNow", "elapsedNow-UwyO8pc", "plus", "duration", "plus-LRDsOJo", "(J)Lkotlin/time/TimeMark;", "kotlin-stdlib"}
)
final class AdjustedTimeMark implements TimeMark {
   @NotNull
   private final TimeMark mark;
   private final long adjustment;

   private AdjustedTimeMark(TimeMark mark, long adjustment) {
      Intrinsics.checkNotNullParameter(mark, "mark");
      super();
      this.mark = mark;
      this.adjustment = adjustment;
   }

   @NotNull
   public final TimeMark getMark() {
      return this.mark;
   }

   public final long getAdjustment_UwyO8pc/* $FF was: getAdjustment-UwyO8pc*/() {
      return this.adjustment;
   }

   public long elapsedNow_UwyO8pc/* $FF was: elapsedNow-UwyO8pc*/() {
      return Duration.minus-LRDsOJo(this.mark.elapsedNow-UwyO8pc(), this.adjustment);
   }

   @NotNull
   public TimeMark plus_LRDsOJo/* $FF was: plus-LRDsOJo*/(long var1) {
      return new AdjustedTimeMark(this.mark, Duration.plus-LRDsOJo(this.adjustment, var1), (DefaultConstructorMarker)null);
   }

   // $FF: synthetic method
   public AdjustedTimeMark(TimeMark mark, long adjustment, DefaultConstructorMarker $constructor_marker) {
      this(mark, adjustment);
   }
}
