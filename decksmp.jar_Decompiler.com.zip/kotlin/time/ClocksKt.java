package kotlin.time;

import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.jvm.JvmName;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 2, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u0014\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u0019\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0004H\u0007¢\u0006\u0002\b\u0005¨\u0006\u0006"},
   d2 = {"asClock", "Lkotlin/time/Clock;", "Lkotlin/time/TimeSource;", "origin", "Lkotlin/time/Instant;", "fromTimeSource", "kotlin-stdlib"}
)
public final class ClocksKt {
   @SinceKotlin(
      version = "2.2"
   )
   @ExperimentalTime
   @JvmName(
      name = "fromTimeSource"
   )
   @NotNull
   public static final Clock fromTimeSource(@NotNull TimeSource $this$asClock, @NotNull final Instant origin) {
      Intrinsics.checkNotNullParameter($this$asClock, "<this>");
      Intrinsics.checkNotNullParameter(origin, "origin");
      return new Clock($this$asClock) {
         private final TimeMark startMark;

         {
            this.startMark = $receiver.markNow();
         }

         public Instant now() {
            return origin.plus-LRDsOJo(this.startMark.elapsedNow-UwyO8pc());
         }
      };
   }
}
