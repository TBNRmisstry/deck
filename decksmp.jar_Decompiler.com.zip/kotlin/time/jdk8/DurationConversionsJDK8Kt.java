package kotlin.time.jdk8;

import java.time.Duration;
import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.internal.InlineOnly;
import kotlin.jvm.JvmName;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.time.DurationKt;
import kotlin.time.DurationUnit;

@Metadata(
   mv = {2, 2, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u001a\u0012\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u0087\b¢\u0006\u0002\u0010\u0003\u001a\u0014\u0010\u0004\u001a\u00020\u0002*\u00020\u0001H\u0087\b¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"},
   d2 = {"toKotlinDuration", "Lkotlin/time/Duration;", "Ljava/time/Duration;", "(Ljava/time/Duration;)J", "toJavaDuration", "toJavaDuration-LRDsOJo", "(J)Ljava/time/Duration;", "kotlin-stdlib-jdk8"},
   pn = "kotlin.time"
)
@JvmName(
   name = "DurationConversionsJDK8Kt"
)
@SourceDebugExtension({"SMAP\nDurationConversions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DurationConversions.kt\nkotlin/time/jdk8/DurationConversionsJDK8Kt\n+ 2 Duration.kt\nkotlin/time/Duration\n*L\n1#1,33:1\n548#2:34\n*S KotlinDebug\n*F\n+ 1 DurationConversions.kt\nkotlin/time/jdk8/DurationConversionsJDK8Kt\n*L\n33#1:34\n*E\n"})
public final class DurationConversionsJDK8Kt {
   @SinceKotlin(
      version = "1.6"
   )
   @InlineOnly
   private static final long toKotlinDuration(Duration $this$toKotlinDuration) {
      Intrinsics.checkNotNullParameter($this$toKotlinDuration, "<this>");
      return kotlin.time.Duration.plus-LRDsOJo(DurationKt.toDuration($this$toKotlinDuration.getSeconds(), DurationUnit.SECONDS), DurationKt.toDuration($this$toKotlinDuration.getNano(), DurationUnit.NANOSECONDS));
   }

   @SinceKotlin(
      version = "1.6"
   )
   @InlineOnly
   private static final Duration toJavaDuration_LRDsOJo/* $FF was: toJavaDuration-LRDsOJo*/(long var0) {
      int var4 = 0;
      long var10000 = kotlin.time.Duration.getInWholeSeconds-impl(var0);
      int nanoseconds = kotlin.time.Duration.getNanosecondsComponent-impl(var0);
      long seconds = var10000;
      int var8 = 0;
      Duration var9 = Duration.ofSeconds(seconds, (long)nanoseconds);
      Intrinsics.checkNotNullExpressionValue(var9, "toComponents-impl(...)");
      return var9;
   }
}
