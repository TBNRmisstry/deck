package kotlin.time.jdk8;

import java.time.Instant;
import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.jvm.JvmName;
import kotlin.jvm.internal.Intrinsics;
import kotlin.time.ExperimentalTime;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 2, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\f\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u0007\u001a\f\u0010\u0003\u001a\u00020\u0002*\u00020\u0001H\u0007¨\u0006\u0004"},
   d2 = {"toJavaInstant", "Ljava/time/Instant;", "Lkotlin/time/Instant;", "toKotlinInstant", "kotlin-stdlib-jdk8"},
   pn = "kotlin.time"
)
@JvmName(
   name = "InstantConversionsJDK8Kt"
)
public final class InstantConversionsJDK8Kt {
   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalTime
   @NotNull
   public static final Instant toJavaInstant(@NotNull kotlin.time.Instant $this$toJavaInstant) {
      Intrinsics.checkNotNullParameter($this$toJavaInstant, "<this>");
      Instant var10000 = Instant.ofEpochSecond($this$toJavaInstant.getEpochSeconds(), (long)$this$toJavaInstant.getNanosecondsOfSecond());
      Intrinsics.checkNotNullExpressionValue(var10000, "ofEpochSecond(...)");
      return var10000;
   }

   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalTime
   @NotNull
   public static final kotlin.time.Instant toKotlinInstant(@NotNull Instant $this$toKotlinInstant) {
      Intrinsics.checkNotNullParameter($this$toKotlinInstant, "<this>");
      return kotlin.time.Instant.Companion.fromEpochSeconds($this$toKotlinInstant.getEpochSecond(), $this$toKotlinInstant.getNano());
   }
}
