package kotlin.time;

import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.WasExperimental;
import kotlin.jvm.JvmInline;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\bg\u0018\u0000 \u00062\u00020\u0001:\u0003\u0004\u0005\u0006J\b\u0010\u0002\u001a\u00020\u0003H&¨\u0006\u0007"},
   d2 = {"Lkotlin/time/TimeSource;", "", "markNow", "Lkotlin/time/TimeMark;", "WithComparableMarks", "Monotonic", "Companion", "kotlin-stdlib"}
)
@SinceKotlin(
   version = "1.9"
)
@WasExperimental(
   markerClass = {ExperimentalTime.class}
)
public interface TimeSource {
   @NotNull
   Companion Companion = TimeSource.Companion.$$INSTANCE;

   @NotNull
   TimeMark markNow();

   @Metadata(
      mv = {2, 2, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001\nB\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0004\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u0006\u0010\u0007J\b\u0010\b\u001a\u00020\tH\u0016¨\u0006\u000b"},
      d2 = {"Lkotlin/time/TimeSource$Monotonic;", "Lkotlin/time/TimeSource$WithComparableMarks;", "<init>", "()V", "markNow", "Lkotlin/time/TimeSource$Monotonic$ValueTimeMark;", "markNow-z9LOYto", "()J", "toString", "", "ValueTimeMark", "kotlin-stdlib"}
   )
   public static final class Monotonic implements WithComparableMarks {
      @NotNull
      public static final Monotonic INSTANCE = new Monotonic();

      private Monotonic() {
      }

      public long markNow_z9LOYto/* $FF was: markNow-z9LOYto*/() {
         return MonotonicTimeSource.INSTANCE.markNow-z9LOYto();
      }

      @NotNull
      public String toString() {
         return MonotonicTimeSource.INSTANCE.toString();
      }

      @JvmInline
      @Metadata(
         mv = {2, 2, 0},
         k = 1,
         xi = 48,
         d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0087@\u0018\u00002\u00020\u0001B\u0015\b\u0000\u0012\n\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004¢\u0006\u0004\b\u0005\u0010\u0006J\u000f\u0010\b\u001a\u00020\tH\u0016¢\u0006\u0004\b\n\u0010\u0006J\u0018\u0010\u000b\u001a\u00020\u00002\u0006\u0010\f\u001a\u00020\tH\u0096\u0002¢\u0006\u0004\b\r\u0010\u000eJ\u0018\u0010\u000f\u001a\u00020\u00002\u0006\u0010\f\u001a\u00020\tH\u0096\u0002¢\u0006\u0004\b\u0010\u0010\u000eJ\u000f\u0010\u0011\u001a\u00020\u0012H\u0016¢\u0006\u0004\b\u0013\u0010\u0014J\u000f\u0010\u0015\u001a\u00020\u0012H\u0016¢\u0006\u0004\b\u0016\u0010\u0014J\u0018\u0010\u000f\u001a\u00020\t2\u0006\u0010\u0017\u001a\u00020\u0001H\u0096\u0002¢\u0006\u0004\b\u0018\u0010\u0019J\u0018\u0010\u000f\u001a\u00020\t2\u0006\u0010\u0017\u001a\u00020\u0000H\u0086\u0002¢\u0006\u0004\b\u001a\u0010\u000eJ\u0018\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u0017\u001a\u00020\u0000H\u0086\u0002¢\u0006\u0004\b\u001d\u0010\u001eJ\u0013\u0010\u001f\u001a\u00020\u00122\b\u0010\u0017\u001a\u0004\u0018\u00010 HÖ\u0003J\t\u0010!\u001a\u00020\u001cHÖ\u0001J\t\u0010\"\u001a\u00020#HÖ\u0001R\u0014\u0010\u0002\u001a\u00060\u0003j\u0002`\u0004X\u0080\u0004¢\u0006\u0004\n\u0002\u0010\u0007\u0088\u0001\u0002\u0092\u0001\u00060\u0003j\u0002`\u0004¨\u0006$"},
         d2 = {"Lkotlin/time/TimeSource$Monotonic$ValueTimeMark;", "Lkotlin/time/ComparableTimeMark;", "reading", "", "Lkotlin/time/ValueTimeMarkReading;", "constructor-impl", "(J)J", "J", "elapsedNow", "Lkotlin/time/Duration;", "elapsedNow-UwyO8pc", "plus", "duration", "plus-LRDsOJo", "(JJ)J", "minus", "minus-LRDsOJo", "hasPassedNow", "", "hasPassedNow-impl", "(J)Z", "hasNotPassedNow", "hasNotPassedNow-impl", "other", "minus-UwyO8pc", "(JLkotlin/time/ComparableTimeMark;)J", "minus-6eNON_k", "compareTo", "", "compareTo-6eNON_k", "(JJ)I", "equals", "", "hashCode", "toString", "", "kotlin-stdlib"}
      )
      @SinceKotlin(
         version = "1.9"
      )
      @WasExperimental(
         markerClass = {ExperimentalTime.class}
      )
      public static final class ValueTimeMark implements ComparableTimeMark {
         private final long reading;

         public static long elapsedNow_UwyO8pc/* $FF was: elapsedNow-UwyO8pc*/(long var0) {
            return MonotonicTimeSource.INSTANCE.elapsedFrom-6eNON_k(var0);
         }

         public long elapsedNow_UwyO8pc/* $FF was: elapsedNow-UwyO8pc*/() {
            return elapsedNow-UwyO8pc(this.reading);
         }

         public static long plus_LRDsOJo/* $FF was: plus-LRDsOJo*/(long var0, long var2) {
            return MonotonicTimeSource.INSTANCE.adjustReading-6QKq23U(var0, var2);
         }

         public long plus_LRDsOJo/* $FF was: plus-LRDsOJo*/(long duration) {
            return plus-LRDsOJo(this.reading, duration);
         }

         public static long minus_LRDsOJo/* $FF was: minus-LRDsOJo*/(long var0, long var2) {
            return MonotonicTimeSource.INSTANCE.adjustReading-6QKq23U(var0, Duration.unaryMinus-UwyO8pc(var2));
         }

         public long minus_LRDsOJo/* $FF was: minus-LRDsOJo*/(long duration) {
            return minus-LRDsOJo(this.reading, duration);
         }

         public static boolean hasPassedNow_impl/* $FF was: hasPassedNow-impl*/(long var0) {
            return !Duration.isNegative-impl(elapsedNow-UwyO8pc(var0));
         }

         public boolean hasPassedNow() {
            return hasPassedNow-impl(this.reading);
         }

         public static boolean hasNotPassedNow_impl/* $FF was: hasNotPassedNow-impl*/(long var0) {
            return Duration.isNegative-impl(elapsedNow-UwyO8pc(var0));
         }

         public boolean hasNotPassedNow() {
            return hasNotPassedNow-impl(this.reading);
         }

         public static long minus_UwyO8pc/* $FF was: minus-UwyO8pc*/(long var0, @NotNull ComparableTimeMark other) {
            Intrinsics.checkNotNullParameter(other, "other");
            if (!(other instanceof ValueTimeMark)) {
               throw new IllegalArgumentException("Subtracting or comparing time marks from different time sources is not possible: " + toString-impl(var0) + " and " + other);
            } else {
               return minus-6eNON_k(var0, ((ValueTimeMark)other).unbox-impl());
            }
         }

         public long minus_UwyO8pc/* $FF was: minus-UwyO8pc*/(@NotNull ComparableTimeMark other) {
            Intrinsics.checkNotNullParameter(other, "other");
            return minus-UwyO8pc(this.reading, other);
         }

         public static final long minus_6eNON_k/* $FF was: minus-6eNON_k*/(long var0, long var2) {
            return MonotonicTimeSource.INSTANCE.differenceBetween-fRLX17w(var0, var2);
         }

         public static final int compareTo_6eNON_k/* $FF was: compareTo-6eNON_k*/(long var0, long var2) {
            return Duration.compareTo-LRDsOJo(minus-6eNON_k(var0, var2), Duration.Companion.getZERO-UwyO8pc());
         }

         public static String toString_impl/* $FF was: toString-impl*/(long var0) {
            return "ValueTimeMark(reading=" + var0 + ')';
         }

         public String toString() {
            return toString-impl(this.reading);
         }

         public static int hashCode_impl/* $FF was: hashCode-impl*/(long var0) {
            return Long.hashCode(var0);
         }

         public int hashCode() {
            return hashCode-impl(this.reading);
         }

         public static boolean equals_impl/* $FF was: equals-impl*/(long var0, Object other) {
            if (!(other instanceof ValueTimeMark)) {
               return false;
            } else {
               long var3 = ((ValueTimeMark)other).unbox-impl();
               return var0 == var3;
            }
         }

         public boolean equals(Object other) {
            return equals-impl(this.reading, other);
         }

         public static int compareTo_impl/* $FF was: compareTo-impl*/(long var0, @NotNull ComparableTimeMark other) {
            Intrinsics.checkNotNullParameter(other, "other");
            return box-impl(var0).compareTo(other);
         }

         // $FF: synthetic method
         private ValueTimeMark(long reading) {
            this.reading = reading;
         }

         public static long constructor_impl/* $FF was: constructor-impl*/(long reading) {
            return reading;
         }

         // $FF: synthetic method
         public static final ValueTimeMark box_impl/* $FF was: box-impl*/(long v) {
            return new ValueTimeMark(v);
         }

         // $FF: synthetic method
         public final long unbox_impl/* $FF was: unbox-impl*/() {
            return this.reading;
         }

         public static final boolean equals_impl0/* $FF was: equals-impl0*/(long p1, long p2) {
            return p1 == p2;
         }
      }
   }

   @Metadata(
      mv = {2, 2, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"},
      d2 = {"Lkotlin/time/TimeSource$Companion;", "", "<init>", "()V", "kotlin-stdlib"}
   )
   public static final class Companion {
      // $FF: synthetic field
      static final Companion $$INSTANCE = new Companion();

      private Companion() {
      }
   }

   @Metadata(
      mv = {2, 2, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bg\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H&¨\u0006\u0004"},
      d2 = {"Lkotlin/time/TimeSource$WithComparableMarks;", "Lkotlin/time/TimeSource;", "markNow", "Lkotlin/time/ComparableTimeMark;", "kotlin-stdlib"}
   )
   @SinceKotlin(
      version = "1.9"
   )
   @WasExperimental(
      markerClass = {ExperimentalTime.class}
   )
   public interface WithComparableMarks extends TimeSource {
      @NotNull
      ComparableTimeMark markNow();
   }
}
