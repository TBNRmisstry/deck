package kotlin.time;

import kotlin.Metadata;
import kotlin.SinceKotlin;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\f\bÁ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0006\u001a\u00020\u0005H\u0002J\b\u0010\u0007\u001a\u00020\bH\u0016J\u000f\u0010\t\u001a\u00020\nH\u0016¢\u0006\u0004\b\u000b\u0010\fJ\u0015\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\n¢\u0006\u0004\b\u0010\u0010\u0011J\u001d\u0010\u0012\u001a\u00020\u000e2\u0006\u0010\u0013\u001a\u00020\n2\u0006\u0010\u0014\u001a\u00020\n¢\u0006\u0004\b\u0015\u0010\u0016J\u001d\u0010\u0017\u001a\u00020\n2\u0006\u0010\u000f\u001a\u00020\n2\u0006\u0010\u0018\u001a\u00020\u000e¢\u0006\u0004\b\u0019\u0010\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001a"},
   d2 = {"Lkotlin/time/MonotonicTimeSource;", "Lkotlin/time/TimeSource$WithComparableMarks;", "<init>", "()V", "zero", "", "read", "toString", "", "markNow", "Lkotlin/time/TimeSource$Monotonic$ValueTimeMark;", "markNow-z9LOYto", "()J", "elapsedFrom", "Lkotlin/time/Duration;", "timeMark", "elapsedFrom-6eNON_k", "(J)J", "differenceBetween", "one", "another", "differenceBetween-fRLX17w", "(JJ)J", "adjustReading", "duration", "adjustReading-6QKq23U", "kotlin-stdlib"}
)
@SinceKotlin(
   version = "1.3"
)
public final class MonotonicTimeSource implements TimeSource.WithComparableMarks {
   @NotNull
   public static final MonotonicTimeSource INSTANCE = new MonotonicTimeSource();
   private static final long zero = System.nanoTime();

   private MonotonicTimeSource() {
   }

   private final long read() {
      return System.nanoTime() - zero;
   }

   @NotNull
   public String toString() {
      return "TimeSource(System.nanoTime())";
   }

   public long markNow_z9LOYto/* $FF was: markNow-z9LOYto*/() {
      return TimeSource.Monotonic.ValueTimeMark.constructor-impl(this.read());
   }

   public final long elapsedFrom_6eNON_k/* $FF was: elapsedFrom-6eNON_k*/(long var1) {
      return LongSaturatedMathKt.saturatingDiff(this.read(), var1, DurationUnit.NANOSECONDS);
   }

   public final long differenceBetween_fRLX17w/* $FF was: differenceBetween-fRLX17w*/(long var1, long var3) {
      return LongSaturatedMathKt.saturatingOriginsDiff(var1, var3, DurationUnit.NANOSECONDS);
   }

   public final long adjustReading_6QKq23U/* $FF was: adjustReading-6QKq23U*/(long var1, long var3) {
      return TimeSource.Monotonic.ValueTimeMark.constructor-impl(LongSaturatedMathKt.saturatingAdd-NuflL3o(var1, DurationUnit.NANOSECONDS, var3));
   }
}
