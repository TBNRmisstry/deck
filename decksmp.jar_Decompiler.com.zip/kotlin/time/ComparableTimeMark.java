package kotlin.time;

import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.WasExperimental;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\u0010\u0000\n\u0002\b\u0002\bg\u0018\u00002\u00020\u00012\b\u0012\u0004\u0012\u00020\u00000\u0002J\u0018\u0010\u0003\u001a\u00020\u00002\u0006\u0010\u0004\u001a\u00020\u0005H¦\u0002¢\u0006\u0004\b\u0006\u0010\u0007J\u0018\u0010\b\u001a\u00020\u00002\u0006\u0010\u0004\u001a\u00020\u0005H\u0096\u0002¢\u0006\u0004\b\t\u0010\u0007J\u0018\u0010\b\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u0000H¦\u0002¢\u0006\u0004\b\u000b\u0010\fJ\u0011\u0010\r\u001a\u00020\u000e2\u0006\u0010\n\u001a\u00020\u0000H\u0096\u0002J\u0013\u0010\u000f\u001a\u00020\u00102\b\u0010\n\u001a\u0004\u0018\u00010\u0011H¦\u0002J\b\u0010\u0012\u001a\u00020\u000eH&¨\u0006\u0013"},
   d2 = {"Lkotlin/time/ComparableTimeMark;", "Lkotlin/time/TimeMark;", "", "plus", "duration", "Lkotlin/time/Duration;", "plus-LRDsOJo", "(J)Lkotlin/time/ComparableTimeMark;", "minus", "minus-LRDsOJo", "other", "minus-UwyO8pc", "(Lkotlin/time/ComparableTimeMark;)J", "compareTo", "", "equals", "", "", "hashCode", "kotlin-stdlib"}
)
@SinceKotlin(
   version = "1.9"
)
@WasExperimental(
   markerClass = {ExperimentalTime.class}
)
public interface ComparableTimeMark extends TimeMark, Comparable<ComparableTimeMark> {
   @NotNull
   ComparableTimeMark plus_LRDsOJo/* $FF was: plus-LRDsOJo*/(long var1);

   @NotNull
   ComparableTimeMark minus_LRDsOJo/* $FF was: minus-LRDsOJo*/(long var1);

   long minus_UwyO8pc/* $FF was: minus-UwyO8pc*/(@NotNull ComparableTimeMark var1);

   int compareTo(@NotNull ComparableTimeMark var1);

   boolean equals(@Nullable Object var1);

   int hashCode();

   @Metadata(
      mv = {2, 2, 0},
      k = 3,
      xi = 48
   )
   public static final class DefaultImpls {
      @NotNull
      public static ComparableTimeMark minus_LRDsOJo/* $FF was: minus-LRDsOJo*/(@NotNull ComparableTimeMark $this, long var1) {
         return $this.plus-LRDsOJo(Duration.unaryMinus-UwyO8pc(var1));
      }

      public static int compareTo(@NotNull ComparableTimeMark $this, @NotNull ComparableTimeMark other) {
         Intrinsics.checkNotNullParameter(other, "other");
         return Duration.compareTo-LRDsOJo($this.minus-UwyO8pc(other), Duration.Companion.getZERO-UwyO8pc());
      }

      public static boolean hasPassedNow(@NotNull ComparableTimeMark $this) {
         return TimeMark.DefaultImpls.hasPassedNow($this);
      }

      public static boolean hasNotPassedNow(@NotNull ComparableTimeMark $this) {
         return TimeMark.DefaultImpls.hasNotPassedNow($this);
      }
   }
}
