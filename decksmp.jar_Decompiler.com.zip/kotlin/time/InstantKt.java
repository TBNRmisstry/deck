package kotlin.time;

import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.internal.InlineOnly;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 2, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000F\n\u0000\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\r\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\b\f\n\u0002\u0010\u0015\n\u0002\b\u0006\u001a\u0010\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0003\u001a\u0010\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0002H\u0003\u001a'\u0010\u0017\u001a\u00020\t2\u0006\u0010\u0018\u001a\u00020\t2\u0006\u0010\u0019\u001a\u00020\t2\f\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u001c0\u001bH\u0082\b\u001a'\u0010\u001d\u001a\u00020\t2\u0006\u0010\u0018\u001a\u00020\t2\u0006\u0010\u0019\u001a\u00020\t2\f\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u001c0\u001bH\u0082\b\u001a\u0010\u0010%\u001a\u00020\u00012\u0006\u0010&\u001a\u00020\u0015H\u0000\u001a\u0014\u0010'\u001a\u00020\u0015*\u00020\u00152\u0006\u0010%\u001a\u00020\u0001H\u0002\u001a\u0014\u0010-\u001a\u00020\u0012*\u00020\u00102\u0006\u0010.\u001a\u00020\u0015H\u0002\"\u001f\u0010\u0000\u001a\u00020\u0001*\u00020\u00028Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b\u0003\u0010\u0004\u001a\u0004\b\u0000\u0010\u0005\"\u001f\u0010\u0006\u001a\u00020\u0001*\u00020\u00028Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b\u0007\u0010\u0004\u001a\u0004\b\u0006\u0010\u0005\"\u000e\u0010\b\u001a\u00020\tX\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\n\u001a\u00020\tX\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u000b\u001a\u00020\tX\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\f\u001a\u00020\tX\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0014\u001a\u00020\u0015X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0016\u001a\u00020\u0015X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u001e\u001a\u00020\u0015X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\u001f\u001a\u00020\u0015X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010 \u001a\u00020\u0015X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010!\u001a\u00020\u0015X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010\"\u001a\u00020\u0015X\u0080T¢\u0006\u0002\n\u0000\"\u000e\u0010#\u001a\u00020\u0015X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010$\u001a\u00020\u0015X\u0082T¢\u0006\u0002\n\u0000\"\u000e\u0010(\u001a\u00020)X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010*\u001a\u00020)X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010+\u001a\u00020)X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010,\u001a\u00020)X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006/"},
   d2 = {"isDistantPast", "", "Lkotlin/time/Instant;", "isDistantPast$annotations", "(Lkotlin/time/Instant;)V", "(Lkotlin/time/Instant;)Z", "isDistantFuture", "isDistantFuture$annotations", "DISTANT_PAST_SECONDS", "", "DISTANT_FUTURE_SECONDS", "MIN_SECOND", "MAX_SECOND", "parseIso", "Lkotlin/time/InstantParseResult;", "isoString", "", "formatIso", "", "instant", "DAYS_PER_CYCLE", "", "DAYS_0000_TO_1970", "safeAddOrElse", "a", "b", "action", "Lkotlin/Function0;", "", "safeMultiplyOrElse", "SECONDS_PER_HOUR", "SECONDS_PER_MINUTE", "HOURS_PER_DAY", "SECONDS_PER_DAY", "NANOS_PER_SECOND", "NANOS_PER_MILLI", "MILLIS_PER_SECOND", "isLeapYear", "year", "monthLength", "POWERS_OF_TEN", "", "asciiDigitPositionsInIsoStringAfterYear", "colonsInIsoOffsetString", "asciiDigitsInIsoOffsetString", "truncateForErrorMessage", "maxLength", "kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nInstant.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Instant.kt\nkotlin/time/InstantKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Instant.kt\nkotlin/time/UnboundLocalDateTime\n*L\n1#1,864:1\n1#2:865\n479#3,28:866\n*S KotlinDebug\n*F\n+ 1 Instant.kt\nkotlin/time/InstantKt\n*L\n689#1:866,28\n*E\n"})
public final class InstantKt {
   private static final long DISTANT_PAST_SECONDS = -3217862419201L;
   private static final long DISTANT_FUTURE_SECONDS = 3093527980800L;
   private static final long MIN_SECOND = -31557014167219200L;
   private static final long MAX_SECOND = 31556889864403199L;
   private static final int DAYS_PER_CYCLE = 146097;
   private static final int DAYS_0000_TO_1970 = 719528;
   private static final int SECONDS_PER_HOUR = 3600;
   private static final int SECONDS_PER_MINUTE = 60;
   private static final int HOURS_PER_DAY = 24;
   private static final int SECONDS_PER_DAY = 86400;
   public static final int NANOS_PER_SECOND = 1000000000;
   private static final int NANOS_PER_MILLI = 1000000;
   private static final int MILLIS_PER_SECOND = 1000;
   @NotNull
   private static final int[] POWERS_OF_TEN;
   @NotNull
   private static final int[] asciiDigitPositionsInIsoStringAfterYear;
   @NotNull
   private static final int[] colonsInIsoOffsetString;
   @NotNull
   private static final int[] asciiDigitsInIsoOffsetString;

   private static final boolean isDistantPast(Instant $this$isDistantPast) {
      Intrinsics.checkNotNullParameter($this$isDistantPast, "<this>");
      return $this$isDistantPast.compareTo(Instant.Companion.getDISTANT_PAST()) <= 0;
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalTime
   @InlineOnly
   public static void isDistantPast$annotations(Instant var0) {
   }

   private static final boolean isDistantFuture(Instant $this$isDistantFuture) {
      Intrinsics.checkNotNullParameter($this$isDistantFuture, "<this>");
      return $this$isDistantFuture.compareTo(Instant.Companion.getDISTANT_FUTURE()) >= 0;
   }

   /** @deprecated */
   // $FF: synthetic method
   @SinceKotlin(
      version = "2.1"
   )
   @ExperimentalTime
   @InlineOnly
   public static void isDistantFuture$annotations(Instant var0) {
   }

   @ExperimentalTime
   private static final InstantParseResult parseIso(CharSequence isoString) {
      CharSequence s = isoString;
      int i = 0;
      if (isoString.length() == 0) {
         return new InstantParseResult.Failure("An empty string is not a valid Instant", isoString);
      } else {
         char c = isoString.charAt(i);
         char var10000;
         switch (c) {
            case '+':
            case '-':
               ++i;
               var10000 = c;
               break;
            case ',':
            default:
               var10000 = 32;
         }

         char yearSign = (char)var10000;
         c = (char)i;

         int absYear;
         for(absYear = 0; i < s.length(); ++i) {
            char var6 = s.charAt(i);
            if (!('0' <= var6 ? var6 < ':' : false)) {
               break;
            }

            absYear = absYear * 10 + (s.charAt(i) - 48);
         }

         int yearStrLength = i - c;
         if (yearStrLength > 10) {
            return parseIso$parseFailure(isoString, "Expected at most 10 digits for the year number, got " + yearStrLength + " digits");
         } else if (yearStrLength == 10 && Intrinsics.compare(s.charAt(c), 50) >= 0) {
            return parseIso$parseFailure(isoString, "Expected at most 9 digits for the year number or year 1000000000, got " + yearStrLength + " digits");
         } else if (yearStrLength < 4) {
            return parseIso$parseFailure(isoString, "The year number must be padded to 4 digits, got " + yearStrLength + " digits");
         } else if (yearSign == '+' && yearStrLength == 4) {
            return parseIso$parseFailure(isoString, "The '+' sign at the start is only valid for year numbers longer than 4 digits");
         } else if (yearSign == ' ' && yearStrLength != 4) {
            return parseIso$parseFailure(isoString, "A '+' or '-' sign is required for year numbers longer than 4 digits");
         } else {
            int year = yearSign == '-' ? -absYear : absYear;
            if (s.length() < i + 16) {
               return parseIso$parseFailure(isoString, "The input string is too short");
            } else {
               InstantParseResult.Failure it = parseIso$expect(isoString, "'-'", i, InstantKt::parseIso$lambda$0);
               if (it != null) {
                  int minute = 0;
                  return it;
               } else {
                  it = parseIso$expect(isoString, "'-'", i + 3, InstantKt::parseIso$lambda$2);
                  if (it != null) {
                     int j = 0;
                     return it;
                  } else {
                     it = parseIso$expect(isoString, "'T' or 't'", i + 6, InstantKt::parseIso$lambda$4);
                     if (it != null) {
                        int var49 = 0;
                        return it;
                     } else {
                        it = parseIso$expect(isoString, "':'", i + 9, InstantKt::parseIso$lambda$6);
                        if (it != null) {
                           int var48 = 0;
                           return it;
                        } else {
                           it = parseIso$expect(isoString, "':'", i + 12, InstantKt::parseIso$lambda$8);
                           if (it != null) {
                              int var47 = 0;
                              return it;
                           } else {
                              int[] it = asciiDigitPositionsInIsoStringAfterYear;
                              int day = 0;

                              for(int it = it.length; day < it; ++day) {
                                 int j = it[day];
                                 InstantParseResult.Failure it = parseIso$expect(isoString, "an ASCII digit", i + j, InstantKt::parseIso$lambda$10);
                                 if (it != null) {
                                    int $this$toInstant_u24lambda_u240$iv = 0;
                                    return it;
                                 }
                              }

                              int month = parseIso$twoDigitNumber(s, i + 1);
                              day = parseIso$twoDigitNumber(s, i + 4);
                              int hour = parseIso$twoDigitNumber(s, i + 7);
                              int minute = parseIso$twoDigitNumber(s, i + 10);
                              int second = parseIso$twoDigitNumber(s, i + 13);
                              if (s.charAt(i + 15) == '.') {
                                 int fractionStart = i + 16;
                                 i = fractionStart;

                                 int fraction;
                                 for(fraction = 0; i < s.length(); ++i) {
                                    char var16 = s.charAt(i);
                                    if (!('0' <= var16 ? var16 < ':' : false)) {
                                       break;
                                    }

                                    fraction = fraction * 10 + (s.charAt(i) - 48);
                                 }

                                 int fractionStrLength = i - fractionStart;
                                 if (!(1 <= fractionStrLength ? fractionStrLength < 10 : false)) {
                                    return parseIso$parseFailure(isoString, "1..9 digits are supported for the fraction of the second, got " + fractionStrLength + " digits");
                                 }

                                 var10000 = fraction * POWERS_OF_TEN[9 - fractionStrLength];
                              } else {
                                 i += 15;
                                 var10000 = 0;
                              }

                              int nanosecond = var10000;
                              if (i >= s.length()) {
                                 return parseIso$parseFailure(isoString, "The UTC offset at the end of the string is missing");
                              } else {
                                 char sign = s.charAt(i);
                                 label250:
                                 switch (sign) {
                                    case '+':
                                    case '-':
                                       int offsetStrLength = s.length() - i;
                                       if (offsetStrLength > 9) {
                                          StringBuilder var78 = (new StringBuilder()).append("The UTC offset string \"");
                                          int var65 = s.length();
                                          return parseIso$parseFailure(isoString, var78.append(truncateForErrorMessage((CharSequence)s.subSequence(i, var65).toString(), 16)).append("\" is too long").toString());
                                       }

                                       if (offsetStrLength % 3 != 0) {
                                          StringBuilder var77 = (new StringBuilder()).append("Invalid UTC offset string \"");
                                          int var64 = s.length();
                                          return parseIso$parseFailure(isoString, var77.append(s.subSequence(i, var64).toString()).append('"').toString());
                                       }

                                       int[] var17 = colonsInIsoOffsetString;
                                       int offsetMinute = 0;

                                       for(int var19 = var17.length; offsetMinute < var19; ++offsetMinute) {
                                          int j = var17[offsetMinute];
                                          if (i + j >= s.length()) {
                                             break;
                                          }

                                          if (s.charAt(i + j) != ':') {
                                             return parseIso$parseFailure(isoString, "Expected ':' at index " + (i + j) + ", got '" + s.charAt(i + j) + '\'');
                                          }
                                       }

                                       var17 = asciiDigitsInIsoOffsetString;
                                       offsetMinute = 0;
                                       int offsetSecond = var17.length;

                                       while(true) {
                                          if (offsetMinute < offsetSecond) {
                                             int j = var17[offsetMinute];
                                             if (i + j < s.length()) {
                                                char var71 = s.charAt(i + j);
                                                if (!('0' <= var71 ? var71 < ':' : false)) {
                                                   return parseIso$parseFailure(isoString, "Expected an ASCII digit at index " + (i + j) + ", got '" + s.charAt(i + j) + '\'');
                                                }

                                                ++offsetMinute;
                                                continue;
                                             }
                                          }

                                          int offsetHour = parseIso$twoDigitNumber(s, i + 1);
                                          offsetMinute = offsetStrLength > 3 ? parseIso$twoDigitNumber(s, i + 4) : 0;
                                          offsetSecond = offsetStrLength > 6 ? parseIso$twoDigitNumber(s, i + 7) : 0;
                                          if (offsetMinute > 59) {
                                             return parseIso$parseFailure(isoString, "Expected offset-minute-of-hour in 0..59, got " + offsetMinute);
                                          }

                                          if (offsetSecond > 59) {
                                             return parseIso$parseFailure(isoString, "Expected offset-second-of-minute in 0..59, got " + offsetSecond);
                                          }

                                          if (offsetHour > 17 && (offsetHour != 18 || offsetMinute != 0 || offsetSecond != 0)) {
                                             StringBuilder var10001 = (new StringBuilder()).append("Expected an offset in -18:00..+18:00, got ");
                                             int var70 = s.length();
                                             return parseIso$parseFailure(isoString, var10001.append(s.subSequence(i, var70).toString()).toString());
                                          }

                                          var10000 = (offsetHour * 3600 + offsetMinute * 60 + offsetSecond) * (sign == '-' ? -1 : 1);
                                          break label250;
                                       }
                                    case 'Z':
                                    case 'z':
                                       if (s.length() != i + 1) {
                                          return parseIso$parseFailure(isoString, "Extra text after the instant at position " + (i + 1));
                                       }

                                       var10000 = 0;
                                       break;
                                    default:
                                       return parseIso$parseFailure(isoString, "Expected the UTC offset at position " + i + ", got '" + sign + '\'');
                                 }

                                 int offsetSeconds = var10000;
                                 if (!(1 <= month ? month < 13 : false)) {
                                    return parseIso$parseFailure(isoString, "Expected a month number in 1..12, got " + month);
                                 } else if (!(1 <= day ? day <= monthLength(month, isLeapYear(year)) : false)) {
                                    return parseIso$parseFailure(isoString, "Expected a valid day-of-month for month " + month + " of year " + year + ", got " + day);
                                 } else if (hour > 23) {
                                    return parseIso$parseFailure(isoString, "Expected hour in 0..23, got " + hour);
                                 } else if (minute > 59) {
                                    return parseIso$parseFailure(isoString, "Expected minute-of-hour in 0..59, got " + minute);
                                 } else if (second > 59) {
                                    return parseIso$parseFailure(isoString, "Expected second-of-minute in 0..59, got " + second);
                                 } else {
                                    UnboundLocalDateTime $this$toInstant_u24lambda_u240$iv = new UnboundLocalDateTime(year, month, day, hour, minute, second, nanosecond);
                                    int $i$f$toInstant = 0;
                                    int var68 = 0;
                                    int var21 = 0;
                                    long y$iv = (long)$this$toInstant_u24lambda_u240$iv.getYear();
                                    long total$iv = (long)365 * y$iv;
                                    if (y$iv >= 0L) {
                                       total$iv += (y$iv + (long)3) / (long)4 - (y$iv + (long)99) / (long)100 + (y$iv + (long)399) / (long)400;
                                    } else {
                                       total$iv -= y$iv / (long)-4 - y$iv / (long)-100 + y$iv / (long)-400;
                                    }

                                    total$iv += (long)((367 * $this$toInstant_u24lambda_u240$iv.getMonth() - 362) / 12);
                                    total$iv += (long)($this$toInstant_u24lambda_u240$iv.getDay() - 1);
                                    if ($this$toInstant_u24lambda_u240$iv.getMonth() > 2) {
                                       total$iv += -1L;
                                       if (!isLeapYear($this$toInstant_u24lambda_u240$iv.getYear())) {
                                          total$iv += -1L;
                                       }
                                    }

                                    long epochDays$iv = total$iv - (long)719528;
                                    int daySeconds$iv = $this$toInstant_u24lambda_u240$iv.getHour() * 3600 + $this$toInstant_u24lambda_u240$iv.getMinute() * 60 + $this$toInstant_u24lambda_u240$iv.getSecond();
                                    long epochSeconds$iv = epochDays$iv * (long)86400 + (long)daySeconds$iv - (long)offsetSeconds;
                                    int p1 = $this$toInstant_u24lambda_u240$iv.getNanosecond();
                                    int var34 = 0;
                                    return new InstantParseResult.Success(epochSeconds$iv, p1);
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @ExperimentalTime
   private static final String formatIso(Instant instant) {
      StringBuilder var1 = new StringBuilder();
      int var3 = 0;
      UnboundLocalDateTime ldt = UnboundLocalDateTime.Companion.fromInstant(instant);
      int var6 = 0;
      int number = ldt.getYear();
      if (Math.abs(number) < 1000) {
         StringBuilder innerBuilder = new StringBuilder();
         if (number >= 0) {
            Intrinsics.checkNotNullExpressionValue(innerBuilder.append(number + 10000).deleteCharAt(0), "deleteCharAt(...)");
         } else {
            Intrinsics.checkNotNullExpressionValue(innerBuilder.append(number - 10000).deleteCharAt(1), "deleteCharAt(...)");
         }

         var1.append((CharSequence)innerBuilder);
      } else {
         if (number >= 10000) {
            var1.append('+');
         }

         var1.append(number);
      }

      var1.append('-');
      formatIso$lambda$0$appendTwoDigits((Appendable)var1, var1, ldt.getMonth());
      var1.append('-');
      formatIso$lambda$0$appendTwoDigits((Appendable)var1, var1, ldt.getDay());
      var1.append('T');
      formatIso$lambda$0$appendTwoDigits((Appendable)var1, var1, ldt.getHour());
      var1.append(':');
      formatIso$lambda$0$appendTwoDigits((Appendable)var1, var1, ldt.getMinute());
      var1.append(':');
      formatIso$lambda$0$appendTwoDigits((Appendable)var1, var1, ldt.getSecond());
      if (ldt.getNanosecond() != 0) {
         var1.append('.');

         int zerosToStrip;
         for(zerosToStrip = 0; ldt.getNanosecond() % POWERS_OF_TEN[zerosToStrip + 1] == 0; ++zerosToStrip) {
         }

         zerosToStrip -= zerosToStrip % 3;
         int numberToOutput = ldt.getNanosecond() / POWERS_OF_TEN[zerosToStrip];
         String var10 = String.valueOf(numberToOutput + POWERS_OF_TEN[9 - zerosToStrip]);
         number = 1;
         Intrinsics.checkNotNull(var10, "null cannot be cast to non-null type java.lang.String");
         String var10001 = var10.substring(number);
         Intrinsics.checkNotNullExpressionValue(var10001, "substring(...)");
         var1.append(var10001);
      }

      var1.append('Z');
      return var1.toString();
   }

   private static final long safeAddOrElse(long a, long b, Function0 action) {
      int $i$f$safeAddOrElse = 0;
      long sum = a + b;
      if ((a ^ sum) < 0L && (a ^ b) >= 0L) {
         action.invoke();
         throw new KotlinNothingValueException();
      } else {
         return sum;
      }
   }

   private static final long safeMultiplyOrElse(long a, long b, Function0 action) {
      int $i$f$safeMultiplyOrElse = 0;
      if (b == 1L) {
         return a;
      } else if (a == 1L) {
         return b;
      } else if (a != 0L && b != 0L) {
         long total = a * b;
         if (total / b == a && (a != Long.MIN_VALUE || b != -1L) && (b != Long.MIN_VALUE || a != -1L)) {
            return total;
         } else {
            action.invoke();
            throw new KotlinNothingValueException();
         }
      } else {
         return 0L;
      }
   }

   public static final boolean isLeapYear(int year) {
      return (year & 3) == 0 && (year % 100 != 0 || year % 400 == 0);
   }

   private static final int monthLength(int $this$monthLength, boolean isLeapYear) {
      int var10000;
      switch ($this$monthLength) {
         case 2:
            var10000 = isLeapYear ? 29 : 28;
            break;
         case 3:
         case 5:
         case 7:
         case 8:
         case 10:
         default:
            var10000 = 31;
            break;
         case 4:
         case 6:
         case 9:
         case 11:
            var10000 = 30;
      }

      return var10000;
   }

   private static final String truncateForErrorMessage(CharSequence $this$truncateForErrorMessage, int maxLength) {
      return $this$truncateForErrorMessage.length() <= maxLength ? $this$truncateForErrorMessage.toString() : $this$truncateForErrorMessage.subSequence(0, maxLength).toString() + "...";
   }

   private static final InstantParseResult.Failure parseIso$parseFailure(CharSequence $isoString, String error) {
      return new InstantParseResult.Failure(error + " when parsing an Instant from \"" + truncateForErrorMessage($isoString, 64) + '"', $isoString);
   }

   private static final InstantParseResult.Failure parseIso$expect(CharSequence $isoString, String what, int where, Function1<? super Character, Boolean> predicate) {
      char c = $isoString.charAt(where);
      return (Boolean)predicate.invoke(c) ? null : parseIso$parseFailure($isoString, "Expected " + what + ", but got '" + c + "' at position " + where);
   }

   private static final boolean parseIso$lambda$0(char it) {
      return it == '-';
   }

   private static final boolean parseIso$lambda$2(char it) {
      return it == '-';
   }

   private static final boolean parseIso$lambda$4(char it) {
      return it == 'T' || it == 't';
   }

   private static final boolean parseIso$lambda$6(char it) {
      return it == ':';
   }

   private static final boolean parseIso$lambda$8(char it) {
      return it == ':';
   }

   private static final boolean parseIso$lambda$10(char it) {
      return '0' <= it ? it < ':' : false;
   }

   private static final int parseIso$twoDigitNumber(CharSequence s, int index) {
      return (s.charAt(index) - 48) * 10 + (s.charAt(index + 1) - 48);
   }

   private static final void formatIso$lambda$0$appendTwoDigits(Appendable $this$formatIso_u24lambda_u240_u24appendTwoDigits, StringBuilder $this_buildString, int number) {
      if (number < 10) {
         $this$formatIso_u24lambda_u240_u24appendTwoDigits.append('0');
      }

      $this_buildString.append(number);
   }

   // $FF: synthetic method
   public static final String access$formatIso(Instant instant) {
      return formatIso(instant);
   }

   // $FF: synthetic method
   public static final InstantParseResult access$parseIso(CharSequence isoString) {
      return parseIso(isoString);
   }

   // $FF: synthetic method
   public static final String access$truncateForErrorMessage(CharSequence $receiver, int maxLength) {
      return truncateForErrorMessage($receiver, maxLength);
   }

   static {
      int[] var0 = new int[]{1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000};
      POWERS_OF_TEN = var0;
      var0 = new int[]{1, 2, 4, 5, 7, 8, 10, 11, 13, 14};
      asciiDigitPositionsInIsoStringAfterYear = var0;
      var0 = new int[]{3, 6};
      colonsInIsoOffsetString = var0;
      var0 = new int[]{1, 2, 4, 5, 7, 8};
      asciiDigitsInIsoOffsetString = var0;
   }
}
