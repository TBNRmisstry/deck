package kotlin.time;

import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.SinceKotlin;
import kotlin.comparisons.ComparisonsKt;
import kotlin.internal.InlineOnly;
import kotlin.jvm.JvmInline;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.functions.Function5;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.math.MathKt;
import kotlin.ranges.LongRange;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@JvmInline
@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000r\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0000\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0013\n\u0002\u0010\u0006\n\u0002\b\u0019\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b%\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0087@\u0018\u0000 \u0089\u00012\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0002\u0089\u0001B\u0011\b\u0000\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000f\u0010\f\u001a\u00020\rH\u0002¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0010\u001a\u00020\rH\u0002¢\u0006\u0004\b\u0011\u0010\u000fJ\u0010\u0010\u0016\u001a\u00020\u0000H\u0086\u0002¢\u0006\u0004\b\u0017\u0010\u0005J\u0018\u0010\u0018\u001a\u00020\u00002\u0006\u0010\u0019\u001a\u00020\u0000H\u0086\u0002¢\u0006\u0004\b\u001a\u0010\u001bJ\u001f\u0010\u001c\u001a\u00020\u00002\u0006\u0010\u001d\u001a\u00020\u00032\u0006\u0010\u001e\u001a\u00020\u0003H\u0002¢\u0006\u0004\b\u001f\u0010 J\u0018\u0010!\u001a\u00020\u00002\u0006\u0010\u0019\u001a\u00020\u0000H\u0086\u0002¢\u0006\u0004\b\"\u0010\u001bJ\u0018\u0010#\u001a\u00020\u00002\u0006\u0010$\u001a\u00020\tH\u0086\u0002¢\u0006\u0004\b%\u0010&J\u0018\u0010#\u001a\u00020\u00002\u0006\u0010$\u001a\u00020'H\u0086\u0002¢\u0006\u0004\b%\u0010(J\u0018\u0010)\u001a\u00020\u00002\u0006\u0010$\u001a\u00020\tH\u0086\u0002¢\u0006\u0004\b*\u0010&J\u0018\u0010)\u001a\u00020\u00002\u0006\u0010$\u001a\u00020'H\u0086\u0002¢\u0006\u0004\b*\u0010(J\u0018\u0010)\u001a\u00020'2\u0006\u0010\u0019\u001a\u00020\u0000H\u0086\u0002¢\u0006\u0004\b+\u0010,J\u0017\u0010-\u001a\u00020\u00002\u0006\u0010.\u001a\u00020\u0013H\u0000¢\u0006\u0004\b/\u00100J\r\u00101\u001a\u00020\r¢\u0006\u0004\b2\u0010\u000fJ\r\u00103\u001a\u00020\r¢\u0006\u0004\b4\u0010\u000fJ\r\u00105\u001a\u00020\r¢\u0006\u0004\b6\u0010\u000fJ\r\u00107\u001a\u00020\r¢\u0006\u0004\b8\u0010\u000fJ\u0018\u0010;\u001a\u00020\t2\u0006\u0010\u0019\u001a\u00020\u0000H\u0096\u0002¢\u0006\u0004\b<\u0010=J\u009d\u0001\u0010>\u001a\u0002H?\"\u0004\b\u0000\u0010?2u\u0010@\u001aq\u0012\u0013\u0012\u00110\u0003¢\u0006\f\bB\u0012\b\bC\u0012\u0004\b\b(D\u0012\u0013\u0012\u00110\t¢\u0006\f\bB\u0012\b\bC\u0012\u0004\b\b(E\u0012\u0013\u0012\u00110\t¢\u0006\f\bB\u0012\b\bC\u0012\u0004\b\b(F\u0012\u0013\u0012\u00110\t¢\u0006\f\bB\u0012\b\bC\u0012\u0004\b\b(G\u0012\u0013\u0012\u00110\t¢\u0006\f\bB\u0012\b\bC\u0012\u0004\b\b(H\u0012\u0004\u0012\u0002H?0AH\u0086\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001¢\u0006\u0004\bI\u0010JJ\u0088\u0001\u0010>\u001a\u0002H?\"\u0004\b\u0000\u0010?2`\u0010@\u001a\\\u0012\u0013\u0012\u00110\u0003¢\u0006\f\bB\u0012\b\bC\u0012\u0004\b\b(E\u0012\u0013\u0012\u00110\t¢\u0006\f\bB\u0012\b\bC\u0012\u0004\b\b(F\u0012\u0013\u0012\u00110\t¢\u0006\f\bB\u0012\b\bC\u0012\u0004\b\b(G\u0012\u0013\u0012\u00110\t¢\u0006\f\bB\u0012\b\bC\u0012\u0004\b\b(H\u0012\u0004\u0012\u0002H?0KH\u0086\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001¢\u0006\u0004\bI\u0010LJs\u0010>\u001a\u0002H?\"\u0004\b\u0000\u0010?2K\u0010@\u001aG\u0012\u0013\u0012\u00110\u0003¢\u0006\f\bB\u0012\b\bC\u0012\u0004\b\b(F\u0012\u0013\u0012\u00110\t¢\u0006\f\bB\u0012\b\bC\u0012\u0004\b\b(G\u0012\u0013\u0012\u00110\t¢\u0006\f\bB\u0012\b\bC\u0012\u0004\b\b(H\u0012\u0004\u0012\u0002H?0MH\u0086\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001¢\u0006\u0004\bI\u0010NJ^\u0010>\u001a\u0002H?\"\u0004\b\u0000\u0010?26\u0010@\u001a2\u0012\u0013\u0012\u00110\u0003¢\u0006\f\bB\u0012\b\bC\u0012\u0004\b\b(G\u0012\u0013\u0012\u00110\t¢\u0006\f\bB\u0012\b\bC\u0012\u0004\b\b(H\u0012\u0004\u0012\u0002H?0OH\u0086\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0001 \u0001¢\u0006\u0004\bI\u0010PJ\u0015\u0010^\u001a\u00020'2\u0006\u0010.\u001a\u00020\u0013¢\u0006\u0004\b_\u0010`J\u0015\u0010a\u001a\u00020\u00032\u0006\u0010.\u001a\u00020\u0013¢\u0006\u0004\bb\u00100J\u0015\u0010c\u001a\u00020\t2\u0006\u0010.\u001a\u00020\u0013¢\u0006\u0004\bd\u0010eJ\u000f\u0010t\u001a\u00020uH\u0016¢\u0006\u0004\bv\u0010wJA\u0010x\u001a\u00020y*\u00060zj\u0002`{2\u0006\u0010|\u001a\u00020\t2\u0006\u0010}\u001a\u00020\t2\u0006\u0010~\u001a\u00020\t2\u0006\u0010.\u001a\u00020u2\u0006\u0010\u007f\u001a\u00020\rH\u0002¢\u0006\u0006\b\u0080\u0001\u0010\u0081\u0001J!\u0010t\u001a\u00020u2\u0006\u0010.\u001a\u00020\u00132\t\b\u0002\u0010\u0082\u0001\u001a\u00020\t¢\u0006\u0005\bv\u0010\u0083\u0001J\u000f\u0010\u0084\u0001\u001a\u00020u¢\u0006\u0005\b\u0085\u0001\u0010wJ\u0015\u0010\u0086\u0001\u001a\u00020\r2\t\u0010\u0019\u001a\u0005\u0018\u00010\u0087\u0001HÖ\u0003J\n\u0010\u0088\u0001\u001a\u00020\tHÖ\u0001R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00038BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\u0005R\u0015\u0010\b\u001a\u00020\t8Â\u0002X\u0082\u0004¢\u0006\u0006\u001a\u0004\b\n\u0010\u000bR\u0014\u0010\u0012\u001a\u00020\u00138BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0014\u0010\u0015R\u0011\u00109\u001a\u00020\u00008F¢\u0006\u0006\u001a\u0004\b:\u0010\u0005R\u001a\u0010Q\u001a\u00020\t8@X\u0081\u0004¢\u0006\f\u0012\u0004\bR\u0010S\u001a\u0004\bT\u0010\u000bR\u001a\u0010U\u001a\u00020\t8@X\u0081\u0004¢\u0006\f\u0012\u0004\bV\u0010S\u001a\u0004\bW\u0010\u000bR\u001a\u0010X\u001a\u00020\t8@X\u0081\u0004¢\u0006\f\u0012\u0004\bY\u0010S\u001a\u0004\bZ\u0010\u000bR\u001a\u0010[\u001a\u00020\t8@X\u0081\u0004¢\u0006\f\u0012\u0004\b\\\u0010S\u001a\u0004\b]\u0010\u000bR\u0011\u0010f\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\bg\u0010\u0005R\u0011\u0010h\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\bi\u0010\u0005R\u0011\u0010j\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\bk\u0010\u0005R\u0011\u0010l\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\bm\u0010\u0005R\u0011\u0010n\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\bo\u0010\u0005R\u0011\u0010p\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\bq\u0010\u0005R\u0011\u0010r\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\bs\u0010\u0005\u0088\u0001\u0002\u0092\u0001\u00020\u0003\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006\u008a\u0001"},
   d2 = {"Lkotlin/time/Duration;", "", "rawValue", "", "constructor-impl", "(J)J", "value", "getValue-impl", "unitDiscriminator", "", "getUnitDiscriminator-impl", "(J)I", "isInNanos", "", "isInNanos-impl", "(J)Z", "isInMillis", "isInMillis-impl", "storageUnit", "Lkotlin/time/DurationUnit;", "getStorageUnit-impl", "(J)Lkotlin/time/DurationUnit;", "unaryMinus", "unaryMinus-UwyO8pc", "plus", "other", "plus-LRDsOJo", "(JJ)J", "addValuesMixedRanges", "thisMillis", "otherNanos", "addValuesMixedRanges-UwyO8pc", "(JJJ)J", "minus", "minus-LRDsOJo", "times", "scale", "times-UwyO8pc", "(JI)J", "", "(JD)J", "div", "div-UwyO8pc", "div-LRDsOJo", "(JJ)D", "truncateTo", "unit", "truncateTo-UwyO8pc$kotlin_stdlib", "(JLkotlin/time/DurationUnit;)J", "isNegative", "isNegative-impl", "isPositive", "isPositive-impl", "isInfinite", "isInfinite-impl", "isFinite", "isFinite-impl", "absoluteValue", "getAbsoluteValue-UwyO8pc", "compareTo", "compareTo-LRDsOJo", "(JJ)I", "toComponents", "T", "action", "Lkotlin/Function5;", "Lkotlin/ParameterName;", "name", "days", "hours", "minutes", "seconds", "nanoseconds", "toComponents-impl", "(JLkotlin/jvm/functions/Function5;)Ljava/lang/Object;", "Lkotlin/Function4;", "(JLkotlin/jvm/functions/Function4;)Ljava/lang/Object;", "Lkotlin/Function3;", "(JLkotlin/jvm/functions/Function3;)Ljava/lang/Object;", "Lkotlin/Function2;", "(JLkotlin/jvm/functions/Function2;)Ljava/lang/Object;", "hoursComponent", "getHoursComponent$annotations", "()V", "getHoursComponent-impl", "minutesComponent", "getMinutesComponent$annotations", "getMinutesComponent-impl", "secondsComponent", "getSecondsComponent$annotations", "getSecondsComponent-impl", "nanosecondsComponent", "getNanosecondsComponent$annotations", "getNanosecondsComponent-impl", "toDouble", "toDouble-impl", "(JLkotlin/time/DurationUnit;)D", "toLong", "toLong-impl", "toInt", "toInt-impl", "(JLkotlin/time/DurationUnit;)I", "inWholeDays", "getInWholeDays-impl", "inWholeHours", "getInWholeHours-impl", "inWholeMinutes", "getInWholeMinutes-impl", "inWholeSeconds", "getInWholeSeconds-impl", "inWholeMilliseconds", "getInWholeMilliseconds-impl", "inWholeMicroseconds", "getInWholeMicroseconds-impl", "inWholeNanoseconds", "getInWholeNanoseconds-impl", "toString", "", "toString-impl", "(J)Ljava/lang/String;", "appendFractional", "", "Ljava/lang/StringBuilder;", "Lkotlin/text/StringBuilder;", "whole", "fractional", "fractionalSize", "isoZeroes", "appendFractional-impl", "(JLjava/lang/StringBuilder;IIILjava/lang/String;Z)V", "decimals", "(JLkotlin/time/DurationUnit;I)Ljava/lang/String;", "toIsoString", "toIsoString-impl", "equals", "", "hashCode", "Companion", "kotlin-stdlib"}
)
@SinceKotlin(
   version = "1.6"
)
@SourceDebugExtension({"SMAP\nDuration.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Duration.kt\nkotlin/time/Duration\n+ 2 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,1062:1\n37#1:1063\n37#1:1064\n37#1:1065\n37#1:1066\n37#1:1067\n500#1:1068\n517#1:1076\n170#2,6:1069\n1#3:1075\n*S KotlinDebug\n*F\n+ 1 Duration.kt\nkotlin/time/Duration\n*L\n38#1:1063\n39#1:1064\n274#1:1065\n294#1:1066\n478#1:1067\n727#1:1068\n818#1:1076\n769#1:1069,6\n*E\n"})
public final class Duration implements Comparable<Duration> {
   @NotNull
   public static final Companion Companion = new Companion((DefaultConstructorMarker)null);
   private final long rawValue;
   private static final long ZERO = constructor-impl(0L);
   private static final long INFINITE = DurationKt.access$durationOfMillis(4611686018427387903L);
   private static final long NEG_INFINITE = DurationKt.access$durationOfMillis(-4611686018427387903L);

   private static final long getValue_impl/* $FF was: getValue-impl*/(long var0) {
      return var0 >> 1;
   }

   private static final int getUnitDiscriminator_impl/* $FF was: getUnitDiscriminator-impl*/(long var0) {
      int var2 = 0;
      return (int)var0 & 1;
   }

   private static final boolean isInNanos_impl/* $FF was: isInNanos-impl*/(long var0) {
      int var4 = 0;
      return ((int)var0 & 1) == 0;
   }

   private static final boolean isInMillis_impl/* $FF was: isInMillis-impl*/(long var0) {
      int var4 = 0;
      return ((int)var0 & 1) == 1;
   }

   private static final DurationUnit getStorageUnit_impl/* $FF was: getStorageUnit-impl*/(long var0) {
      return isInNanos-impl(var0) ? DurationUnit.NANOSECONDS : DurationUnit.MILLISECONDS;
   }

   public static final long unaryMinus_UwyO8pc/* $FF was: unaryMinus-UwyO8pc*/(long var0) {
      long var10000 = -getValue-impl(var0);
      int var4 = 0;
      return DurationKt.access$durationOf(var10000, (int)var0 & 1);
   }

   public static final long plus_LRDsOJo/* $FF was: plus-LRDsOJo*/(long var0, long var2) {
      if (isInfinite-impl(var0)) {
         if (!isFinite-impl(var2) && (var0 ^ var2) < 0L) {
            throw new IllegalArgumentException("Summing infinite durations of different signs yields an undefined result.");
         } else {
            return var0;
         }
      } else if (isInfinite-impl(var2)) {
         return var2;
      } else {
         int var6 = 0;
         int var10000 = (int)var0 & 1;
         var6 = 0;
         long var8;
         if (var10000 == ((int)var2 & 1)) {
            long result = getValue-impl(var0) + getValue-impl(var2);
            var8 = isInNanos-impl(var0) ? DurationKt.access$durationOfNanosNormalized(result) : DurationKt.access$durationOfMillisNormalized(result);
         } else {
            var8 = isInMillis-impl(var0) ? addValuesMixedRanges-UwyO8pc(var0, getValue-impl(var0), getValue-impl(var2)) : addValuesMixedRanges-UwyO8pc(var0, getValue-impl(var2), getValue-impl(var0));
         }

         return var8;
      }
   }

   private static final long addValuesMixedRanges_UwyO8pc/* $FF was: addValuesMixedRanges-UwyO8pc*/(long var0, long thisMillis, long otherNanos) {
      long otherMillis = DurationKt.access$nanosToMillis(otherNanos);
      long resultMillis = thisMillis + otherMillis;
      long var10000;
      if (-4611686018426L <= resultMillis ? resultMillis < 4611686018427L : false) {
         long otherNanoRemainder = otherNanos - DurationKt.access$millisToNanos(otherMillis);
         var10000 = DurationKt.access$durationOfNanos(DurationKt.access$millisToNanos(resultMillis) + otherNanoRemainder);
      } else {
         var10000 = DurationKt.access$durationOfMillis(RangesKt.coerceIn(resultMillis, -4611686018427387903L, 4611686018427387903L));
      }

      return var10000;
   }

   public static final long minus_LRDsOJo/* $FF was: minus-LRDsOJo*/(long var0, long var2) {
      return plus-LRDsOJo(var0, unaryMinus-UwyO8pc(var2));
   }

   public static final long times_UwyO8pc/* $FF was: times-UwyO8pc*/(long var0, int scale) {
      if (isInfinite-impl(var0)) {
         if (scale == 0) {
            throw new IllegalArgumentException("Multiplying infinite duration by zero yields an undefined result.");
         } else {
            return scale > 0 ? var0 : unaryMinus-UwyO8pc(var0);
         }
      } else if (scale == 0) {
         return ZERO;
      } else {
         long value = getValue-impl(var0);
         long result = value * (long)scale;
         long var10000;
         if (isInNanos-impl(var0)) {
            if (-2147483647L <= value ? value < 2147483648L : false) {
               var10000 = DurationKt.access$durationOfNanos(result);
            } else if (result / (long)scale == value) {
               var10000 = DurationKt.access$durationOfNanosNormalized(result);
            } else {
               long millis = DurationKt.access$nanosToMillis(value);
               long remNanos = value - DurationKt.access$millisToNanos(millis);
               long resultMillis = millis * (long)scale;
               long totalMillis = resultMillis + DurationKt.access$nanosToMillis(remNanos * (long)scale);
               var10000 = resultMillis / (long)scale == millis && (totalMillis ^ resultMillis) >= 0L ? DurationKt.access$durationOfMillis(RangesKt.coerceIn(totalMillis, new LongRange(-4611686018427387903L, 4611686018427387903L))) : (MathKt.getSign(value) * MathKt.getSign(scale) > 0 ? INFINITE : NEG_INFINITE);
            }
         } else {
            var10000 = result / (long)scale == value ? DurationKt.access$durationOfMillis(RangesKt.coerceIn(result, new LongRange(-4611686018427387903L, 4611686018427387903L))) : (MathKt.getSign(value) * MathKt.getSign(scale) > 0 ? INFINITE : NEG_INFINITE);
         }

         return var10000;
      }
   }

   public static final long times_UwyO8pc/* $FF was: times-UwyO8pc*/(long var0, double scale) {
      int intScale = MathKt.roundToInt(scale);
      if ((double)intScale == scale) {
         return times-UwyO8pc(var0, intScale);
      } else {
         DurationUnit unit = getStorageUnit-impl(var0);
         double result = toDouble-impl(var0, unit) * scale;
         return DurationKt.toDuration(result, unit);
      }
   }

   public static final long div_UwyO8pc/* $FF was: div-UwyO8pc*/(long var0, int scale) {
      if (scale == 0) {
         long var10000;
         if (isPositive-impl(var0)) {
            var10000 = INFINITE;
         } else {
            if (!isNegative-impl(var0)) {
               throw new IllegalArgumentException("Dividing zero duration by zero yields an undefined result.");
            }

            var10000 = NEG_INFINITE;
         }

         return var10000;
      } else if (isInNanos-impl(var0)) {
         return DurationKt.access$durationOfNanos(getValue-impl(var0) / (long)scale);
      } else if (isInfinite-impl(var0)) {
         return times-UwyO8pc(var0, MathKt.getSign(scale));
      } else {
         long result = getValue-impl(var0) / (long)scale;
         if (-4611686018426L <= result ? result < 4611686018427L : false) {
            long rem = DurationKt.access$millisToNanos(getValue-impl(var0) - result * (long)scale) / (long)scale;
            return DurationKt.access$durationOfNanos(DurationKt.access$millisToNanos(result) + rem);
         } else {
            return DurationKt.access$durationOfMillis(result);
         }
      }
   }

   public static final long div_UwyO8pc/* $FF was: div-UwyO8pc*/(long var0, double scale) {
      int intScale = MathKt.roundToInt(scale);
      if ((double)intScale == scale && intScale != 0) {
         return div-UwyO8pc(var0, intScale);
      } else {
         DurationUnit unit = getStorageUnit-impl(var0);
         double result = toDouble-impl(var0, unit) / scale;
         return DurationKt.toDuration(result, unit);
      }
   }

   public static final double div_LRDsOJo/* $FF was: div-LRDsOJo*/(long var0, long var2) {
      DurationUnit coarserUnit = (DurationUnit)ComparisonsKt.maxOf((Comparable)getStorageUnit-impl(var0), (Comparable)getStorageUnit-impl(var2));
      return toDouble-impl(var0, coarserUnit) / toDouble-impl(var2, coarserUnit);
   }

   public static final long truncateTo_UwyO8pc$kotlin_stdlib/* $FF was: truncateTo-UwyO8pc$kotlin_stdlib*/(long var0, @NotNull DurationUnit unit) {
      Intrinsics.checkNotNullParameter(unit, "unit");
      DurationUnit storageUnit = getStorageUnit-impl(var0);
      if (unit.compareTo(storageUnit) > 0 && !isInfinite-impl(var0)) {
         long scale = DurationUnitKt.convertDurationUnit(1L, unit, storageUnit);
         long result = getValue-impl(var0) - getValue-impl(var0) % scale;
         return DurationKt.toDuration(result, storageUnit);
      } else {
         return var0;
      }
   }

   public static final boolean isNegative_impl/* $FF was: isNegative-impl*/(long var0) {
      return var0 < 0L;
   }

   public static final boolean isPositive_impl/* $FF was: isPositive-impl*/(long var0) {
      return var0 > 0L;
   }

   public static final boolean isInfinite_impl/* $FF was: isInfinite-impl*/(long var0) {
      return var0 == INFINITE || var0 == NEG_INFINITE;
   }

   public static final boolean isFinite_impl/* $FF was: isFinite-impl*/(long var0) {
      return !isInfinite-impl(var0);
   }

   public static final long getAbsoluteValue_UwyO8pc/* $FF was: getAbsoluteValue-UwyO8pc*/(long var0) {
      return isNegative-impl(var0) ? unaryMinus-UwyO8pc(var0) : var0;
   }

   public static int compareTo_LRDsOJo/* $FF was: compareTo-LRDsOJo*/(long var0, long var2) {
      long compareBits = var0 ^ var2;
      if (compareBits >= 0L && ((int)compareBits & 1) != 0) {
         int var9 = 0;
         int var10000 = (int)var0 & 1;
         var9 = 0;
         int r = var10000 - ((int)var2 & 1);
         return isNegative-impl(var0) ? -r : r;
      } else {
         return Intrinsics.compare(var0, var2);
      }
   }

   public int compareTo_LRDsOJo/* $FF was: compareTo-LRDsOJo*/(long other) {
      return compareTo-LRDsOJo(this.rawValue, other);
   }

   public static final <T> T toComponents_impl/* $FF was: toComponents-impl*/(long var0, @NotNull Function5<? super Long, ? super Integer, ? super Integer, ? super Integer, ? super Integer, ? extends T> action) {
      Intrinsics.checkNotNullParameter(action, "action");
      int var3 = 0;
      return (T)action.invoke(getInWholeDays-impl(var0), getHoursComponent-impl(var0), getMinutesComponent-impl(var0), getSecondsComponent-impl(var0), getNanosecondsComponent-impl(var0));
   }

   public static final <T> T toComponents_impl/* $FF was: toComponents-impl*/(long var0, @NotNull Function4<? super Long, ? super Integer, ? super Integer, ? super Integer, ? extends T> action) {
      Intrinsics.checkNotNullParameter(action, "action");
      int var3 = 0;
      return (T)action.invoke(getInWholeHours-impl(var0), getMinutesComponent-impl(var0), getSecondsComponent-impl(var0), getNanosecondsComponent-impl(var0));
   }

   public static final <T> T toComponents_impl/* $FF was: toComponents-impl*/(long var0, @NotNull Function3<? super Long, ? super Integer, ? super Integer, ? extends T> action) {
      Intrinsics.checkNotNullParameter(action, "action");
      int var3 = 0;
      return (T)action.invoke(getInWholeMinutes-impl(var0), getSecondsComponent-impl(var0), getNanosecondsComponent-impl(var0));
   }

   public static final <T> T toComponents_impl/* $FF was: toComponents-impl*/(long var0, @NotNull Function2<? super Long, ? super Integer, ? extends T> action) {
      Intrinsics.checkNotNullParameter(action, "action");
      int var3 = 0;
      return (T)action.invoke(getInWholeSeconds-impl(var0), getNanosecondsComponent-impl(var0));
   }

   public static final int getHoursComponent_impl/* $FF was: getHoursComponent-impl*/(long var0) {
      return isInfinite-impl(var0) ? 0 : (int)(getInWholeHours-impl(var0) % (long)24);
   }

   /** @deprecated */
   // $FF: synthetic method
   @PublishedApi
   public static void getHoursComponent$annotations() {
   }

   public static final int getMinutesComponent_impl/* $FF was: getMinutesComponent-impl*/(long var0) {
      return isInfinite-impl(var0) ? 0 : (int)(getInWholeMinutes-impl(var0) % (long)60);
   }

   /** @deprecated */
   // $FF: synthetic method
   @PublishedApi
   public static void getMinutesComponent$annotations() {
   }

   public static final int getSecondsComponent_impl/* $FF was: getSecondsComponent-impl*/(long var0) {
      return isInfinite-impl(var0) ? 0 : (int)(getInWholeSeconds-impl(var0) % (long)60);
   }

   /** @deprecated */
   // $FF: synthetic method
   @PublishedApi
   public static void getSecondsComponent$annotations() {
   }

   public static final int getNanosecondsComponent_impl/* $FF was: getNanosecondsComponent-impl*/(long var0) {
      return isInfinite-impl(var0) ? 0 : (isInMillis-impl(var0) ? (int)DurationKt.access$millisToNanos(getValue-impl(var0) % (long)1000) : (int)(getValue-impl(var0) % (long)1000000000));
   }

   /** @deprecated */
   // $FF: synthetic method
   @PublishedApi
   public static void getNanosecondsComponent$annotations() {
   }

   public static final double toDouble_impl/* $FF was: toDouble-impl*/(long var0, @NotNull DurationUnit unit) {
      Intrinsics.checkNotNullParameter(unit, "unit");
      return var0 == INFINITE ? Double.POSITIVE_INFINITY : (var0 == NEG_INFINITE ? Double.NEGATIVE_INFINITY : DurationUnitKt.convertDurationUnit((double)getValue-impl(var0), getStorageUnit-impl(var0), unit));
   }

   public static final long toLong_impl/* $FF was: toLong-impl*/(long var0, @NotNull DurationUnit unit) {
      Intrinsics.checkNotNullParameter(unit, "unit");
      return var0 == INFINITE ? Long.MAX_VALUE : (var0 == NEG_INFINITE ? Long.MIN_VALUE : DurationUnitKt.convertDurationUnit(getValue-impl(var0), getStorageUnit-impl(var0), unit));
   }

   public static final int toInt_impl/* $FF was: toInt-impl*/(long var0, @NotNull DurationUnit unit) {
      Intrinsics.checkNotNullParameter(unit, "unit");
      return (int)RangesKt.coerceIn(toLong-impl(var0, unit), -2147483648L, 2147483647L);
   }

   public static final long getInWholeDays_impl/* $FF was: getInWholeDays-impl*/(long var0) {
      return toLong-impl(var0, DurationUnit.DAYS);
   }

   public static final long getInWholeHours_impl/* $FF was: getInWholeHours-impl*/(long var0) {
      return toLong-impl(var0, DurationUnit.HOURS);
   }

   public static final long getInWholeMinutes_impl/* $FF was: getInWholeMinutes-impl*/(long var0) {
      return toLong-impl(var0, DurationUnit.MINUTES);
   }

   public static final long getInWholeSeconds_impl/* $FF was: getInWholeSeconds-impl*/(long var0) {
      return toLong-impl(var0, DurationUnit.SECONDS);
   }

   public static final long getInWholeMilliseconds_impl/* $FF was: getInWholeMilliseconds-impl*/(long var0) {
      return isInMillis-impl(var0) && isFinite-impl(var0) ? getValue-impl(var0) : toLong-impl(var0, DurationUnit.MILLISECONDS);
   }

   public static final long getInWholeMicroseconds_impl/* $FF was: getInWholeMicroseconds-impl*/(long var0) {
      return toLong-impl(var0, DurationUnit.MICROSECONDS);
   }

   public static final long getInWholeNanoseconds_impl/* $FF was: getInWholeNanoseconds-impl*/(long var0) {
      long value = getValue-impl(var0);
      return isInNanos-impl(var0) ? value : (value > 9223372036854L ? Long.MAX_VALUE : (value < -9223372036854L ? Long.MIN_VALUE : DurationKt.access$millisToNanos(value)));
   }

   @NotNull
   public static String toString_impl/* $FF was: toString-impl*/(long var0) {
      String var10000;
      if (var0 == 0L) {
         var10000 = "0s";
      } else if (var0 == INFINITE) {
         var10000 = "Infinity";
      } else if (var0 == NEG_INFINITE) {
         var10000 = "-Infinity";
      } else {
         boolean isNegative = isNegative-impl(var0);
         StringBuilder var5 = new StringBuilder();
         int var7 = 0;
         if (isNegative) {
            var5.append('-');
         }

         long var8 = getAbsoluteValue-UwyO8pc(var0);
         int var10 = 0;
         long var23 = getInWholeDays-impl(var8);
         int var10001 = getHoursComponent-impl(var8);
         int var10002 = getMinutesComponent-impl(var8);
         int var10003 = getSecondsComponent-impl(var8);
         int nanoseconds = getNanosecondsComponent-impl(var8);
         int seconds = var10003;
         int minutes = var10002;
         int hours = var10001;
         long days = var23;
         int var17 = 0;
         boolean hasDays = days != 0L;
         boolean hasHours = hours != 0;
         boolean hasMinutes = minutes != 0;
         boolean hasSeconds = seconds != 0 || nanoseconds != 0;
         int components = 0;
         if (hasDays) {
            var5.append(days).append('d');
            ++components;
         }

         if (hasHours || hasDays && (hasMinutes || hasSeconds)) {
            if (components++ > 0) {
               var5.append(' ');
            }

            var5.append(hours).append('h');
         }

         if (hasMinutes || hasSeconds && (hasHours || hasDays)) {
            if (components++ > 0) {
               var5.append(' ');
            }

            var5.append(minutes).append('m');
         }

         if (hasSeconds) {
            if (components++ > 0) {
               var5.append(' ');
            }

            if (seconds == 0 && !hasDays && !hasHours && !hasMinutes) {
               if (nanoseconds >= 1000000) {
                  appendFractional-impl(var0, var5, nanoseconds / 1000000, nanoseconds % 1000000, 6, "ms", false);
               } else if (nanoseconds >= 1000) {
                  appendFractional-impl(var0, var5, nanoseconds / 1000, nanoseconds % 1000, 3, "us", false);
               } else {
                  var5.append(nanoseconds).append("ns");
               }
            } else {
               appendFractional-impl(var0, var5, seconds, nanoseconds, 9, "s", false);
            }
         }

         if (isNegative && components > 1) {
            var5.insert(1, '(').append(')');
         }

         var10000 = var5.toString();
      }

      return var10000;
   }

   @NotNull
   public String toString() {
      return toString-impl(this.rawValue);
   }

   private static final void appendFractional_impl/* $FF was: appendFractional-impl*/(long var0, StringBuilder $this$appendFractional, int whole, int fractional, int fractionalSize, String unit, boolean isoZeroes) {
      $this$appendFractional.append(whole);
      if (fractional != 0) {
         String fracString;
         int var10000;
         label33: {
            $this$appendFractional.append('.');
            fracString = StringsKt.padStart(String.valueOf(fractional), fractionalSize, '0');
            CharSequence $this$indexOfLast$iv = (CharSequence)fracString;
            int $i$f$indexOfLast = 0;
            int var12 = $this$indexOfLast$iv.length() + -1;
            if (0 <= var12) {
               do {
                  int index$iv = var12--;
                  char it = $this$indexOfLast$iv.charAt(index$iv);
                  int var15 = 0;
                  if (it != '0') {
                     var10000 = index$iv;
                     break label33;
                  }
               } while(0 <= var12);
            }

            var10000 = -1;
         }

         int nonZeroDigits = var10000 + 1;
         if (!isoZeroes && nonZeroDigits < 3) {
            Intrinsics.checkNotNullExpressionValue($this$appendFractional.append((CharSequence)fracString, 0, nonZeroDigits), "append(...)");
         } else {
            Intrinsics.checkNotNullExpressionValue($this$appendFractional.append((CharSequence)fracString, 0, (nonZeroDigits + 2) / 3 * 3), "append(...)");
         }
      }

      $this$appendFractional.append(unit);
   }

   @NotNull
   public static final String toString_impl/* $FF was: toString-impl*/(long var0, @NotNull DurationUnit unit, int decimals) {
      Intrinsics.checkNotNullParameter(unit, "unit");
      if (decimals < 0) {
         int var5 = 0;
         String var6 = "decimals must be not negative, but was " + decimals;
         throw new IllegalArgumentException(var6.toString());
      } else {
         double number = toDouble-impl(var0, unit);
         return Double.isInfinite(number) ? String.valueOf(number) : DurationJvmKt.formatToExactDecimals(number, RangesKt.coerceAtMost(decimals, 12)) + DurationUnitKt.shortName(unit);
      }
   }

   // $FF: synthetic method
   public static String toString_impl$default/* $FF was: toString-impl$default*/(long var0, DurationUnit var2, int var3, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var3 = 0;
      }

      return toString-impl(var0, var2, var3);
   }

   @NotNull
   public static final String toIsoString_impl/* $FF was: toIsoString-impl*/(long var0) {
      StringBuilder var2 = new StringBuilder();
      int var4 = 0;
      if (isNegative-impl(var0)) {
         var2.append('-');
      }

      var2.append("PT");
      long var5 = getAbsoluteValue-UwyO8pc(var0);
      int var7 = 0;
      long var10000 = getInWholeHours-impl(var5);
      int var10001 = getMinutesComponent-impl(var5);
      int var10002 = getSecondsComponent-impl(var5);
      int nanoseconds = getNanosecondsComponent-impl(var5);
      int seconds = var10002;
      int minutes = var10001;
      long hours = var10000;
      int var13 = 0;
      long hours = hours;
      if (isInfinite-impl(var0)) {
         hours = 9999999999999L;
      }

      boolean hasHours = hours != 0L;
      boolean hasSeconds = seconds != 0 || nanoseconds != 0;
      boolean hasMinutes = minutes != 0 || hasSeconds && hasHours;
      if (hasHours) {
         var2.append(hours).append('H');
      }

      if (hasMinutes) {
         var2.append(minutes).append('M');
      }

      if (hasSeconds || !hasHours && !hasMinutes) {
         appendFractional-impl(var0, var2, seconds, nanoseconds, 9, "S", true);
      }

      return var2.toString();
   }

   public static int hashCode_impl/* $FF was: hashCode-impl*/(long var0) {
      return Long.hashCode(var0);
   }

   public int hashCode() {
      return hashCode-impl(this.rawValue);
   }

   public static boolean equals_impl/* $FF was: equals-impl*/(long var0, Object other) {
      if (!(other instanceof Duration)) {
         return false;
      } else {
         long var3 = ((Duration)other).unbox-impl();
         return var0 == var3;
      }
   }

   public boolean equals(Object other) {
      return equals-impl(this.rawValue, other);
   }

   // $FF: synthetic method
   private Duration(long rawValue) {
      this.rawValue = rawValue;
   }

   public static long constructor_impl/* $FF was: constructor-impl*/(long rawValue) {
      if (DurationJvmKt.getDurationAssertionsEnabled()) {
         if (isInNanos-impl(rawValue)) {
            long var4 = getValue-impl(rawValue);
            if (!(-4611686018426999999L <= var4 ? var4 < 4611686018427000000L : false)) {
               throw new AssertionError(getValue-impl(rawValue) + " ns is out of nanoseconds range");
            }
         } else {
            long var6 = getValue-impl(rawValue);
            if (!(-4611686018427387903L <= var6 ? var6 < 4611686018427387904L : false)) {
               throw new AssertionError(getValue-impl(rawValue) + " ms is out of milliseconds range");
            }

            var6 = getValue-impl(rawValue);
            if (-4611686018426L <= var6 ? var6 < 4611686018427L : false) {
               throw new AssertionError(getValue-impl(rawValue) + " ms is denormalized");
            }
         }
      }

      return rawValue;
   }

   // $FF: synthetic method
   public static final Duration box_impl/* $FF was: box-impl*/(long v) {
      return new Duration(v);
   }

   // $FF: synthetic method
   public final long unbox_impl/* $FF was: unbox-impl*/() {
      return this.rawValue;
   }

   public static final boolean equals_impl0/* $FF was: equals-impl0*/(long p1, long p2) {
      return p1 == p2;
   }

   @Metadata(
      mv = {2, 2, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0006\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0017\n\u0002\u0010\u000e\n\u0002\b\t\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J \u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0011H\u0007J\u0015\u00100\u001a\u00020\u00052\u0006\u0010\u000f\u001a\u000201¢\u0006\u0004\b2\u00103J\u0015\u00104\u001a\u00020\u00052\u0006\u0010\u000f\u001a\u000201¢\u0006\u0004\b5\u00103J\u0015\u00106\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u000f\u001a\u000201¢\u0006\u0002\b7J\u0015\u00108\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u000f\u001a\u000201¢\u0006\u0002\b9R\u0013\u0010\u0004\u001a\u00020\u0005¢\u0006\n\n\u0002\u0010\b\u001a\u0004\b\u0006\u0010\u0007R\u0013\u0010\t\u001a\u00020\u0005¢\u0006\n\n\u0002\u0010\b\u001a\u0004\b\n\u0010\u0007R\u0016\u0010\u000b\u001a\u00020\u0005X\u0080\u0004¢\u0006\n\n\u0002\u0010\b\u001a\u0004\b\f\u0010\u0007R\u001f\u0010\u0013\u001a\u00020\u0005*\u00020\u00148Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b\u0015\u0010\u0016\u001a\u0004\b\u0017\u0010\u0018R\u001f\u0010\u0013\u001a\u00020\u0005*\u00020\u00198Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b\u0015\u0010\u001a\u001a\u0004\b\u0017\u0010\u001bR\u001f\u0010\u0013\u001a\u00020\u0005*\u00020\u000e8Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b\u0015\u0010\u001c\u001a\u0004\b\u0017\u0010\u001dR\u001f\u0010\u001e\u001a\u00020\u0005*\u00020\u00148Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b\u001f\u0010\u0016\u001a\u0004\b \u0010\u0018R\u001f\u0010\u001e\u001a\u00020\u0005*\u00020\u00198Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b\u001f\u0010\u001a\u001a\u0004\b \u0010\u001bR\u001f\u0010\u001e\u001a\u00020\u0005*\u00020\u000e8Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b\u001f\u0010\u001c\u001a\u0004\b \u0010\u001dR\u001f\u0010!\u001a\u00020\u0005*\u00020\u00148Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b\"\u0010\u0016\u001a\u0004\b#\u0010\u0018R\u001f\u0010!\u001a\u00020\u0005*\u00020\u00198Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b\"\u0010\u001a\u001a\u0004\b#\u0010\u001bR\u001f\u0010!\u001a\u00020\u0005*\u00020\u000e8Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b\"\u0010\u001c\u001a\u0004\b#\u0010\u001dR\u001f\u0010$\u001a\u00020\u0005*\u00020\u00148Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b%\u0010\u0016\u001a\u0004\b&\u0010\u0018R\u001f\u0010$\u001a\u00020\u0005*\u00020\u00198Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b%\u0010\u001a\u001a\u0004\b&\u0010\u001bR\u001f\u0010$\u001a\u00020\u0005*\u00020\u000e8Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b%\u0010\u001c\u001a\u0004\b&\u0010\u001dR\u001f\u0010'\u001a\u00020\u0005*\u00020\u00148Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b(\u0010\u0016\u001a\u0004\b)\u0010\u0018R\u001f\u0010'\u001a\u00020\u0005*\u00020\u00198Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b(\u0010\u001a\u001a\u0004\b)\u0010\u001bR\u001f\u0010'\u001a\u00020\u0005*\u00020\u000e8Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b(\u0010\u001c\u001a\u0004\b)\u0010\u001dR\u001f\u0010*\u001a\u00020\u0005*\u00020\u00148Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b+\u0010\u0016\u001a\u0004\b,\u0010\u0018R\u001f\u0010*\u001a\u00020\u0005*\u00020\u00198Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b+\u0010\u001a\u001a\u0004\b,\u0010\u001bR\u001f\u0010*\u001a\u00020\u0005*\u00020\u000e8Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b+\u0010\u001c\u001a\u0004\b,\u0010\u001dR\u001f\u0010-\u001a\u00020\u0005*\u00020\u00148Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b.\u0010\u0016\u001a\u0004\b/\u0010\u0018R\u001f\u0010-\u001a\u00020\u0005*\u00020\u00198Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b.\u0010\u001a\u001a\u0004\b/\u0010\u001bR\u001f\u0010-\u001a\u00020\u0005*\u00020\u000e8Æ\u0002X\u0087\u0004¢\u0006\f\u0012\u0004\b.\u0010\u001c\u001a\u0004\b/\u0010\u001d¨\u0006:"},
      d2 = {"Lkotlin/time/Duration$Companion;", "", "<init>", "()V", "ZERO", "Lkotlin/time/Duration;", "getZERO-UwyO8pc", "()J", "J", "INFINITE", "getINFINITE-UwyO8pc", "NEG_INFINITE", "getNEG_INFINITE-UwyO8pc$kotlin_stdlib", "convert", "", "value", "sourceUnit", "Lkotlin/time/DurationUnit;", "targetUnit", "nanoseconds", "", "getNanoseconds-UwyO8pc$annotations", "(I)V", "getNanoseconds-UwyO8pc", "(I)J", "", "(J)V", "(J)J", "(D)V", "(D)J", "microseconds", "getMicroseconds-UwyO8pc$annotations", "getMicroseconds-UwyO8pc", "milliseconds", "getMilliseconds-UwyO8pc$annotations", "getMilliseconds-UwyO8pc", "seconds", "getSeconds-UwyO8pc$annotations", "getSeconds-UwyO8pc", "minutes", "getMinutes-UwyO8pc$annotations", "getMinutes-UwyO8pc", "hours", "getHours-UwyO8pc$annotations", "getHours-UwyO8pc", "days", "getDays-UwyO8pc$annotations", "getDays-UwyO8pc", "parse", "", "parse-UwyO8pc", "(Ljava/lang/String;)J", "parseIsoString", "parseIsoString-UwyO8pc", "parseOrNull", "parseOrNull-FghU774", "parseIsoStringOrNull", "parseIsoStringOrNull-FghU774", "kotlin-stdlib"}
   )
   public static final class Companion {
      private Companion() {
      }

      public final long getZERO_UwyO8pc/* $FF was: getZERO-UwyO8pc*/() {
         return Duration.ZERO;
      }

      public final long getINFINITE_UwyO8pc/* $FF was: getINFINITE-UwyO8pc*/() {
         return Duration.INFINITE;
      }

      public final long getNEG_INFINITE_UwyO8pc$kotlin_stdlib/* $FF was: getNEG_INFINITE-UwyO8pc$kotlin_stdlib*/() {
         return Duration.NEG_INFINITE;
      }

      @ExperimentalTime
      public final double convert(double value, @NotNull DurationUnit sourceUnit, @NotNull DurationUnit targetUnit) {
         Intrinsics.checkNotNullParameter(sourceUnit, "sourceUnit");
         Intrinsics.checkNotNullParameter(targetUnit, "targetUnit");
         return DurationUnitKt.convertDurationUnit(value, sourceUnit, targetUnit);
      }

      private final long getNanoseconds_UwyO8pc/* $FF was: getNanoseconds-UwyO8pc*/(int $this$nanoseconds) {
         return DurationKt.toDuration($this$nanoseconds, DurationUnit.NANOSECONDS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getNanoseconds_UwyO8pc$annotations/* $FF was: getNanoseconds-UwyO8pc$annotations*/(int var0) {
      }

      private final long getNanoseconds_UwyO8pc/* $FF was: getNanoseconds-UwyO8pc*/(long $this$nanoseconds) {
         return DurationKt.toDuration($this$nanoseconds, DurationUnit.NANOSECONDS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getNanoseconds_UwyO8pc$annotations/* $FF was: getNanoseconds-UwyO8pc$annotations*/(long var0) {
      }

      private final long getNanoseconds_UwyO8pc/* $FF was: getNanoseconds-UwyO8pc*/(double $this$nanoseconds) {
         return DurationKt.toDuration($this$nanoseconds, DurationUnit.NANOSECONDS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getNanoseconds_UwyO8pc$annotations/* $FF was: getNanoseconds-UwyO8pc$annotations*/(double var0) {
      }

      private final long getMicroseconds_UwyO8pc/* $FF was: getMicroseconds-UwyO8pc*/(int $this$microseconds) {
         return DurationKt.toDuration($this$microseconds, DurationUnit.MICROSECONDS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getMicroseconds_UwyO8pc$annotations/* $FF was: getMicroseconds-UwyO8pc$annotations*/(int var0) {
      }

      private final long getMicroseconds_UwyO8pc/* $FF was: getMicroseconds-UwyO8pc*/(long $this$microseconds) {
         return DurationKt.toDuration($this$microseconds, DurationUnit.MICROSECONDS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getMicroseconds_UwyO8pc$annotations/* $FF was: getMicroseconds-UwyO8pc$annotations*/(long var0) {
      }

      private final long getMicroseconds_UwyO8pc/* $FF was: getMicroseconds-UwyO8pc*/(double $this$microseconds) {
         return DurationKt.toDuration($this$microseconds, DurationUnit.MICROSECONDS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getMicroseconds_UwyO8pc$annotations/* $FF was: getMicroseconds-UwyO8pc$annotations*/(double var0) {
      }

      private final long getMilliseconds_UwyO8pc/* $FF was: getMilliseconds-UwyO8pc*/(int $this$milliseconds) {
         return DurationKt.toDuration($this$milliseconds, DurationUnit.MILLISECONDS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getMilliseconds_UwyO8pc$annotations/* $FF was: getMilliseconds-UwyO8pc$annotations*/(int var0) {
      }

      private final long getMilliseconds_UwyO8pc/* $FF was: getMilliseconds-UwyO8pc*/(long $this$milliseconds) {
         return DurationKt.toDuration($this$milliseconds, DurationUnit.MILLISECONDS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getMilliseconds_UwyO8pc$annotations/* $FF was: getMilliseconds-UwyO8pc$annotations*/(long var0) {
      }

      private final long getMilliseconds_UwyO8pc/* $FF was: getMilliseconds-UwyO8pc*/(double $this$milliseconds) {
         return DurationKt.toDuration($this$milliseconds, DurationUnit.MILLISECONDS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getMilliseconds_UwyO8pc$annotations/* $FF was: getMilliseconds-UwyO8pc$annotations*/(double var0) {
      }

      private final long getSeconds_UwyO8pc/* $FF was: getSeconds-UwyO8pc*/(int $this$seconds) {
         return DurationKt.toDuration($this$seconds, DurationUnit.SECONDS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getSeconds_UwyO8pc$annotations/* $FF was: getSeconds-UwyO8pc$annotations*/(int var0) {
      }

      private final long getSeconds_UwyO8pc/* $FF was: getSeconds-UwyO8pc*/(long $this$seconds) {
         return DurationKt.toDuration($this$seconds, DurationUnit.SECONDS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getSeconds_UwyO8pc$annotations/* $FF was: getSeconds-UwyO8pc$annotations*/(long var0) {
      }

      private final long getSeconds_UwyO8pc/* $FF was: getSeconds-UwyO8pc*/(double $this$seconds) {
         return DurationKt.toDuration($this$seconds, DurationUnit.SECONDS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getSeconds_UwyO8pc$annotations/* $FF was: getSeconds-UwyO8pc$annotations*/(double var0) {
      }

      private final long getMinutes_UwyO8pc/* $FF was: getMinutes-UwyO8pc*/(int $this$minutes) {
         return DurationKt.toDuration($this$minutes, DurationUnit.MINUTES);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getMinutes_UwyO8pc$annotations/* $FF was: getMinutes-UwyO8pc$annotations*/(int var0) {
      }

      private final long getMinutes_UwyO8pc/* $FF was: getMinutes-UwyO8pc*/(long $this$minutes) {
         return DurationKt.toDuration($this$minutes, DurationUnit.MINUTES);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getMinutes_UwyO8pc$annotations/* $FF was: getMinutes-UwyO8pc$annotations*/(long var0) {
      }

      private final long getMinutes_UwyO8pc/* $FF was: getMinutes-UwyO8pc*/(double $this$minutes) {
         return DurationKt.toDuration($this$minutes, DurationUnit.MINUTES);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getMinutes_UwyO8pc$annotations/* $FF was: getMinutes-UwyO8pc$annotations*/(double var0) {
      }

      private final long getHours_UwyO8pc/* $FF was: getHours-UwyO8pc*/(int $this$hours) {
         return DurationKt.toDuration($this$hours, DurationUnit.HOURS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getHours_UwyO8pc$annotations/* $FF was: getHours-UwyO8pc$annotations*/(int var0) {
      }

      private final long getHours_UwyO8pc/* $FF was: getHours-UwyO8pc*/(long $this$hours) {
         return DurationKt.toDuration($this$hours, DurationUnit.HOURS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getHours_UwyO8pc$annotations/* $FF was: getHours-UwyO8pc$annotations*/(long var0) {
      }

      private final long getHours_UwyO8pc/* $FF was: getHours-UwyO8pc*/(double $this$hours) {
         return DurationKt.toDuration($this$hours, DurationUnit.HOURS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getHours_UwyO8pc$annotations/* $FF was: getHours-UwyO8pc$annotations*/(double var0) {
      }

      private final long getDays_UwyO8pc/* $FF was: getDays-UwyO8pc*/(int $this$days) {
         return DurationKt.toDuration($this$days, DurationUnit.DAYS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getDays_UwyO8pc$annotations/* $FF was: getDays-UwyO8pc$annotations*/(int var0) {
      }

      private final long getDays_UwyO8pc/* $FF was: getDays-UwyO8pc*/(long $this$days) {
         return DurationKt.toDuration($this$days, DurationUnit.DAYS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getDays_UwyO8pc$annotations/* $FF was: getDays-UwyO8pc$annotations*/(long var0) {
      }

      private final long getDays_UwyO8pc/* $FF was: getDays-UwyO8pc*/(double $this$days) {
         return DurationKt.toDuration($this$days, DurationUnit.DAYS);
      }

      /** @deprecated */
      // $FF: synthetic method
      @InlineOnly
      public static void getDays_UwyO8pc$annotations/* $FF was: getDays-UwyO8pc$annotations*/(double var0) {
      }

      public final long parse_UwyO8pc/* $FF was: parse-UwyO8pc*/(@NotNull String value) {
         Intrinsics.checkNotNullParameter(value, "value");

         try {
            long var2 = DurationKt.access$parseDuration(value, false);
            return var2;
         } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid duration string format: '" + value + "'.", (Throwable)e);
         }
      }

      public final long parseIsoString_UwyO8pc/* $FF was: parseIsoString-UwyO8pc*/(@NotNull String value) {
         Intrinsics.checkNotNullParameter(value, "value");

         try {
            long var2 = DurationKt.access$parseDuration(value, true);
            return var2;
         } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid ISO duration string format: '" + value + "'.", (Throwable)e);
         }
      }

      @Nullable
      public final Duration parseOrNull_FghU774/* $FF was: parseOrNull-FghU774*/(@NotNull String value) {
         Intrinsics.checkNotNullParameter(value, "value");

         Duration var2;
         try {
            var2 = Duration.box-impl(DurationKt.access$parseDuration(value, false));
         } catch (IllegalArgumentException var4) {
            var2 = null;
         }

         return var2;
      }

      @Nullable
      public final Duration parseIsoStringOrNull_FghU774/* $FF was: parseIsoStringOrNull-FghU774*/(@NotNull String value) {
         Intrinsics.checkNotNullParameter(value, "value");

         Duration var2;
         try {
            var2 = Duration.box-impl(DurationKt.access$parseDuration(value, true));
         } catch (IllegalArgumentException var4) {
            var2 = null;
         }

         return var2;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
