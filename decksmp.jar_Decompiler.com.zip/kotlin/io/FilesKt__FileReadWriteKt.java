package kotlin.io;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.CoderResult;
import java.nio.charset.CodingErrorAction;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.internal.InlineOnly;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.RangesKt;
import kotlin.sequences.Sequence;
import kotlin.text.Charsets;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 2, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000\u008c\u0001\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u0017\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a!\u0010\u0005\u001a\u00020\u0006*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042\b\b\u0002\u0010\u0007\u001a\u00020\bH\u0087\b\u001a\u0017\u0010\t\u001a\u00020\n*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a!\u0010\u000b\u001a\u00020\f*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042\b\b\u0002\u0010\u0007\u001a\u00020\bH\u0087\b\u001a\u0017\u0010\r\u001a\u00020\u000e*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u0004H\u0087\b\u001a\n\u0010\u000f\u001a\u00020\u0010*\u00020\u0002\u001a\u0012\u0010\u0011\u001a\u00020\u0012*\u00020\u00022\u0006\u0010\u0013\u001a\u00020\u0010\u001a\u0012\u0010\u0014\u001a\u00020\u0012*\u00020\u00022\u0006\u0010\u0013\u001a\u00020\u0010\u001a\u0014\u0010\u0015\u001a\u00020\u0016*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u0004\u001a\u001c\u0010\u0017\u001a\u00020\u0012*\u00020\u00022\u0006\u0010\u0018\u001a\u00020\u00162\b\b\u0002\u0010\u0003\u001a\u00020\u0004\u001a\u001c\u0010\u0019\u001a\u00020\u0012*\u00020\u00022\u0006\u0010\u0018\u001a\u00020\u00162\b\b\u0002\u0010\u0003\u001a\u00020\u0004\u001a\u001c\u0010\u001a\u001a\u00020\u0012*\u00020\u001b2\u0006\u0010\u0018\u001a\u00020\u00162\u0006\u0010\u0003\u001a\u00020\u0004H\u0000\u001a\u0014\u0010\u001c\u001a\n \u001e*\u0004\u0018\u00010\u001d0\u001d*\u00020\u0004H\u0000\u001a\u0018\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\b2\u0006\u0010\"\u001a\u00020\u001dH\u0000\u001aB\u0010#\u001a\u00020\u0012*\u00020\u000226\u0010$\u001a2\u0012\u0013\u0012\u00110\u0010¢\u0006\f\b&\u0012\b\b'\u0012\u0004\b\b((\u0012\u0013\u0012\u00110\b¢\u0006\f\b&\u0012\b\b'\u0012\u0004\b\b()\u0012\u0004\u0012\u00020\u00120%\u001aJ\u0010#\u001a\u00020\u0012*\u00020\u00022\u0006\u0010*\u001a\u00020\b26\u0010$\u001a2\u0012\u0013\u0012\u00110\u0010¢\u0006\f\b&\u0012\b\b'\u0012\u0004\b\b((\u0012\u0013\u0012\u00110\b¢\u0006\f\b&\u0012\b\b'\u0012\u0004\b\b()\u0012\u0004\u0012\u00020\u00120%\u001a7\u0010+\u001a\u00020\u0012*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042!\u0010$\u001a\u001d\u0012\u0013\u0012\u00110\u0016¢\u0006\f\b&\u0012\b\b'\u0012\u0004\b\b(-\u0012\u0004\u0012\u00020\u00120,\u001a\r\u0010.\u001a\u00020/*\u00020\u0002H\u0087\b\u001a\r\u00100\u001a\u000201*\u00020\u0002H\u0087\b\u001a\u001a\u00102\u001a\b\u0012\u0004\u0012\u00020\u001603*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u0004\u001aL\u00104\u001a\u0002H5\"\u0004\b\u0000\u00105*\u00020\u00022\b\b\u0002\u0010\u0003\u001a\u00020\u00042\u0018\u00106\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001607\u0012\u0004\u0012\u0002H50,H\u0086\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0001¢\u0006\u0002\u00108\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u00069"},
   d2 = {"reader", "Ljava/io/InputStreamReader;", "Ljava/io/File;", "charset", "Ljava/nio/charset/Charset;", "bufferedReader", "Ljava/io/BufferedReader;", "bufferSize", "", "writer", "Ljava/io/OutputStreamWriter;", "bufferedWriter", "Ljava/io/BufferedWriter;", "printWriter", "Ljava/io/PrintWriter;", "readBytes", "", "writeBytes", "", "array", "appendBytes", "readText", "", "writeText", "text", "appendText", "writeTextImpl", "Ljava/io/OutputStream;", "newReplaceEncoder", "Ljava/nio/charset/CharsetEncoder;", "kotlin.jvm.PlatformType", "byteBufferForEncoding", "Ljava/nio/ByteBuffer;", "chunkSize", "encoder", "forEachBlock", "action", "Lkotlin/Function2;", "Lkotlin/ParameterName;", "name", "buffer", "bytesRead", "blockSize", "forEachLine", "Lkotlin/Function1;", "line", "inputStream", "Ljava/io/FileInputStream;", "outputStream", "Ljava/io/FileOutputStream;", "readLines", "", "useLines", "T", "block", "Lkotlin/sequences/Sequence;", "(Ljava/io/File;Ljava/nio/charset/Charset;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "kotlin-stdlib"},
   xs = "kotlin/io/FilesKt"
)
@SourceDebugExtension({"SMAP\nFileReadWrite.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FileReadWrite.kt\nkotlin/io/FilesKt__FileReadWriteKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,290:1\n1#2:291\n*E\n"})
class FilesKt__FileReadWriteKt extends FilesKt__FilePathComponentsKt {
   @InlineOnly
   private static final InputStreamReader reader(File $this$reader, Charset charset) {
      Intrinsics.checkNotNullParameter($this$reader, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      return new InputStreamReader((InputStream)(new FileInputStream($this$reader)), charset);
   }

   // $FF: synthetic method
   static InputStreamReader reader$default(File $this$reader_u24default, Charset charset, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         charset = Charsets.UTF_8;
      }

      Intrinsics.checkNotNullParameter($this$reader_u24default, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      return new InputStreamReader((InputStream)(new FileInputStream($this$reader_u24default)), charset);
   }

   @InlineOnly
   private static final BufferedReader bufferedReader(File $this$bufferedReader, Charset charset, int bufferSize) {
      Intrinsics.checkNotNullParameter($this$bufferedReader, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Reader var3 = (Reader)(new InputStreamReader((InputStream)(new FileInputStream($this$bufferedReader)), charset));
      return var3 instanceof BufferedReader ? (BufferedReader)var3 : new BufferedReader(var3, bufferSize);
   }

   // $FF: synthetic method
   static BufferedReader bufferedReader$default(File $this$bufferedReader_u24default, Charset charset, int bufferSize, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         charset = Charsets.UTF_8;
      }

      if ((var3 & 2) != 0) {
         bufferSize = 8192;
      }

      Intrinsics.checkNotNullParameter($this$bufferedReader_u24default, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Reader var5 = (Reader)(new InputStreamReader((InputStream)(new FileInputStream($this$bufferedReader_u24default)), charset));
      return var5 instanceof BufferedReader ? (BufferedReader)var5 : new BufferedReader(var5, bufferSize);
   }

   @InlineOnly
   private static final OutputStreamWriter writer(File $this$writer, Charset charset) {
      Intrinsics.checkNotNullParameter($this$writer, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      return new OutputStreamWriter((OutputStream)(new FileOutputStream($this$writer)), charset);
   }

   // $FF: synthetic method
   static OutputStreamWriter writer$default(File $this$writer_u24default, Charset charset, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         charset = Charsets.UTF_8;
      }

      Intrinsics.checkNotNullParameter($this$writer_u24default, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      return new OutputStreamWriter((OutputStream)(new FileOutputStream($this$writer_u24default)), charset);
   }

   @InlineOnly
   private static final BufferedWriter bufferedWriter(File $this$bufferedWriter, Charset charset, int bufferSize) {
      Intrinsics.checkNotNullParameter($this$bufferedWriter, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Writer var3 = (Writer)(new OutputStreamWriter((OutputStream)(new FileOutputStream($this$bufferedWriter)), charset));
      return var3 instanceof BufferedWriter ? (BufferedWriter)var3 : new BufferedWriter(var3, bufferSize);
   }

   // $FF: synthetic method
   static BufferedWriter bufferedWriter$default(File $this$bufferedWriter_u24default, Charset charset, int bufferSize, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         charset = Charsets.UTF_8;
      }

      if ((var3 & 2) != 0) {
         bufferSize = 8192;
      }

      Intrinsics.checkNotNullParameter($this$bufferedWriter_u24default, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Writer var5 = (Writer)(new OutputStreamWriter((OutputStream)(new FileOutputStream($this$bufferedWriter_u24default)), charset));
      return var5 instanceof BufferedWriter ? (BufferedWriter)var5 : new BufferedWriter(var5, bufferSize);
   }

   @InlineOnly
   private static final PrintWriter printWriter(File $this$printWriter, Charset charset) {
      Intrinsics.checkNotNullParameter($this$printWriter, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      short var3 = 8192;
      Writer var4 = (Writer)(new OutputStreamWriter((OutputStream)(new FileOutputStream($this$printWriter)), charset));
      return new PrintWriter((Writer)(var4 instanceof BufferedWriter ? (BufferedWriter)var4 : new BufferedWriter(var4, var3)));
   }

   // $FF: synthetic method
   static PrintWriter printWriter$default(File $this$printWriter_u24default, Charset charset, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         charset = Charsets.UTF_8;
      }

      Intrinsics.checkNotNullParameter($this$printWriter_u24default, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      short var5 = 8192;
      Writer var4 = (Writer)(new OutputStreamWriter((OutputStream)(new FileOutputStream($this$printWriter_u24default)), charset));
      return new PrintWriter((Writer)(var4 instanceof BufferedWriter ? (BufferedWriter)var4 : new BufferedWriter(var4, var5)));
   }

   @NotNull
   public static final byte[] readBytes(@NotNull File $this$readBytes) {
      Intrinsics.checkNotNullParameter($this$readBytes, "<this>");
      Closeable var1 = (Closeable)(new FileInputStream($this$readBytes));
      Throwable var2 = null;

      byte[] var18;
      try {
         FileInputStream input = (FileInputStream)var1;
         int var4 = 0;
         int offset = 0;
         long length = $this$readBytes.length();
         int var10 = 0;
         if (length > 2147483647L) {
            throw new OutOfMemoryError("File " + $this$readBytes + " is too big (" + length + " bytes) to fit in memory.");
         }

         int remaining = (int)length;

         int read;
         for(result = new byte[remaining]; remaining > 0; offset += read) {
            read = input.read(result, offset, remaining);
            if (read < 0) {
               break;
            }

            remaining -= read;
         }

         byte[] var10000;
         if (remaining > 0) {
            var10000 = Arrays.copyOf(result, offset);
            Intrinsics.checkNotNullExpressionValue(var10000, "copyOf(...)");
         } else {
            read = input.read();
            if (read == -1) {
               var10000 = result;
            } else {
               ExposingBufferByteArrayOutputStream extra = new ExposingBufferByteArrayOutputStream(8193);
               extra.write(read);
               ByteStreamsKt.copyTo$default((InputStream)input, (OutputStream)extra, 0, 2, (Object)null);
               var10 = result.length + extra.size();
               if (var10 < 0) {
                  throw new OutOfMemoryError("File " + $this$readBytes + " is too big to fit in memory.");
               }

               var10000 = extra.getBuffer();
               byte[] var10001 = Arrays.copyOf(result, var10);
               Intrinsics.checkNotNullExpressionValue(var10001, "copyOf(...)");
               var10000 = ArraysKt.copyInto(var10000, var10001, result.length, 0, extra.size());
            }
         }

         var18 = var10000;
      } catch (Throwable var16) {
         var2 = var16;
         throw var16;
      } finally {
         CloseableKt.closeFinally(var1, var2);
      }

      return var18;
   }

   public static final void writeBytes(@NotNull File $this$writeBytes, @NotNull byte[] array) {
      Intrinsics.checkNotNullParameter($this$writeBytes, "<this>");
      Intrinsics.checkNotNullParameter(array, "array");
      Closeable var2 = (Closeable)(new FileOutputStream($this$writeBytes));
      Throwable var3 = null;

      try {
         FileOutputStream it = (FileOutputStream)var2;
         int var5 = 0;
         it.write(array);
         Unit var10 = Unit.INSTANCE;
      } catch (Throwable var8) {
         var3 = var8;
         throw var8;
      } finally {
         CloseableKt.closeFinally(var2, var3);
      }

   }

   public static final void appendBytes(@NotNull File $this$appendBytes, @NotNull byte[] array) {
      Intrinsics.checkNotNullParameter($this$appendBytes, "<this>");
      Intrinsics.checkNotNullParameter(array, "array");
      Closeable var2 = (Closeable)(new FileOutputStream($this$appendBytes, true));
      Throwable var3 = null;

      try {
         FileOutputStream it = (FileOutputStream)var2;
         int var5 = 0;
         it.write(array);
         Unit var10 = Unit.INSTANCE;
      } catch (Throwable var8) {
         var3 = var8;
         throw var8;
      } finally {
         CloseableKt.closeFinally(var2, var3);
      }

   }

   @NotNull
   public static final String readText(@NotNull File $this$readText, @NotNull Charset charset) {
      Intrinsics.checkNotNullParameter($this$readText, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Closeable var2 = (Closeable)(new InputStreamReader((InputStream)(new FileInputStream($this$readText)), charset));
      Throwable var3 = null;

      String var10;
      try {
         InputStreamReader it = (InputStreamReader)var2;
         int var5 = 0;
         var10 = TextStreamsKt.readText((Reader)it);
      } catch (Throwable var8) {
         var3 = var8;
         throw var8;
      } finally {
         CloseableKt.closeFinally(var2, var3);
      }

      return var10;
   }

   // $FF: synthetic method
   public static String readText$default(File var0, Charset var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = Charsets.UTF_8;
      }

      return FilesKt.readText(var0, var1);
   }

   public static final void writeText(@NotNull File $this$writeText, @NotNull String text, @NotNull Charset charset) {
      Intrinsics.checkNotNullParameter($this$writeText, "<this>");
      Intrinsics.checkNotNullParameter(text, "text");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Closeable var3 = (Closeable)(new FileOutputStream($this$writeText));
      Throwable var4 = null;

      try {
         FileOutputStream it = (FileOutputStream)var3;
         int var6 = 0;
         FilesKt.writeTextImpl((OutputStream)it, text, charset);
         Unit var11 = Unit.INSTANCE;
      } catch (Throwable var9) {
         var4 = var9;
         throw var9;
      } finally {
         CloseableKt.closeFinally(var3, var4);
      }

   }

   // $FF: synthetic method
   public static void writeText$default(File var0, String var1, Charset var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = Charsets.UTF_8;
      }

      FilesKt.writeText(var0, var1, var2);
   }

   public static final void appendText(@NotNull File $this$appendText, @NotNull String text, @NotNull Charset charset) {
      Intrinsics.checkNotNullParameter($this$appendText, "<this>");
      Intrinsics.checkNotNullParameter(text, "text");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Closeable var3 = (Closeable)(new FileOutputStream($this$appendText, true));
      Throwable var4 = null;

      try {
         FileOutputStream it = (FileOutputStream)var3;
         int var6 = 0;
         FilesKt.writeTextImpl((OutputStream)it, text, charset);
         Unit var11 = Unit.INSTANCE;
      } catch (Throwable var9) {
         var4 = var9;
         throw var9;
      } finally {
         CloseableKt.closeFinally(var3, var4);
      }

   }

   // $FF: synthetic method
   public static void appendText$default(File var0, String var1, Charset var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = Charsets.UTF_8;
      }

      FilesKt.appendText(var0, var1, var2);
   }

   public static final void writeTextImpl(@NotNull OutputStream $this$writeTextImpl, @NotNull String text, @NotNull Charset charset) {
      Intrinsics.checkNotNullParameter($this$writeTextImpl, "<this>");
      Intrinsics.checkNotNullParameter(text, "text");
      Intrinsics.checkNotNullParameter(charset, "charset");
      int chunkSize = 8192;
      if (text.length() < 2 * chunkSize) {
         byte[] var10001 = text.getBytes(charset);
         Intrinsics.checkNotNullExpressionValue(var10001, "getBytes(...)");
         $this$writeTextImpl.write(var10001);
      } else {
         CharsetEncoder encoder = FilesKt.newReplaceEncoder(charset);
         CharBuffer charBuffer = CharBuffer.allocate(chunkSize);
         Intrinsics.checkNotNull(encoder);
         ByteBuffer byteBuffer = FilesKt.byteBufferForEncoding(chunkSize, encoder);
         int startIndex = 0;

         int endIndex;
         for(int leftover = 0; startIndex < text.length(); startIndex = endIndex) {
            int var10 = chunkSize - leftover;
            int it = text.length() - startIndex;
            int copyLength = Math.min(var10, it);
            endIndex = startIndex + copyLength;
            char[] var10000 = charBuffer.array();
            Intrinsics.checkNotNullExpressionValue(var10000, "array(...)");
            char[] var12 = var10000;
            text.getChars(startIndex, endIndex, var12, leftover);
            charBuffer.limit(copyLength + leftover);
            CoderResult it = encoder.encode(charBuffer, byteBuffer, endIndex == text.length());
            int var13 = 0;
            if (!it.isUnderflow()) {
               throw new IllegalStateException("Check failed.");
            }

            $this$writeTextImpl.write(byteBuffer.array(), 0, byteBuffer.position());
            if (charBuffer.position() != charBuffer.limit()) {
               charBuffer.put(0, charBuffer.get());
               leftover = 1;
            } else {
               leftover = 0;
            }

            charBuffer.clear();
            byteBuffer.clear();
         }

      }
   }

   public static final CharsetEncoder newReplaceEncoder(@NotNull Charset $this$newReplaceEncoder) {
      Intrinsics.checkNotNullParameter($this$newReplaceEncoder, "<this>");
      return $this$newReplaceEncoder.newEncoder().onMalformedInput(CodingErrorAction.REPLACE).onUnmappableCharacter(CodingErrorAction.REPLACE);
   }

   @NotNull
   public static final ByteBuffer byteBufferForEncoding(int chunkSize, @NotNull CharsetEncoder encoder) {
      Intrinsics.checkNotNullParameter(encoder, "encoder");
      int maxBytesPerChar = (int)((float)Math.ceil((double)encoder.maxBytesPerChar()));
      ByteBuffer var10000 = ByteBuffer.allocate(chunkSize * maxBytesPerChar);
      Intrinsics.checkNotNullExpressionValue(var10000, "allocate(...)");
      return var10000;
   }

   public static final void forEachBlock(@NotNull File $this$forEachBlock, @NotNull Function2<byte[], ? super Integer, Unit> action) {
      Intrinsics.checkNotNullParameter($this$forEachBlock, "<this>");
      Intrinsics.checkNotNullParameter(action, "action");
      FilesKt.forEachBlock($this$forEachBlock, 4096, action);
   }

   public static final void forEachBlock(@NotNull File $this$forEachBlock, int blockSize, @NotNull Function2<byte[], ? super Integer, Unit> action) {
      Intrinsics.checkNotNullParameter($this$forEachBlock, "<this>");
      Intrinsics.checkNotNullParameter(action, "action");
      byte[] arr = new byte[RangesKt.coerceAtLeast(blockSize, 512)];
      Closeable var4 = (Closeable)(new FileInputStream($this$forEachBlock));
      Throwable var5 = null;

      try {
         FileInputStream input = (FileInputStream)var4;
         int var7 = 0;

         while(true) {
            int size = input.read(arr);
            if (size <= 0) {
               Unit var13 = Unit.INSTANCE;
               return;
            }

            action.invoke(arr, size);
         }
      } catch (Throwable var11) {
         var5 = var11;
         throw var11;
      } finally {
         CloseableKt.closeFinally(var4, var5);
      }
   }

   public static final void forEachLine(@NotNull File $this$forEachLine, @NotNull Charset charset, @NotNull Function1<? super String, Unit> action) {
      Intrinsics.checkNotNullParameter($this$forEachLine, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(action, "action");
      TextStreamsKt.forEachLine((Reader)(new BufferedReader((Reader)(new InputStreamReader((InputStream)(new FileInputStream($this$forEachLine)), charset)))), action);
   }

   // $FF: synthetic method
   public static void forEachLine$default(File var0, Charset var1, Function1 var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = Charsets.UTF_8;
      }

      FilesKt.forEachLine(var0, var1, var2);
   }

   @InlineOnly
   private static final FileInputStream inputStream(File $this$inputStream) {
      Intrinsics.checkNotNullParameter($this$inputStream, "<this>");
      return new FileInputStream($this$inputStream);
   }

   @InlineOnly
   private static final FileOutputStream outputStream(File $this$outputStream) {
      Intrinsics.checkNotNullParameter($this$outputStream, "<this>");
      return new FileOutputStream($this$outputStream);
   }

   @NotNull
   public static final List<String> readLines(@NotNull File $this$readLines, @NotNull Charset charset) {
      Intrinsics.checkNotNullParameter($this$readLines, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      ArrayList result = new ArrayList();
      FilesKt.forEachLine($this$readLines, charset, FilesKt__FileReadWriteKt::readLines$lambda$0$FilesKt__FileReadWriteKt);
      return (List)result;
   }

   // $FF: synthetic method
   public static List readLines$default(File var0, Charset var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = Charsets.UTF_8;
      }

      return FilesKt.readLines(var0, var1);
   }

   public static final <T> T useLines(@NotNull File $this$useLines, @NotNull Charset charset, @NotNull Function1<? super Sequence<String>, ? extends T> block) {
      Intrinsics.checkNotNullParameter($this$useLines, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(block, "block");
      int $i$f$useLines = 0;
      short var5 = 8192;
      Reader var6 = (Reader)(new InputStreamReader((InputStream)(new FileInputStream($this$useLines)), charset));
      Closeable var4 = (Closeable)(var6 instanceof BufferedReader ? (BufferedReader)var6 : new BufferedReader(var6, var5));
      Throwable var12 = null;

      try {
         BufferedReader it = (BufferedReader)var4;
         int var7 = 0;
         var14 = block.invoke(TextStreamsKt.lineSequence(it));
      } catch (Throwable var10) {
         var12 = var10;
         throw var10;
      } finally {
         InlineMarker.finallyStart(1);
         CloseableKt.closeFinally(var4, var12);
         InlineMarker.finallyEnd(1);
      }

      return (T)var14;
   }

   // $FF: synthetic method
   public static Object useLines$default(File $this$useLines_u24default, Charset charset, Function1 block, int $i$f$useLines, Object var4) {
      if (($i$f$useLines & 1) != 0) {
         charset = Charsets.UTF_8;
      }

      Intrinsics.checkNotNullParameter($this$useLines_u24default, "<this>");
      Intrinsics.checkNotNullParameter(charset, "charset");
      Intrinsics.checkNotNullParameter(block, "block");
      $i$f$useLines = 0;
      short var5 = 8192;
      Reader var6 = (Reader)(new InputStreamReader((InputStream)(new FileInputStream($this$useLines_u24default)), charset));
      Closeable var13 = (Closeable)(var6 instanceof BufferedReader ? (BufferedReader)var6 : new BufferedReader(var6, var5));
      Throwable var14 = null;

      try {
         BufferedReader it = (BufferedReader)var13;
         int var7 = 0;
         var16 = block.invoke(TextStreamsKt.lineSequence(it));
      } catch (Throwable var10) {
         var14 = var10;
         throw var10;
      } finally {
         InlineMarker.finallyStart(1);
         CloseableKt.closeFinally(var13, var14);
         InlineMarker.finallyEnd(1);
      }

      return var16;
   }

   private static final Unit readLines$lambda$0$FilesKt__FileReadWriteKt(ArrayList $result, String it) {
      Intrinsics.checkNotNullParameter(it, "it");
      $result.add(it);
      return Unit.INSTANCE;
   }

   public FilesKt__FileReadWriteKt() {
   }
}
