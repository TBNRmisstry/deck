package kotlin.io.path;

import java.io.Closeable;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystemException;
import java.nio.file.FileSystemLoopException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.SecureDirectoryStream;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.ExceptionsKt;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.SinceKotlin;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.io.CloseableKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.jvm.internal.SpreadBuilder;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 2, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\f\u001aw\u0010\u0000\u001a\u00020\u0001*\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00012Q\b\u0002\u0010\u0003\u001aK\u0012\u0013\u0012\u00110\u0001¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0013\u0012\u00110\u0001¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0002\u0012\u0017\u0012\u00150\bj\u0002`\n¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\t\u0012\u0004\u0012\u00020\u000b0\u00042\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\rH\u0007\u001a´\u0001\u0010\u0000\u001a\u00020\u0001*\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00012Q\b\u0002\u0010\u0003\u001aK\u0012\u0013\u0012\u00110\u0001¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0013\u0012\u00110\u0001¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0002\u0012\u0017\u0012\u00150\bj\u0002`\n¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\t\u0012\u0004\u0012\u00020\u000b0\u00042\u0006\u0010\f\u001a\u00020\r2C\b\u0002\u0010\u000f\u001a=\u0012\u0004\u0012\u00020\u0010\u0012\u0013\u0012\u00110\u0001¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0013\u0012\u00110\u0001¢\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0002\u0012\u0004\u0012\u00020\u00110\u0004¢\u0006\u0002\b\u0012H\u0007\u001a\u0011\u0010\u0013\u001a\u00020\u0014*\u00020\u0011H\u0003¢\u0006\u0002\b\u0015\u001a\u0011\u0010\u0013\u001a\u00020\u0014*\u00020\u000bH\u0003¢\u0006\u0002\b\u0015\u001a\f\u0010\u0016\u001a\u00020\u0017*\u00020\u0001H\u0007\u001a\u001b\u0010\u0018\u001a\f\u0012\b\u0012\u00060\bj\u0002`\n0\u0019*\u00020\u0001H\u0002¢\u0006\u0002\b\u001a\u001a$\u0010\u001b\u001a\u00020\u00172\u0006\u0010\u001c\u001a\u00020\u001d2\f\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u00170\u001fH\u0082\b¢\u0006\u0002\b \u001a&\u0010!\u001a\u0004\u0018\u0001H\"\"\u0004\b\u0000\u0010\"2\f\u0010\u001e\u001a\b\u0012\u0004\u0012\u0002H\"0\u001fH\u0082\b¢\u0006\u0004\b#\u0010$\u001a1\u0010%\u001a\u00020\u0017*\b\u0012\u0004\u0012\u00020\u00010&2\u0006\u0010\u0006\u001a\u00020\u00012\b\u0010'\u001a\u0004\u0018\u00010\u00012\u0006\u0010\u001c\u001a\u00020\u001dH\u0002¢\u0006\u0002\b(\u001a'\u0010)\u001a\u00020\u0017*\b\u0012\u0004\u0012\u00020\u00010&2\u0006\u0010\u0006\u001a\u00020\u00012\u0006\u0010\u001c\u001a\u00020\u001dH\u0002¢\u0006\u0002\b*\u001a5\u0010+\u001a\u00020\r*\b\u0012\u0004\u0012\u00020\u00010&2\u0006\u0010,\u001a\u00020\u00012\u0012\u0010-\u001a\n\u0012\u0006\b\u0001\u0012\u00020/0.\"\u00020/H\u0002¢\u0006\u0004\b0\u00101\u001a'\u00102\u001a\u00020\u00172\u0006\u00103\u001a\u00020\u00012\b\u0010'\u001a\u0004\u0018\u00010\u00012\u0006\u0010\u001c\u001a\u00020\u001dH\u0002¢\u0006\u0002\b4\u001a\u001d\u00105\u001a\u00020\u00172\u0006\u00106\u001a\u00020\u00012\u0006\u0010\u001c\u001a\u00020\u001dH\u0002¢\u0006\u0002\b7\u001a\f\u00108\u001a\u00020\u0017*\u00020\u0001H\u0000\u001a\u0019\u00109\u001a\u00020\u0017*\u00020\u00012\u0006\u0010'\u001a\u00020\u0001H\u0002¢\u0006\u0002\b:¨\u0006;"},
   d2 = {"copyToRecursively", "Ljava/nio/file/Path;", "target", "onError", "Lkotlin/Function3;", "Lkotlin/ParameterName;", "name", "source", "Ljava/lang/Exception;", "exception", "Lkotlin/Exception;", "Lkotlin/io/path/OnErrorResult;", "followLinks", "", "overwrite", "copyAction", "Lkotlin/io/path/CopyActionContext;", "Lkotlin/io/path/CopyActionResult;", "Lkotlin/ExtensionFunctionType;", "toFileVisitResult", "Ljava/nio/file/FileVisitResult;", "toFileVisitResult$PathsKt__PathRecursiveFunctionsKt", "deleteRecursively", "", "deleteRecursivelyImpl", "", "deleteRecursivelyImpl$PathsKt__PathRecursiveFunctionsKt", "collectIfThrows", "collector", "Lkotlin/io/path/ExceptionsCollector;", "function", "Lkotlin/Function0;", "collectIfThrows$PathsKt__PathRecursiveFunctionsKt", "tryIgnoreNoSuchFileException", "R", "tryIgnoreNoSuchFileException$PathsKt__PathRecursiveFunctionsKt", "(Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "handleEntry", "Ljava/nio/file/SecureDirectoryStream;", "parent", "handleEntry$PathsKt__PathRecursiveFunctionsKt", "enterDirectory", "enterDirectory$PathsKt__PathRecursiveFunctionsKt", "isDirectory", "entryName", "options", "", "Ljava/nio/file/LinkOption;", "isDirectory$PathsKt__PathRecursiveFunctionsKt", "(Ljava/nio/file/SecureDirectoryStream;Ljava/nio/file/Path;[Ljava/nio/file/LinkOption;)Z", "insecureHandleEntry", "entry", "insecureHandleEntry$PathsKt__PathRecursiveFunctionsKt", "insecureEnterDirectory", "path", "insecureEnterDirectory$PathsKt__PathRecursiveFunctionsKt", "checkFileName", "checkNotSameAs", "checkNotSameAs$PathsKt__PathRecursiveFunctionsKt", "kotlin-stdlib-jdk7"},
   xs = "kotlin/io/path/PathsKt"
)
@SourceDebugExtension({"SMAP\nPathRecursiveFunctions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PathRecursiveFunctions.kt\nkotlin/io/path/PathsKt__PathRecursiveFunctionsKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,532:1\n378#1,2:536\n386#1:538\n386#1:539\n380#1,4:540\n378#1,2:544\n386#1:546\n380#1,4:547\n386#1:551\n378#1,6:552\n378#1,2:558\n386#1:560\n380#1,4:561\n1#2:533\n1869#3,2:534\n*S KotlinDebug\n*F\n+ 1 PathRecursiveFunctions.kt\nkotlin/io/path/PathsKt__PathRecursiveFunctionsKt\n*L\n394#1:536,2\n409#1:538\n412#1:539\n394#1:540,4\n420#1:544,2\n421#1:546\n420#1:547,4\n432#1:551\n440#1:552,6\n463#1:558,2\n464#1:560\n463#1:561,4\n314#1:534,2\n*E\n"})
class PathsKt__PathRecursiveFunctionsKt extends PathsKt__PathReadWriteKt {
   @ExperimentalPathApi
   @SinceKotlin(
      version = "1.8"
   )
   @NotNull
   public static final Path copyToRecursively(@NotNull Path $this$copyToRecursively, @NotNull Path target, @NotNull Function3<? super Path, ? super Path, ? super Exception, ? extends OnErrorResult> onError, boolean followLinks, boolean overwrite) {
      Intrinsics.checkNotNullParameter($this$copyToRecursively, "<this>");
      Intrinsics.checkNotNullParameter(target, "target");
      Intrinsics.checkNotNullParameter(onError, "onError");
      return overwrite ? PathsKt.copyToRecursively($this$copyToRecursively, target, onError, followLinks, PathsKt__PathRecursiveFunctionsKt::copyToRecursively$lambda$0$PathsKt__PathRecursiveFunctionsKt) : PathsKt.copyToRecursively$default($this$copyToRecursively, target, onError, followLinks, (Function3)null, 8, (Object)null);
   }

   // $FF: synthetic method
   public static Path copyToRecursively$default(Path var0, Path var1, Function3 var2, boolean var3, boolean var4, int var5, Object var6) {
      if ((var5 & 2) != 0) {
         var2 = null.INSTANCE;
      }

      return PathsKt.copyToRecursively(var0, var1, var2, var3, var4);
   }

   @ExperimentalPathApi
   @SinceKotlin(
      version = "1.8"
   )
   @NotNull
   public static final Path copyToRecursively(@NotNull Path $this$copyToRecursively, @NotNull Path target, @NotNull Function3<? super Path, ? super Path, ? super Exception, ? extends OnErrorResult> onError, boolean followLinks, @NotNull Function3<? super CopyActionContext, ? super Path, ? super Path, ? extends CopyActionResult> copyAction) {
      Intrinsics.checkNotNullParameter($this$copyToRecursively, "<this>");
      Intrinsics.checkNotNullParameter(target, "target");
      Intrinsics.checkNotNullParameter(onError, "onError");
      Intrinsics.checkNotNullParameter(copyAction, "copyAction");
      LinkOption[] var6 = LinkFollowing.INSTANCE.toLinkOptions(followLinks);
      var6 = (LinkOption[])Arrays.copyOf(var6, var6.length);
      if (!Files.exists($this$copyToRecursively, (LinkOption[])Arrays.copyOf(var6, var6.length))) {
         throw new NoSuchFileException($this$copyToRecursively.toString(), target.toString(), "The source file doesn't exist.");
      } else {
         LinkOption[] var10001 = new LinkOption[0];
         if (Files.exists($this$copyToRecursively, (LinkOption[])Arrays.copyOf(var10001, var10001.length)) && (followLinks || !Files.isSymbolicLink($this$copyToRecursively))) {
            var10001 = new LinkOption[0];
            boolean targetExistsAndNotSymlink = Files.exists(target, (LinkOption[])Arrays.copyOf(var10001, var10001.length)) && !Files.isSymbolicLink(target);
            if (!targetExistsAndNotSymlink || !Files.isSameFile($this$copyToRecursively, target)) {
               boolean var13;
               if (!Intrinsics.areEqual((Object)$this$copyToRecursively.getFileSystem(), (Object)target.getFileSystem())) {
                  var13 = false;
               } else if (targetExistsAndNotSymlink) {
                  var13 = target.toRealPath().startsWith($this$copyToRecursively.toRealPath());
               } else {
                  Path var10000 = target.getParent();
                  if (var10000 == null) {
                     var13 = false;
                  } else {
                     Path it = var10000;
                     int var8 = 0;
                     var10001 = new LinkOption[0];
                     var13 = Files.exists(it, (LinkOption[])Arrays.copyOf(var10001, var10001.length)) && it.toRealPath().startsWith($this$copyToRecursively.toRealPath());
                  }
               }

               boolean isSubdirectory = var13;
               if (isSubdirectory) {
                  throw new FileSystemException($this$copyToRecursively.toString(), target.toString(), "Recursively copying a directory into its subdirectory is prohibited.");
               }
            }
         }

         Path normalizedTarget = target.normalize();
         ArrayList stack = new ArrayList();
         PathsKt.visitFileTree$default($this$copyToRecursively, 0, followLinks, PathsKt__PathRecursiveFunctionsKt::copyToRecursively$lambda$3$PathsKt__PathRecursiveFunctionsKt, 1, (Object)null);
         return target;
      }
   }

   // $FF: synthetic method
   public static Path copyToRecursively$default(Path var0, Path var1, Function3 var2, boolean var3, Function3 var4, int var5, Object var6) {
      if ((var5 & 2) != 0) {
         var2 = null.INSTANCE;
      }

      if ((var5 & 8) != 0) {
         var4 = PathsKt__PathRecursiveFunctionsKt::copyToRecursively$lambda$1$PathsKt__PathRecursiveFunctionsKt;
      }

      return PathsKt.copyToRecursively(var0, var1, var2, var3, var4);
   }

   @ExperimentalPathApi
   private static final FileVisitResult toFileVisitResult$PathsKt__PathRecursiveFunctionsKt(CopyActionResult $this$toFileVisitResult) {
      FileVisitResult var10000;
      switch (PathsKt__PathRecursiveFunctionsKt.WhenMappings.$EnumSwitchMapping$0[$this$toFileVisitResult.ordinal()]) {
         case 1:
            var10000 = FileVisitResult.CONTINUE;
            break;
         case 2:
            var10000 = FileVisitResult.TERMINATE;
            break;
         case 3:
            var10000 = FileVisitResult.SKIP_SUBTREE;
            break;
         default:
            throw new NoWhenBranchMatchedException();
      }

      return var10000;
   }

   @ExperimentalPathApi
   private static final FileVisitResult toFileVisitResult$PathsKt__PathRecursiveFunctionsKt(OnErrorResult $this$toFileVisitResult) {
      FileVisitResult var10000;
      switch (PathsKt__PathRecursiveFunctionsKt.WhenMappings.$EnumSwitchMapping$1[$this$toFileVisitResult.ordinal()]) {
         case 1:
            var10000 = FileVisitResult.TERMINATE;
            break;
         case 2:
            var10000 = FileVisitResult.SKIP_SUBTREE;
            break;
         default:
            throw new NoWhenBranchMatchedException();
      }

      return var10000;
   }

   @ExperimentalPathApi
   @SinceKotlin(
      version = "1.8"
   )
   public static final void deleteRecursively(@NotNull Path $this$deleteRecursively) {
      Intrinsics.checkNotNullParameter($this$deleteRecursively, "<this>");
      List suppressedExceptions = deleteRecursivelyImpl$PathsKt__PathRecursiveFunctionsKt($this$deleteRecursively);
      if (!((Collection)suppressedExceptions).isEmpty()) {
         FileSystemException var2 = new FileSystemException("Failed to delete one or more files. See suppressed exceptions for details.");
         FileSystemException $this$deleteRecursively_u24lambda_u240 = var2;
         int var4 = 0;
         Iterable $this$forEach$iv = (Iterable)suppressedExceptions;
         int $i$f$forEach = 0;

         for(Object element$iv : $this$forEach$iv) {
            Exception it = (Exception)element$iv;
            int var10 = 0;
            ExceptionsKt.addSuppressed((Throwable)$this$deleteRecursively_u24lambda_u240, (Throwable)it);
         }

         throw (Throwable)var2;
      }
   }

   private static final List<Exception> deleteRecursivelyImpl$PathsKt__PathRecursiveFunctionsKt(Path $this$deleteRecursivelyImpl) {
      ExceptionsCollector collector = new ExceptionsCollector(0, 1, (DefaultConstructorMarker)null);
      boolean useInsecure = false;
      useInsecure = true;
      Path var10000 = $this$deleteRecursivelyImpl.getFileName();
      if (var10000 != null) {
         Path fileName = var10000;
         int var4 = 0;
         var10000 = $this$deleteRecursivelyImpl.getParent();
         if (var10000 == null) {
            var10000 = $this$deleteRecursivelyImpl.getFileSystem().getPath("");
         }

         Path parent = var10000;

         DirectoryStream directoryStream;
         try {
            directoryStream = Files.newDirectoryStream(parent);
         } catch (Throwable var16) {
            directoryStream = null;
         }

         if (directoryStream != null) {
            Closeable directoryStream = (Closeable)directoryStream;
            Throwable var7 = null;

            try {
               DirectoryStream stream = (DirectoryStream)directoryStream;
               int var10 = 0;
               if (stream instanceof SecureDirectoryStream) {
                  useInsecure = false;
                  collector.setPath(parent);
                  handleEntry$PathsKt__PathRecursiveFunctionsKt((SecureDirectoryStream)stream, fileName, (Path)null, collector);
               }

               Unit var19 = Unit.INSTANCE;
            } catch (Throwable var14) {
               var7 = var14;
               throw var14;
            } finally {
               CloseableKt.closeFinally(directoryStream, var7);
            }
         }
      }

      if (useInsecure) {
         insecureHandleEntry$PathsKt__PathRecursiveFunctionsKt($this$deleteRecursivelyImpl, (Path)null, collector);
      }

      return collector.getCollectedExceptions();
   }

   private static final void collectIfThrows$PathsKt__PathRecursiveFunctionsKt(ExceptionsCollector collector, Function0<Unit> function) {
      int $i$f$collectIfThrows = 0;

      try {
         function.invoke();
      } catch (Exception exception) {
         collector.collect(exception);
      }

   }

   private static final <R> R tryIgnoreNoSuchFileException$PathsKt__PathRecursiveFunctionsKt(Function0<? extends R> function) {
      int $i$f$tryIgnoreNoSuchFileException = 0;

      Object var2;
      try {
         var2 = function.invoke();
      } catch (NoSuchFileException var4) {
         var2 = null;
      }

      return (R)var2;
   }

   private static final void handleEntry$PathsKt__PathRecursiveFunctionsKt(SecureDirectoryStream<Path> $this$handleEntry, Path name, Path parent, ExceptionsCollector collector) {
      collector.enterEntry(name);
      int $i$f$collectIfThrows = 0;

      try {
         int var6 = 0;
         if (parent != null) {
            Path var10000 = collector.getPath();
            Intrinsics.checkNotNull(var10000);
            Path entry = var10000;
            PathsKt.checkFileName(entry);
            checkNotSameAs$PathsKt__PathRecursiveFunctionsKt(entry, parent);
         }

         LinkOption[] preEnterTotalExceptions = new LinkOption[]{LinkOption.NOFOLLOW_LINKS};
         if (isDirectory$PathsKt__PathRecursiveFunctionsKt($this$handleEntry, name, preEnterTotalExceptions)) {
            int preEnterTotalExceptions = collector.getTotalExceptions();
            enterDirectory$PathsKt__PathRecursiveFunctionsKt($this$handleEntry, name, collector);
            if (preEnterTotalExceptions == collector.getTotalExceptions()) {
               int $i$f$tryIgnoreNoSuchFileException = 0;

               try {
                  int var9 = 0;
                  $this$handleEntry.deleteDirectory(name);
                  Unit var22 = Unit.INSTANCE;
               } catch (NoSuchFileException var14) {
                  Unit var10 = null;
               }
            }
         } else {
            int $i$f$tryIgnoreNoSuchFileException = 0;

            try {
               int var19 = 0;
               $this$handleEntry.deleteFile(name);
               Unit var21 = Unit.INSTANCE;
            } catch (NoSuchFileException var13) {
               Object var20 = null;
            }
         }
      } catch (Exception exception$iv) {
         collector.collect(exception$iv);
      }

      collector.exitEntry(name);
   }

   private static final void enterDirectory$PathsKt__PathRecursiveFunctionsKt(SecureDirectoryStream<Path> $this$enterDirectory, Path name, ExceptionsCollector collector) {
      int $i$f$collectIfThrows = 0;

      try {
         int var5 = 0;
         int $i$f$tryIgnoreNoSuchFileException = 0;

         SecureDirectoryStream var9;
         try {
            int var7 = 0;
            LinkOption[] var8 = new LinkOption[]{LinkOption.NOFOLLOW_LINKS};
            var9 = $this$enterDirectory.newDirectoryStream(name, var8);
         } catch (NoSuchFileException var18) {
            var9 = null;
         }

         if (var9 != null) {
            Closeable var22 = (Closeable)var9;
            Throwable var23 = null;

            try {
               SecureDirectoryStream directoryStream = (SecureDirectoryStream)var22;
               int var26 = 0;
               Iterator var10000 = directoryStream.iterator();
               Intrinsics.checkNotNullExpressionValue(var10000, "iterator(...)");
               Iterator var10 = var10000;

               while(var10.hasNext()) {
                  Path entry = (Path)var10.next();
                  Path var10001 = entry.getFileName();
                  Intrinsics.checkNotNullExpressionValue(var10001, "getFileName(...)");
                  handleEntry$PathsKt__PathRecursiveFunctionsKt(directoryStream, var10001, collector.getPath(), collector);
               }

               Unit var25 = Unit.INSTANCE;
            } catch (Throwable var19) {
               var23 = var19;
               throw var19;
            } finally {
               CloseableKt.closeFinally(var22, var23);
            }
         }
      } catch (Exception exception$iv) {
         collector.collect(exception$iv);
      }

   }

   private static final boolean isDirectory$PathsKt__PathRecursiveFunctionsKt(SecureDirectoryStream<Path> $this$isDirectory, Path entryName, LinkOption... options) {
      int $i$f$tryIgnoreNoSuchFileException = 0;

      Boolean var5;
      try {
         int var4 = 0;
         var5 = ((BasicFileAttributeView)$this$isDirectory.getFileAttributeView(entryName, BasicFileAttributeView.class, (LinkOption[])Arrays.copyOf(options, options.length))).readAttributes().isDirectory();
      } catch (NoSuchFileException var7) {
         var5 = null;
      }

      return var5 != null ? var5 : false;
   }

   private static final void insecureHandleEntry$PathsKt__PathRecursiveFunctionsKt(Path entry, Path parent, ExceptionsCollector collector) {
      int $i$f$collectIfThrows = 0;

      try {
         int var5 = 0;
         if (parent != null) {
            PathsKt.checkFileName(entry);
            checkNotSameAs$PathsKt__PathRecursiveFunctionsKt(entry, parent);
         }

         LinkOption[] var7 = new LinkOption[]{LinkOption.NOFOLLOW_LINKS};
         if (Files.isDirectory(entry, (LinkOption[])Arrays.copyOf(var7, var7.length))) {
            int preEnterTotalExceptions = collector.getTotalExceptions();
            insecureEnterDirectory$PathsKt__PathRecursiveFunctionsKt(entry, collector);
            if (preEnterTotalExceptions == collector.getTotalExceptions()) {
               Files.deleteIfExists(entry);
            }
         } else {
            Files.deleteIfExists(entry);
         }
      } catch (Exception exception$iv) {
         collector.collect(exception$iv);
      }

   }

   private static final void insecureEnterDirectory$PathsKt__PathRecursiveFunctionsKt(Path path, ExceptionsCollector collector) {
      int $i$f$collectIfThrows = 0;

      try {
         int var4 = 0;
         int $i$f$tryIgnoreNoSuchFileException = 0;

         DirectoryStream directoryStream;
         try {
            int var6 = 0;
            directoryStream = Files.newDirectoryStream(path);
         } catch (NoSuchFileException var17) {
            directoryStream = null;
         }

         if (directoryStream != null) {
            Closeable var21 = (Closeable)directoryStream;
            Throwable var22 = null;

            try {
               directoryStream = (DirectoryStream)var21;
               int var9 = 0;
               Iterator var10000 = directoryStream.iterator();
               Intrinsics.checkNotNullExpressionValue(var10000, "iterator(...)");
               Iterator var10 = var10000;

               while(var10.hasNext()) {
                  Path entry = (Path)var10.next();
                  Intrinsics.checkNotNull(entry);
                  insecureHandleEntry$PathsKt__PathRecursiveFunctionsKt(entry, path, collector);
               }

               Unit var24 = Unit.INSTANCE;
            } catch (Throwable var18) {
               var22 = var18;
               throw var18;
            } finally {
               CloseableKt.closeFinally(var21, var22);
            }
         }
      } catch (Exception exception$iv) {
         collector.collect(exception$iv);
      }

   }

   public static final void checkFileName(@NotNull Path $this$checkFileName) {
      Intrinsics.checkNotNullParameter($this$checkFileName, "<this>");
      switch (fileName) {
         case ".":
            throw new IllegalFileNameException($this$checkFileName);
         case "..":
            throw new IllegalFileNameException($this$checkFileName);
         case "./":
            throw new IllegalFileNameException($this$checkFileName);
         case ".\\":
            throw new IllegalFileNameException($this$checkFileName);
         case "../":
            throw new IllegalFileNameException($this$checkFileName);
         case "..\\":
            throw new IllegalFileNameException($this$checkFileName);
      }

   }

   private static final void checkNotSameAs$PathsKt__PathRecursiveFunctionsKt(Path $this$checkNotSameAs, Path parent) {
      if (!Files.isSymbolicLink($this$checkNotSameAs) && Files.isSameFile($this$checkNotSameAs, parent)) {
         throw new FileSystemLoopException($this$checkNotSameAs.toString());
      }
   }

   private static final CopyActionResult copyToRecursively$lambda$0$PathsKt__PathRecursiveFunctionsKt(boolean $followLinks, CopyActionContext $this$copyToRecursively, Path src, Path dst) {
      Intrinsics.checkNotNullParameter($this$copyToRecursively, "$this$copyToRecursively");
      Intrinsics.checkNotNullParameter(src, "src");
      Intrinsics.checkNotNullParameter(dst, "dst");
      LinkOption[] options = LinkFollowing.INSTANCE.toLinkOptions($followLinks);
      LinkOption[] var7 = new LinkOption[]{LinkOption.NOFOLLOW_LINKS};
      boolean dstIsDirectory = Files.isDirectory(dst, (LinkOption[])Arrays.copyOf(var7, var7.length));
      LinkOption[] var10001 = (LinkOption[])Arrays.copyOf(options, options.length);
      boolean srcIsDirectory = Files.isDirectory(src, (LinkOption[])Arrays.copyOf(var10001, var10001.length));
      if (!srcIsDirectory || !dstIsDirectory) {
         if (dstIsDirectory) {
            PathsKt.deleteRecursively(dst);
         }

         SpreadBuilder var8 = new SpreadBuilder(2);
         var8.addSpread(options);
         var8.add(StandardCopyOption.REPLACE_EXISTING);
         CopyOption[] var9 = (CopyOption[])var8.toArray(new CopyOption[var8.size()]);
         Intrinsics.checkNotNullExpressionValue(Files.copy(src, dst, (CopyOption[])Arrays.copyOf(var9, var9.length)), "copy(...)");
      }

      return CopyActionResult.CONTINUE;
   }

   private static final CopyActionResult copyToRecursively$lambda$1$PathsKt__PathRecursiveFunctionsKt(boolean $followLinks, CopyActionContext var1, Path src, Path dst) {
      Intrinsics.checkNotNullParameter(var1, "<this>");
      Intrinsics.checkNotNullParameter(src, "src");
      Intrinsics.checkNotNullParameter(dst, "dst");
      return var1.copyToIgnoringExistingDirectory(src, dst, $followLinks);
   }

   private static final Path copyToRecursively$destination$PathsKt__PathRecursiveFunctionsKt(Path $this_copyToRecursively, Path $target, Path normalizedTarget, Path source) {
      Path relativePath = PathsKt.relativeTo(source, $this_copyToRecursively);
      Path destination = $target.resolve(relativePath.toString());
      if (!destination.normalize().startsWith(normalizedTarget)) {
         throw new IllegalFileNameException(source, destination, "Copying files to outside the specified target directory is prohibited. The directory being recursively copied might contain an entry with an illegal name.");
      } else {
         Intrinsics.checkNotNull(destination);
         return destination;
      }
   }

   private static final FileVisitResult copyToRecursively$error$PathsKt__PathRecursiveFunctionsKt(Function3<? super Path, ? super Path, ? super Exception, ? extends OnErrorResult> $onError, Path $this_copyToRecursively, Path $target, Path normalizedTarget, Path source, Exception exception) {
      return toFileVisitResult$PathsKt__PathRecursiveFunctionsKt((OnErrorResult)$onError.invoke(source, copyToRecursively$destination$PathsKt__PathRecursiveFunctionsKt($this_copyToRecursively, $target, normalizedTarget, source), exception));
   }

   private static final FileVisitResult copyToRecursively$copy$PathsKt__PathRecursiveFunctionsKt(ArrayList<Path> stack, Function3<? super CopyActionContext, ? super Path, ? super Path, ? extends CopyActionResult> $copyAction, Path $this_copyToRecursively, Path $target, Path normalizedTarget, Function3<? super Path, ? super Path, ? super Exception, ? extends OnErrorResult> $onError, Path source, BasicFileAttributes attributes) {
      FileVisitResult var8;
      try {
         if (!((Collection)stack).isEmpty()) {
            PathsKt.checkFileName(source);
            Object var10001 = CollectionsKt.last((List)stack);
            Intrinsics.checkNotNullExpressionValue(var10001, "last(...)");
            checkNotSameAs$PathsKt__PathRecursiveFunctionsKt(source, (Path)var10001);
         }

         var8 = toFileVisitResult$PathsKt__PathRecursiveFunctionsKt((CopyActionResult)$copyAction.invoke(DefaultCopyActionContext.INSTANCE, source, copyToRecursively$destination$PathsKt__PathRecursiveFunctionsKt($this_copyToRecursively, $target, normalizedTarget, source)));
      } catch (Exception exception) {
         var8 = copyToRecursively$error$PathsKt__PathRecursiveFunctionsKt($onError, $this_copyToRecursively, $target, normalizedTarget, source, exception);
      }

      return var8;
   }

   private static final Unit copyToRecursively$lambda$3$PathsKt__PathRecursiveFunctionsKt(ArrayList $stack, Function3 $copyAction, Path $this_copyToRecursively, Path $target, Path $normalizedTarget, Function3 $onError, FileVisitorBuilder $this$visitFileTree) {
      Intrinsics.checkNotNullParameter($this$visitFileTree, "$this$visitFileTree");
      $this$visitFileTree.onPreVisitDirectory(PathsKt__PathRecursiveFunctionsKt::copyToRecursively$lambda$3$0$PathsKt__PathRecursiveFunctionsKt);
      $this$visitFileTree.onVisitFile(new Function2<Path, BasicFileAttributes, FileVisitResult>($stack, $copyAction, $this_copyToRecursively, $target, $normalizedTarget, $onError) {
         // $FF: synthetic field
         final ArrayList<Path> $stack;
         // $FF: synthetic field
         final Function3<CopyActionContext, Path, Path, CopyActionResult> $copyAction;
         // $FF: synthetic field
         final Path $this_copyToRecursively;
         // $FF: synthetic field
         final Path $target;
         // $FF: synthetic field
         final Path $normalizedTarget;
         // $FF: synthetic field
         final Function3<Path, Path, Exception, OnErrorResult> $onError;

         {
            this.$stack = $stack;
            this.$copyAction = $copyAction;
            this.$this_copyToRecursively = $receiver;
            this.$target = $target;
            this.$normalizedTarget = $normalizedTarget;
            this.$onError = $onError;
         }

         public final FileVisitResult invoke(Path p0, BasicFileAttributes p1) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            Intrinsics.checkNotNullParameter(p1, "p1");
            return PathsKt__PathRecursiveFunctionsKt.copyToRecursively$copy$PathsKt__PathRecursiveFunctionsKt(this.$stack, this.$copyAction, this.$this_copyToRecursively, this.$target, this.$normalizedTarget, this.$onError, p0, p1);
         }
      });
      $this$visitFileTree.onVisitFileFailed(new Function2<Path, Exception, FileVisitResult>($onError, $this_copyToRecursively, $target, $normalizedTarget) {
         // $FF: synthetic field
         final Function3<Path, Path, Exception, OnErrorResult> $onError;
         // $FF: synthetic field
         final Path $this_copyToRecursively;
         // $FF: synthetic field
         final Path $target;
         // $FF: synthetic field
         final Path $normalizedTarget;

         {
            this.$onError = $onError;
            this.$this_copyToRecursively = $receiver;
            this.$target = $target;
            this.$normalizedTarget = $normalizedTarget;
         }

         public final FileVisitResult invoke(Path p0, Exception p1) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            Intrinsics.checkNotNullParameter(p1, "p1");
            return PathsKt__PathRecursiveFunctionsKt.copyToRecursively$error$PathsKt__PathRecursiveFunctionsKt(this.$onError, this.$this_copyToRecursively, this.$target, this.$normalizedTarget, p0, p1);
         }
      });
      $this$visitFileTree.onPostVisitDirectory(PathsKt__PathRecursiveFunctionsKt::copyToRecursively$lambda$3$1$PathsKt__PathRecursiveFunctionsKt);
      return Unit.INSTANCE;
   }

   private static final FileVisitResult copyToRecursively$lambda$3$0$PathsKt__PathRecursiveFunctionsKt(ArrayList $stack, Function3 $copyAction, Path $this_copyToRecursively, Path $target, Path $normalizedTarget, Function3 $onError, Path directory, BasicFileAttributes attributes) {
      Intrinsics.checkNotNullParameter(directory, "directory");
      Intrinsics.checkNotNullParameter(attributes, "attributes");
      FileVisitResult it = copyToRecursively$copy$PathsKt__PathRecursiveFunctionsKt($stack, $copyAction, $this_copyToRecursively, $target, $normalizedTarget, $onError, directory, attributes);
      int var10 = 0;
      if (it == FileVisitResult.CONTINUE) {
         $stack.add(directory);
      }

      return it;
   }

   private static final FileVisitResult copyToRecursively$lambda$3$1$PathsKt__PathRecursiveFunctionsKt(ArrayList $stack, Function3 $onError, Path $this_copyToRecursively, Path $target, Path $normalizedTarget, Path directory, IOException exception) {
      Intrinsics.checkNotNullParameter(directory, "directory");
      CollectionsKt.removeLast((List)$stack);
      return exception == null ? FileVisitResult.CONTINUE : copyToRecursively$error$PathsKt__PathRecursiveFunctionsKt($onError, $this_copyToRecursively, $target, $normalizedTarget, directory, (Exception)exception);
   }

   public PathsKt__PathRecursiveFunctionsKt() {
   }

   // $FF: synthetic class
   @Metadata(
      mv = {2, 2, 0},
      k = 3,
      xi = 48
   )
   public static final class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$1;

      static {
         int[] var0 = new int[CopyActionResult.values().length];

         try {
            var0[CopyActionResult.CONTINUE.ordinal()] = 1;
         } catch (NoSuchFieldError var6) {
         }

         try {
            var0[CopyActionResult.TERMINATE.ordinal()] = 2;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[CopyActionResult.SKIP_SUBTREE.ordinal()] = 3;
         } catch (NoSuchFieldError var4) {
         }

         $EnumSwitchMapping$0 = var0;
         var0 = new int[OnErrorResult.values().length];

         try {
            var0[OnErrorResult.TERMINATE.ordinal()] = 1;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[OnErrorResult.SKIP_SUBTREE.ordinal()] = 2;
         } catch (NoSuchFieldError var2) {
         }

         $EnumSwitchMapping$1 = var0;
      }
   }
}
