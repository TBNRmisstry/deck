package kotlin.io.path;

import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.Arrays;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\bÃ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001c\u0010\u0004\u001a\u00020\u0005*\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\tH\u0016¨\u0006\n"},
   d2 = {"Lkotlin/io/path/DefaultCopyActionContext;", "Lkotlin/io/path/CopyActionContext;", "<init>", "()V", "copyToIgnoringExistingDirectory", "Lkotlin/io/path/CopyActionResult;", "Ljava/nio/file/Path;", "target", "followLinks", "", "kotlin-stdlib-jdk7"}
)
@ExperimentalPathApi
final class DefaultCopyActionContext implements CopyActionContext {
   @NotNull
   public static final DefaultCopyActionContext INSTANCE = new DefaultCopyActionContext();

   private DefaultCopyActionContext() {
   }

   @NotNull
   public CopyActionResult copyToIgnoringExistingDirectory(@NotNull Path $this$copyToIgnoringExistingDirectory, @NotNull Path target, boolean followLinks) {
      Intrinsics.checkNotNullParameter($this$copyToIgnoringExistingDirectory, "<this>");
      Intrinsics.checkNotNullParameter(target, "target");
      LinkOption[] options = LinkFollowing.INSTANCE.toLinkOptions(followLinks);
      LinkOption[] var10001 = (LinkOption[])Arrays.copyOf(options, options.length);
      if (Files.isDirectory($this$copyToIgnoringExistingDirectory, (LinkOption[])Arrays.copyOf(var10001, var10001.length))) {
         LinkOption[] var6 = new LinkOption[]{LinkOption.NOFOLLOW_LINKS};
         if (Files.isDirectory(target, (LinkOption[])Arrays.copyOf(var6, var6.length))) {
            Unit var10000 = Unit.INSTANCE;
            return CopyActionResult.CONTINUE;
         }
      }

      CopyOption[] var10002 = (CopyOption[])Arrays.copyOf(options, options.length);
      Intrinsics.checkNotNullExpressionValue(Files.copy($this$copyToIgnoringExistingDirectory, target, (CopyOption[])Arrays.copyOf(var10002, var10002.length)), "copy(...)");
      return CopyActionResult.CONTINUE;
   }
}
