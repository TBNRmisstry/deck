package kotlin.io.path;

import java.nio.file.FileSystemLoopException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.ArrayDeque;
import kotlin.collections.ArraysKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.sequences.Sequence;
import kotlin.sequences.SequenceScope;
import kotlin.sequences.SequencesKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010(\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\b\u0004\b\u0000\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u001f\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u000e\u0010\u0004\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00060\u0005¢\u0006\u0004\b\u0007\u0010\bJ\u000f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00020\u0016H\u0096\u0002JB\u0010\u0017\u001a\u00020\u0018*\b\u0012\u0004\u0012\u00020\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001d2\u0018\u0010\u001e\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001b0 \u0012\u0004\u0012\u00020\u00180\u001fH\u0082H¢\u0006\u0002\u0010!J\u000e\u0010\"\u001a\b\u0012\u0004\u0012\u00020\u00020\u0016H\u0002J\u000e\u0010#\u001a\b\u0012\u0004\u0012\u00020\u00020\u0016H\u0002R\u000e\u0010\u0003\u001a\u00020\u0002X\u0082\u0004¢\u0006\u0002\n\u0000R\u0018\u0010\u0004\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\tR\u0014\u0010\n\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\f\u0010\rR\u001a\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u000f0\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0010\u0010\u0011R\u0014\u0010\u0012\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0013\u0010\rR\u0014\u0010\u0014\u001a\u00020\u000b8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0014\u0010\r¨\u0006$"},
   d2 = {"Lkotlin/io/path/PathTreeWalk;", "Lkotlin/sequences/Sequence;", "Ljava/nio/file/Path;", "start", "options", "", "Lkotlin/io/path/PathWalkOption;", "<init>", "(Ljava/nio/file/Path;[Lkotlin/io/path/PathWalkOption;)V", "[Lkotlin/io/path/PathWalkOption;", "followLinks", "", "getFollowLinks", "()Z", "linkOptions", "Ljava/nio/file/LinkOption;", "getLinkOptions", "()[Ljava/nio/file/LinkOption;", "includeDirectories", "getIncludeDirectories", "isBFS", "iterator", "", "yieldIfNeeded", "", "Lkotlin/sequences/SequenceScope;", "node", "Lkotlin/io/path/PathNode;", "entriesReader", "Lkotlin/io/path/DirectoryEntriesReader;", "entriesAction", "Lkotlin/Function1;", "", "(Lkotlin/sequences/SequenceScope;Lkotlin/io/path/PathNode;Lkotlin/io/path/DirectoryEntriesReader;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "dfsIterator", "bfsIterator", "kotlin-stdlib-jdk7"}
)
public final class PathTreeWalk implements Sequence<Path> {
   @NotNull
   private final Path start;
   @NotNull
   private final PathWalkOption[] options;

   public PathTreeWalk(@NotNull Path start, @NotNull PathWalkOption[] options) {
      Intrinsics.checkNotNullParameter(start, "start");
      Intrinsics.checkNotNullParameter(options, "options");
      super();
      this.start = start;
      this.options = options;
   }

   private final boolean getFollowLinks() {
      return ArraysKt.contains(this.options, PathWalkOption.FOLLOW_LINKS);
   }

   private final LinkOption[] getLinkOptions() {
      return LinkFollowing.INSTANCE.toLinkOptions(this.getFollowLinks());
   }

   private final boolean getIncludeDirectories() {
      return ArraysKt.contains(this.options, PathWalkOption.INCLUDE_DIRECTORIES);
   }

   private final boolean isBFS() {
      return ArraysKt.contains(this.options, PathWalkOption.BREADTH_FIRST);
   }

   @NotNull
   public Iterator<Path> iterator() {
      return this.isBFS() ? this.bfsIterator() : this.dfsIterator();
   }

   private final Object yieldIfNeeded(SequenceScope<? super Path> $this$yieldIfNeeded, PathNode node, DirectoryEntriesReader entriesReader, Function1<? super List<PathNode>, Unit> entriesAction, Continuation<? super Unit> $completion) {
      int $i$f$yieldIfNeeded = 0;
      Path path = node.getPath();
      if (node.getParent() != null) {
         PathsKt.checkFileName(path);
      }

      LinkOption[] var9 = access$getLinkOptions(this);
      var9 = (LinkOption[])Arrays.copyOf(var9, var9.length);
      if (Files.isDirectory(path, (LinkOption[])Arrays.copyOf(var9, var9.length))) {
         if (PathTreeWalkKt.access$createsCycle(node)) {
            throw new FileSystemLoopException(path.toString());
         }

         if (access$getIncludeDirectories(this)) {
            InlineMarker.mark(0);
            $this$yieldIfNeeded.yield(path, $completion);
            InlineMarker.mark(1);
         }

         var9 = access$getLinkOptions(this);
         var9 = (LinkOption[])Arrays.copyOf(var9, var9.length);
         if (Files.isDirectory(path, (LinkOption[])Arrays.copyOf(var9, var9.length))) {
            entriesAction.invoke(entriesReader.readEntries(node));
         }
      } else {
         var9 = new LinkOption[]{LinkOption.NOFOLLOW_LINKS};
         if (Files.exists(path, (LinkOption[])Arrays.copyOf(var9, var9.length))) {
            InlineMarker.mark(0);
            $this$yieldIfNeeded.yield(path, $completion);
            InlineMarker.mark(1);
            return Unit.INSTANCE;
         }
      }

      return Unit.INSTANCE;
   }

   private final Iterator<Path> dfsIterator() {
      return SequencesKt.iterator(new Function2<SequenceScope<? super Path>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         Object L$2;
         Object L$3;
         Object L$4;
         Object L$5;
         Object L$6;
         Object L$7;
         Object L$8;
         Object L$9;
         Object L$10;
         Object L$11;
         int I$0;
         int label;
         // $FF: synthetic field
         private Object L$0;

         public final Object invokeSuspend(Object $result) {
            SequenceScope $this$iterator = (SequenceScope)this.L$0;
            Object var19 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            ArrayDeque stack;
            DirectoryEntriesReader entriesReader;
            PathNode startNode;
            switch (this.label) {
               case 0:
                  ResultKt.throwOnFailure($result);
                  stack = new ArrayDeque();
                  entriesReader = new DirectoryEntriesReader(PathTreeWalk.this.getFollowLinks());
                  startNode = new PathNode(PathTreeWalk.this.start, PathTreeWalkKt.access$keyOf(PathTreeWalk.this.start, PathTreeWalk.this.getLinkOptions()), (PathNode)null);
                  PathTreeWalk topNodex = PathTreeWalk.this;
                  int $i$f$yieldIfNeeded = 0;
                  Path path$iv = startNode.getPath();
                  if (startNode.getParent() != null) {
                     PathsKt.checkFileName(path$iv);
                  }

                  LinkOption[] var49 = topNodex.getLinkOptions();
                  var49 = (LinkOption[])Arrays.copyOf(var49, var49.length);
                  if (Files.isDirectory(path$iv, (LinkOption[])Arrays.copyOf(var49, var49.length))) {
                     if (PathTreeWalkKt.access$createsCycle(startNode)) {
                        throw new FileSystemLoopException(path$iv.toString());
                     }

                     if (topNodex.getIncludeDirectories()) {
                        Continuation var10002 = this;
                        this.L$0 = $this$iterator;
                        this.L$1 = stack;
                        this.L$2 = entriesReader;
                        this.L$3 = startNode;
                        this.L$4 = topNodex;
                        this.L$5 = SpillingKt.nullOutSpilledVariable($this$iterator);
                        this.L$6 = startNode;
                        this.L$7 = entriesReader;
                        this.L$8 = path$iv;
                        this.I$0 = $i$f$yieldIfNeeded;
                        this.label = 1;
                        if ($this$iterator.yield(path$iv, var10002) == var19) {
                           return var19;
                        }
                     }

                     var49 = topNodex.getLinkOptions();
                     var49 = (LinkOption[])Arrays.copyOf(var49, var49.length);
                     if (Files.isDirectory(path$iv, (LinkOption[])Arrays.copyOf(var49, var49.length))) {
                        List entries = entriesReader.readEntries(startNode);
                        int var59 = 0;
                        startNode.setContentIterator(entries.iterator());
                        stack.addLast(startNode);
                     }
                  } else {
                     var49 = new LinkOption[]{LinkOption.NOFOLLOW_LINKS};
                     if (Files.exists(path$iv, (LinkOption[])Arrays.copyOf(var49, var49.length))) {
                        Continuation var68 = this;
                        this.L$0 = $this$iterator;
                        this.L$1 = stack;
                        this.L$2 = entriesReader;
                        this.L$3 = SpillingKt.nullOutSpilledVariable(startNode);
                        this.L$4 = SpillingKt.nullOutSpilledVariable(topNodex);
                        this.L$5 = SpillingKt.nullOutSpilledVariable($this$iterator);
                        this.L$6 = SpillingKt.nullOutSpilledVariable(startNode);
                        this.L$7 = SpillingKt.nullOutSpilledVariable(entriesReader);
                        this.L$8 = SpillingKt.nullOutSpilledVariable(path$iv);
                        this.I$0 = $i$f$yieldIfNeeded;
                        this.label = 2;
                        if ($this$iterator.yield(path$iv, var68) == var19) {
                           return var19;
                        }
                     }
                  }
                  break;
               case 1:
                  int $i$f$yieldIfNeeded = this.I$0;
                  Path path$iv = (Path)this.L$8;
                  DirectoryEntriesReader entriesReader$iv = (DirectoryEntriesReader)this.L$7;
                  PathNode node$iv = (PathNode)this.L$6;
                  SequenceScope $this$yieldIfNeeded$iv = (SequenceScope)this.L$5;
                  PathTreeWalk this_$iv = (PathTreeWalk)this.L$4;
                  startNode = (PathNode)this.L$3;
                  entriesReader = (DirectoryEntriesReader)this.L$2;
                  stack = (ArrayDeque)this.L$1;
                  ResultKt.throwOnFailure($result);
                  LinkOption[] var47 = this_$iv.getLinkOptions();
                  var47 = (LinkOption[])Arrays.copyOf(var47, var47.length);
                  if (Files.isDirectory(path$iv, (LinkOption[])Arrays.copyOf(var47, var47.length))) {
                     List var56 = entriesReader$iv.readEntries(node$iv);
                     boolean var15 = false;
                     startNode.setContentIterator(var56.iterator());
                     stack.addLast(startNode);
                  }
                  break;
               case 2:
                  int $i$f$yieldIfNeeded = this.I$0;
                  Path path$iv = (Path)this.L$8;
                  DirectoryEntriesReader entriesReader$iv = (DirectoryEntriesReader)this.L$7;
                  PathNode node$iv = (PathNode)this.L$6;
                  SequenceScope $this$yieldIfNeeded$iv = (SequenceScope)this.L$5;
                  PathTreeWalk this_$iv = (PathTreeWalk)this.L$4;
                  startNode = (PathNode)this.L$3;
                  entriesReader = (DirectoryEntriesReader)this.L$2;
                  stack = (ArrayDeque)this.L$1;
                  ResultKt.throwOnFailure($result);
                  break;
               case 3:
                  int $i$f$yieldIfNeeded = this.I$0;
                  Path path$iv = (Path)this.L$11;
                  DirectoryEntriesReader entriesReader$iv = (DirectoryEntriesReader)this.L$10;
                  PathNode node$iv = (PathNode)this.L$9;
                  SequenceScope $this$yieldIfNeeded$iv = (SequenceScope)this.L$8;
                  PathTreeWalk this_$iv = (PathTreeWalk)this.L$7;
                  PathNode pathNode = (PathNode)this.L$6;
                  Iterator topIterator = (Iterator)this.L$5;
                  PathNode topNode = (PathNode)this.L$4;
                  startNode = (PathNode)this.L$3;
                  entriesReader = (DirectoryEntriesReader)this.L$2;
                  stack = (ArrayDeque)this.L$1;
                  ResultKt.throwOnFailure($result);
                  LinkOption[] var16 = this_$iv.getLinkOptions();
                  var16 = (LinkOption[])Arrays.copyOf(var16, var16.length);
                  if (Files.isDirectory(path$iv, (LinkOption[])Arrays.copyOf(var16, var16.length))) {
                     List entries = entriesReader$iv.readEntries(node$iv);
                     int var18 = 0;
                     pathNode.setContentIterator(entries.iterator());
                     stack.addLast(pathNode);
                  }
                  break;
               case 4:
                  int $i$f$yieldIfNeeded = this.I$0;
                  Path path$iv = (Path)this.L$11;
                  DirectoryEntriesReader entriesReader$iv = (DirectoryEntriesReader)this.L$10;
                  PathNode node$iv = (PathNode)this.L$9;
                  SequenceScope $this$yieldIfNeeded$iv = (SequenceScope)this.L$8;
                  PathTreeWalk this_$iv = (PathTreeWalk)this.L$7;
                  PathNode pathNode = (PathNode)this.L$6;
                  Iterator topIterator = (Iterator)this.L$5;
                  PathNode topNode = (PathNode)this.L$4;
                  startNode = (PathNode)this.L$3;
                  entriesReader = (DirectoryEntriesReader)this.L$2;
                  stack = (ArrayDeque)this.L$1;
                  ResultKt.throwOnFailure($result);
                  break;
               default:
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            while(!((Collection)stack).isEmpty()) {
               PathNode topNode = (PathNode)stack.last();
               Iterator var10000 = topNode.getContentIterator();
               Intrinsics.checkNotNull(var10000);
               Iterator topIterator = var10000;
               if (topIterator.hasNext()) {
                  PathNode pathNode = (PathNode)topIterator.next();
                  PathTreeWalk this_$ivxxxx = PathTreeWalk.this;
                  int $i$f$yieldIfNeeded = 0;
                  Path path$iv = pathNode.getPath();
                  if (pathNode.getParent() != null) {
                     PathsKt.checkFileName(path$iv);
                  }

                  LinkOption[] var61 = this_$ivxxxx.getLinkOptions();
                  var61 = (LinkOption[])Arrays.copyOf(var61, var61.length);
                  if (Files.isDirectory(path$iv, (LinkOption[])Arrays.copyOf(var61, var61.length))) {
                     if (PathTreeWalkKt.access$createsCycle(pathNode)) {
                        throw new FileSystemLoopException(path$iv.toString());
                     }

                     if (this_$ivxxxx.getIncludeDirectories()) {
                        Continuation var69 = this;
                        this.L$0 = $this$iterator;
                        this.L$1 = stack;
                        this.L$2 = entriesReader;
                        this.L$3 = SpillingKt.nullOutSpilledVariable(startNode);
                        this.L$4 = SpillingKt.nullOutSpilledVariable(topNode);
                        this.L$5 = SpillingKt.nullOutSpilledVariable(topIterator);
                        this.L$6 = pathNode;
                        this.L$7 = this_$ivxxxx;
                        this.L$8 = SpillingKt.nullOutSpilledVariable($this$iterator);
                        this.L$9 = pathNode;
                        this.L$10 = entriesReader;
                        this.L$11 = path$iv;
                        this.I$0 = $i$f$yieldIfNeeded;
                        this.label = 3;
                        if ($this$iterator.yield(path$iv, var69) == var19) {
                           return var19;
                        }
                     }

                     var61 = this_$ivxxxx.getLinkOptions();
                     var61 = (LinkOption[])Arrays.copyOf(var61, var61.length);
                     if (Files.isDirectory(path$iv, (LinkOption[])Arrays.copyOf(var61, var61.length))) {
                        List var66 = entriesReader.readEntries(pathNode);
                        boolean var67 = false;
                        pathNode.setContentIterator(var66.iterator());
                        stack.addLast(pathNode);
                     }
                  } else {
                     var61 = new LinkOption[]{LinkOption.NOFOLLOW_LINKS};
                     if (Files.exists(path$iv, (LinkOption[])Arrays.copyOf(var61, var61.length))) {
                        Continuation var70 = this;
                        this.L$0 = $this$iterator;
                        this.L$1 = stack;
                        this.L$2 = entriesReader;
                        this.L$3 = SpillingKt.nullOutSpilledVariable(startNode);
                        this.L$4 = SpillingKt.nullOutSpilledVariable(topNode);
                        this.L$5 = SpillingKt.nullOutSpilledVariable(topIterator);
                        this.L$6 = SpillingKt.nullOutSpilledVariable(pathNode);
                        this.L$7 = SpillingKt.nullOutSpilledVariable(this_$ivxxxx);
                        this.L$8 = SpillingKt.nullOutSpilledVariable($this$iterator);
                        this.L$9 = SpillingKt.nullOutSpilledVariable(pathNode);
                        this.L$10 = SpillingKt.nullOutSpilledVariable(entriesReader);
                        this.L$11 = SpillingKt.nullOutSpilledVariable(path$iv);
                        this.I$0 = $i$f$yieldIfNeeded;
                        this.label = 4;
                        if ($this$iterator.yield(path$iv, var70) == var19) {
                           return var19;
                        }
                     }
                  }
               } else {
                  stack.removeLast();
               }
            }

            return Unit.INSTANCE;
         }

         public final Continuation<Unit> create(Object value, Continuation<?> $completion) {
            Function2 var3 = new <anonymous constructor>($completion);
            var3.L$0 = value;
            return (Continuation)var3;
         }

         public final Object invoke(SequenceScope<? super Path> p1, Continuation<? super Unit> p2) {
            return ((<undefinedtype>)this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
         }
      });
   }

   private final Iterator<Path> bfsIterator() {
      return SequencesKt.iterator(new Function2<SequenceScope<? super Path>, Continuation<? super Unit>, Object>((Continuation)null) {
         Object L$1;
         Object L$2;
         Object L$3;
         Object L$4;
         Object L$5;
         Object L$6;
         Object L$7;
         Object L$8;
         int I$0;
         int label;
         // $FF: synthetic field
         private Object L$0;

         public final Object invokeSuspend(Object $result) {
            SequenceScope $this$iterator = (SequenceScope)this.L$0;
            Object var16 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            ArrayDeque queue;
            DirectoryEntriesReader entriesReader;
            switch (this.label) {
               case 0:
                  ResultKt.throwOnFailure($result);
                  queue = new ArrayDeque();
                  entriesReader = new DirectoryEntriesReader(PathTreeWalk.this.getFollowLinks());
                  queue.addLast(new PathNode(PathTreeWalk.this.start, PathTreeWalkKt.access$keyOf(PathTreeWalk.this.start, PathTreeWalk.this.getLinkOptions()), (PathNode)null));
                  break;
               case 1:
                  int $i$f$yieldIfNeeded = this.I$0;
                  Path path$iv = (Path)this.L$8;
                  DirectoryEntriesReader entriesReader$iv = (DirectoryEntriesReader)this.L$7;
                  PathNode node$iv = (PathNode)this.L$6;
                  SequenceScope $this$yieldIfNeeded$iv = (SequenceScope)this.L$5;
                  PathTreeWalk this_$iv = (PathTreeWalk)this.L$4;
                  PathNode pathNode = (PathNode)this.L$3;
                  entriesReader = (DirectoryEntriesReader)this.L$2;
                  queue = (ArrayDeque)this.L$1;
                  ResultKt.throwOnFailure($result);
                  LinkOption[] var13 = this_$iv.getLinkOptions();
                  var13 = (LinkOption[])Arrays.copyOf(var13, var13.length);
                  if (Files.isDirectory(path$iv, (LinkOption[])Arrays.copyOf(var13, var13.length))) {
                     List entries = entriesReader$iv.readEntries(node$iv);
                     int var15 = 0;
                     queue.addAll((Collection)entries);
                  }
                  break;
               case 2:
                  int $i$f$yieldIfNeeded = this.I$0;
                  Path path$iv = (Path)this.L$8;
                  DirectoryEntriesReader entriesReader$iv = (DirectoryEntriesReader)this.L$7;
                  PathNode node$iv = (PathNode)this.L$6;
                  SequenceScope $this$yieldIfNeeded$iv = (SequenceScope)this.L$5;
                  PathTreeWalk this_$iv = (PathTreeWalk)this.L$4;
                  PathNode pathNode = (PathNode)this.L$3;
                  entriesReader = (DirectoryEntriesReader)this.L$2;
                  queue = (ArrayDeque)this.L$1;
                  ResultKt.throwOnFailure($result);
                  break;
               default:
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            while(!((Collection)queue).isEmpty()) {
               PathNode pathNode = (PathNode)queue.removeFirst();
               PathTreeWalk this_$ivxx = PathTreeWalk.this;
               int $i$f$yieldIfNeeded = 0;
               Path path$iv = pathNode.getPath();
               if (pathNode.getParent() != null) {
                  PathsKt.checkFileName(path$iv);
               }

               LinkOption[] var29 = this_$ivxx.getLinkOptions();
               var29 = (LinkOption[])Arrays.copyOf(var29, var29.length);
               if (Files.isDirectory(path$iv, (LinkOption[])Arrays.copyOf(var29, var29.length))) {
                  if (PathTreeWalkKt.access$createsCycle(pathNode)) {
                     throw new FileSystemLoopException(path$iv.toString());
                  }

                  if (this_$ivxx.getIncludeDirectories()) {
                     Continuation var10002 = this;
                     this.L$0 = $this$iterator;
                     this.L$1 = queue;
                     this.L$2 = entriesReader;
                     this.L$3 = SpillingKt.nullOutSpilledVariable(pathNode);
                     this.L$4 = this_$ivxx;
                     this.L$5 = SpillingKt.nullOutSpilledVariable($this$iterator);
                     this.L$6 = pathNode;
                     this.L$7 = entriesReader;
                     this.L$8 = path$iv;
                     this.I$0 = $i$f$yieldIfNeeded;
                     this.label = 1;
                     if ($this$iterator.yield(path$iv, var10002) == var16) {
                        return var16;
                     }
                  }

                  var29 = this_$ivxx.getLinkOptions();
                  var29 = (LinkOption[])Arrays.copyOf(var29, var29.length);
                  if (Files.isDirectory(path$iv, (LinkOption[])Arrays.copyOf(var29, var29.length))) {
                     List var34 = entriesReader.readEntries(pathNode);
                     boolean var35 = false;
                     queue.addAll((Collection)var34);
                  }
               } else {
                  var29 = new LinkOption[]{LinkOption.NOFOLLOW_LINKS};
                  if (Files.exists(path$iv, (LinkOption[])Arrays.copyOf(var29, var29.length))) {
                     Continuation var36 = this;
                     this.L$0 = $this$iterator;
                     this.L$1 = queue;
                     this.L$2 = entriesReader;
                     this.L$3 = SpillingKt.nullOutSpilledVariable(pathNode);
                     this.L$4 = SpillingKt.nullOutSpilledVariable(this_$ivxx);
                     this.L$5 = SpillingKt.nullOutSpilledVariable($this$iterator);
                     this.L$6 = SpillingKt.nullOutSpilledVariable(pathNode);
                     this.L$7 = SpillingKt.nullOutSpilledVariable(entriesReader);
                     this.L$8 = SpillingKt.nullOutSpilledVariable(path$iv);
                     this.I$0 = $i$f$yieldIfNeeded;
                     this.label = 2;
                     if ($this$iterator.yield(path$iv, var36) == var16) {
                        return var16;
                     }
                  }
               }
            }

            return Unit.INSTANCE;
         }

         public final Continuation<Unit> create(Object value, Continuation<?> $completion) {
            Function2 var3 = new <anonymous constructor>($completion);
            var3.L$0 = value;
            return (Continuation)var3;
         }

         public final Object invoke(SequenceScope<? super Path> p1, Continuation<? super Unit> p2) {
            return ((<undefinedtype>)this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
         }
      });
   }
}
