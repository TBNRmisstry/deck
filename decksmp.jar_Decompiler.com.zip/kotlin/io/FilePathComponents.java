package kotlin.io;

import java.io.File;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 2, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0007\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u000e\b\u0080\b\u0018\u00002\u00020\u0001B\u001f\b\u0000\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u0016\u0010\u0017\u001a\u00020\u00032\u0006\u0010\u0018\u001a\u00020\u00142\u0006\u0010\u0019\u001a\u00020\u0014J\t\u0010\u001a\u001a\u00020\u0003HÆ\u0003J\u000f\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005HÆ\u0003J(\u0010\u001c\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\u000e\b\u0002\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005HÀ\u0001¢\u0006\u0002\b\u001dJ\u0013\u0010\u001e\u001a\u00020\u00112\b\u0010\u001f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010 \u001a\u00020\u0014HÖ\u0001J\t\u0010!\u001a\u00020\rHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\f\u001a\u00020\r8F¢\u0006\u0006\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0010\u001a\u00020\u00118F¢\u0006\u0006\u001a\u0004\b\u0010\u0010\u0012R\u0011\u0010\u0013\u001a\u00020\u00148F¢\u0006\u0006\u001a\u0004\b\u0015\u0010\u0016¨\u0006\""},
   d2 = {"Lkotlin/io/FilePathComponents;", "", "root", "Ljava/io/File;", "segments", "", "<init>", "(Ljava/io/File;Ljava/util/List;)V", "getRoot", "()Ljava/io/File;", "getSegments", "()Ljava/util/List;", "rootName", "", "getRootName", "()Ljava/lang/String;", "isRooted", "", "()Z", "size", "", "getSize", "()I", "subPath", "beginIndex", "endIndex", "component1", "component2", "copy", "copy$kotlin_stdlib", "equals", "other", "hashCode", "toString", "kotlin-stdlib"}
)
public final class FilePathComponents {
   @NotNull
   private final File root;
   @NotNull
   private final List<File> segments;

   public FilePathComponents(@NotNull File root, @NotNull List<? extends File> segments) {
      Intrinsics.checkNotNullParameter(root, "root");
      Intrinsics.checkNotNullParameter(segments, "segments");
      super();
      this.root = root;
      this.segments = segments;
   }

   @NotNull
   public final File getRoot() {
      return this.root;
   }

   @NotNull
   public final List<File> getSegments() {
      return this.segments;
   }

   @NotNull
   public final String getRootName() {
      String var10000 = this.root.getPath();
      Intrinsics.checkNotNullExpressionValue(var10000, "getPath(...)");
      return var10000;
   }

   public final boolean isRooted() {
      String var10000 = this.root.getPath();
      Intrinsics.checkNotNullExpressionValue(var10000, "getPath(...)");
      return ((CharSequence)var10000).length() > 0;
   }

   public final int getSize() {
      return this.segments.size();
   }

   @NotNull
   public final File subPath(int beginIndex, int endIndex) {
      if (beginIndex >= 0 && beginIndex <= endIndex && endIndex <= this.getSize()) {
         Iterable var10002 = (Iterable)this.segments.subList(beginIndex, endIndex);
         String var10003 = File.separator;
         Intrinsics.checkNotNullExpressionValue(var10003, "separator");
         return new File(CollectionsKt.joinToString$default(var10002, (CharSequence)var10003, (CharSequence)null, (CharSequence)null, 0, (CharSequence)null, (Function1)null, 62, (Object)null));
      } else {
         throw new IllegalArgumentException();
      }
   }

   @NotNull
   public final File component1() {
      return this.root;
   }

   @NotNull
   public final List<File> component2() {
      return this.segments;
   }

   @NotNull
   public final FilePathComponents copy$kotlin_stdlib(@NotNull File root, @NotNull List<? extends File> segments) {
      Intrinsics.checkNotNullParameter(root, "root");
      Intrinsics.checkNotNullParameter(segments, "segments");
      return new FilePathComponents(root, segments);
   }

   // $FF: synthetic method
   public static FilePathComponents copy$kotlin_stdlib$default(FilePathComponents var0, File var1, List var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = var0.root;
      }

      if ((var3 & 2) != 0) {
         var2 = var0.segments;
      }

      return var0.copy$kotlin_stdlib(var1, var2);
   }

   @NotNull
   public String toString() {
      return "FilePathComponents(root=" + this.root + ", segments=" + this.segments + ')';
   }

   public int hashCode() {
      int result = this.root.hashCode();
      result = result * 31 + this.segments.hashCode();
      return result;
   }

   public boolean equals(@Nullable Object other) {
      if (this == other) {
         return true;
      } else if (!(other instanceof FilePathComponents)) {
         return false;
      } else {
         FilePathComponents var2 = (FilePathComponents)other;
         if (!Intrinsics.areEqual((Object)this.root, (Object)var2.root)) {
            return false;
         } else {
            return Intrinsics.areEqual((Object)this.segments, (Object)var2.segments);
         }
      }
   }
}
