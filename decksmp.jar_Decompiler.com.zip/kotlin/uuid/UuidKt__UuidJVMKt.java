package kotlin.uuid;

import java.nio.BufferOverflowException;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 2, 0},
   k = 5,
   xi = 49,
   d1 = {"\u0000@\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a\b\u0010\u0000\u001a\u00020\u0001H\u0001\u001a\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0001H\u0001\u001a\u0014\u0010\u0005\u001a\u00020\u0006*\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0001\u001a,\u0010\n\u001a\u00020\u000b*\u00020\u00062\u0006\u0010\f\u001a\u00020\u00072\u0006\u0010\r\u001a\u00020\t2\u0006\u0010\u000e\u001a\u00020\t2\u0006\u0010\u000f\u001a\u00020\tH\u0001\u001a\u001c\u0010\u0010\u001a\u00020\u000b*\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u0011\u001a\u00020\u0006H\u0001\u001a\u0010\u0010\u0012\u001a\u00020\u00012\u0006\u0010\u0013\u001a\u00020\u0014H\u0001\u001a\u0010\u0010\u0015\u001a\u00020\u00012\u0006\u0010\u0016\u001a\u00020\u0014H\u0001\u001a\r\u0010\u0017\u001a\u00020\u0001*\u00020\u0018H\u0087\b\u001a\r\u0010\u0019\u001a\u00020\u0018*\u00020\u0001H\u0087\b\u001a\f\u0010\u001a\u001a\u00020\u0001*\u00020\u001bH\u0007\u001a\u0014\u0010\u001a\u001a\u00020\u0001*\u00020\u001b2\u0006\u0010\b\u001a\u00020\tH\u0007\u001a\u0014\u0010\u001c\u001a\u00020\u001b*\u00020\u001b2\u0006\u0010\u0004\u001a\u00020\u0001H\u0007\u001a\u001c\u0010\u001c\u001a\u00020\u001b*\u00020\u001b2\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u0004\u001a\u00020\u0001H\u0007\u001a\r\u0010\u001d\u001a\u00020\u0006*\u00020\u0006H\u0080\b¨\u0006\u001e"},
   d2 = {"secureRandomUuid", "Lkotlin/uuid/Uuid;", "serializedUuid", "", "uuid", "getLongAt", "", "", "index", "", "formatBytesInto", "", "dst", "dstOffset", "startIndex", "endIndex", "setLongAt", "value", "uuidParseHexDash", "hexDashString", "", "uuidParseHex", "hexString", "toKotlinUuid", "Ljava/util/UUID;", "toJavaUuid", "getUuid", "Ljava/nio/ByteBuffer;", "putUuid", "reverseBytes", "kotlin-stdlib"},
   xs = "kotlin/uuid/UuidKt"
)
@SourceDebugExtension({"SMAP\nUuidJVM.kt\nKotlin\n*S Kotlin\n*F\n+ 1 UuidJVM.kt\nkotlin/uuid/UuidKt__UuidJVMKt\n*L\n1#1,277:1\n277#1:278\n277#1:279\n277#1:280\n277#1:281\n277#1:282\n277#1:283\n277#1:284\n277#1:285\n*S KotlinDebug\n*F\n+ 1 UuidJVM.kt\nkotlin/uuid/UuidKt__UuidJVMKt\n*L\n139#1:278\n140#1:279\n184#1:280\n185#1:281\n224#1:282\n225#1:283\n271#1:284\n272#1:285\n*E\n"})
class UuidKt__UuidJVMKt {
   @ExperimentalUuidApi
   @NotNull
   public static final Uuid secureRandomUuid() {
      byte[] randomBytes = new byte[16];
      SecureRandomHolder.INSTANCE.getInstance().nextBytes(randomBytes);
      return UuidKt.uuidFromRandomBytes(randomBytes);
   }

   @ExperimentalUuidApi
   @NotNull
   public static final Object serializedUuid(@NotNull Uuid uuid) {
      Intrinsics.checkNotNullParameter(uuid, "uuid");
      return new UuidSerialized(uuid.getMostSignificantBits(), uuid.getLeastSignificantBits());
   }

   @ExperimentalUuidApi
   public static final long getLongAt(@NotNull byte[] $this$getLongAt, int index) {
      Intrinsics.checkNotNullParameter($this$getLongAt, "<this>");
      return UuidKt.getLongAtCommonImpl($this$getLongAt, index);
   }

   @ExperimentalUuidApi
   public static final void formatBytesInto(long $this$formatBytesInto, @NotNull byte[] dst, int dstOffset, int startIndex, int endIndex) {
      Intrinsics.checkNotNullParameter(dst, "dst");
      UuidKt.formatBytesIntoCommonImpl($this$formatBytesInto, dst, dstOffset, startIndex, endIndex);
   }

   @ExperimentalUuidApi
   public static final void setLongAt(@NotNull byte[] $this$setLongAt, int index, long value) {
      Intrinsics.checkNotNullParameter($this$setLongAt, "<this>");
      UuidKt.setLongAtCommonImpl($this$setLongAt, index, value);
   }

   @ExperimentalUuidApi
   @NotNull
   public static final Uuid uuidParseHexDash(@NotNull String hexDashString) {
      Intrinsics.checkNotNullParameter(hexDashString, "hexDashString");
      return UuidKt.uuidParseHexDashCommonImpl(hexDashString);
   }

   @ExperimentalUuidApi
   @NotNull
   public static final Uuid uuidParseHex(@NotNull String hexString) {
      Intrinsics.checkNotNullParameter(hexString, "hexString");
      return UuidKt.uuidParseHexCommonImpl(hexString);
   }

   @SinceKotlin(
      version = "2.0"
   )
   @ExperimentalUuidApi
   @NotNull
   public static final Uuid toKotlinUuid(@NotNull UUID $this$toKotlinUuid) {
      Intrinsics.checkNotNullParameter($this$toKotlinUuid, "<this>");
      int $i$f$toKotlinUuid = 0;
      return Uuid.Companion.fromLongs($this$toKotlinUuid.getMostSignificantBits(), $this$toKotlinUuid.getLeastSignificantBits());
   }

   @SinceKotlin(
      version = "2.0"
   )
   @ExperimentalUuidApi
   @NotNull
   public static final UUID toJavaUuid(@NotNull Uuid $this$toJavaUuid) {
      Intrinsics.checkNotNullParameter($this$toJavaUuid, "<this>");
      int $i$f$toJavaUuid = 0;
      long var10000 = $this$toJavaUuid.getMostSignificantBits();
      long leastSignificantBits = $this$toJavaUuid.getLeastSignificantBits();
      long mostSignificantBits = var10000;
      int var7 = 0;
      return new UUID(mostSignificantBits, leastSignificantBits);
   }

   @SinceKotlin(
      version = "2.0"
   )
   @ExperimentalUuidApi
   @NotNull
   public static final Uuid getUuid(@NotNull ByteBuffer $this$getUuid) {
      Intrinsics.checkNotNullParameter($this$getUuid, "<this>");
      if ($this$getUuid.position() + 15 >= $this$getUuid.limit()) {
         throw new BufferUnderflowException();
      } else {
         long msb = $this$getUuid.getLong();
         long lsb = $this$getUuid.getLong();
         if (Intrinsics.areEqual((Object)$this$getUuid.order(), (Object)ByteOrder.LITTLE_ENDIAN)) {
            int $i$f$reverseBytes = 0;
            msb = Long.reverseBytes(msb);
            $i$f$reverseBytes = 0;
            lsb = Long.reverseBytes(lsb);
         }

         return Uuid.Companion.fromLongs(msb, lsb);
      }
   }

   @SinceKotlin(
      version = "2.0"
   )
   @ExperimentalUuidApi
   @NotNull
   public static final Uuid getUuid(@NotNull ByteBuffer $this$getUuid, int index) {
      Intrinsics.checkNotNullParameter($this$getUuid, "<this>");
      if (index < 0) {
         throw new IndexOutOfBoundsException("Negative index: " + index);
      } else if (index + 15 >= $this$getUuid.limit()) {
         throw new IndexOutOfBoundsException("Not enough bytes to read a uuid at index: " + index + ", with limit: " + $this$getUuid.limit() + ' ');
      } else {
         long msb = $this$getUuid.getLong(index);
         long lsb = $this$getUuid.getLong(index + 8);
         if (Intrinsics.areEqual((Object)$this$getUuid.order(), (Object)ByteOrder.LITTLE_ENDIAN)) {
            int $i$f$reverseBytes = 0;
            msb = Long.reverseBytes(msb);
            $i$f$reverseBytes = 0;
            lsb = Long.reverseBytes(lsb);
         }

         return Uuid.Companion.fromLongs(msb, lsb);
      }
   }

   @SinceKotlin(
      version = "2.0"
   )
   @ExperimentalUuidApi
   @NotNull
   public static final ByteBuffer putUuid(@NotNull ByteBuffer $this$putUuid, @NotNull Uuid uuid) {
      Intrinsics.checkNotNullParameter($this$putUuid, "<this>");
      Intrinsics.checkNotNullParameter(uuid, "uuid");
      long var10000 = uuid.getMostSignificantBits();
      long lsb = uuid.getLeastSignificantBits();
      long msb = var10000;
      int var7 = 0;
      if ($this$putUuid.position() + 15 >= $this$putUuid.limit()) {
         throw new BufferOverflowException();
      } else {
         ByteBuffer var12;
         if (Intrinsics.areEqual((Object)$this$putUuid.order(), (Object)ByteOrder.BIG_ENDIAN)) {
            $this$putUuid.putLong(msb);
            var12 = $this$putUuid.putLong(lsb);
         } else {
            int $i$f$reverseBytes = 0;
            $this$putUuid.putLong(Long.reverseBytes(msb));
            $i$f$reverseBytes = 0;
            var12 = $this$putUuid.putLong(Long.reverseBytes(lsb));
         }

         Intrinsics.checkNotNullExpressionValue(var12, "toLongs(...)");
         return var12;
      }
   }

   @SinceKotlin(
      version = "2.0"
   )
   @ExperimentalUuidApi
   @NotNull
   public static final ByteBuffer putUuid(@NotNull ByteBuffer $this$putUuid, int index, @NotNull Uuid uuid) {
      Intrinsics.checkNotNullParameter($this$putUuid, "<this>");
      Intrinsics.checkNotNullParameter(uuid, "uuid");
      long var10000 = uuid.getMostSignificantBits();
      long lsb = uuid.getLeastSignificantBits();
      long msb = var10000;
      int var8 = 0;
      if (index < 0) {
         throw new IndexOutOfBoundsException("Negative index: " + index);
      } else if (index + 15 >= $this$putUuid.limit()) {
         throw new IndexOutOfBoundsException("Not enough capacity to write a uuid at index: " + index + ", with limit: " + $this$putUuid.limit() + ' ');
      } else {
         ByteBuffer var13;
         if (Intrinsics.areEqual((Object)$this$putUuid.order(), (Object)ByteOrder.BIG_ENDIAN)) {
            $this$putUuid.putLong(index, msb);
            var13 = $this$putUuid.putLong(index + 8, lsb);
         } else {
            int $i$f$reverseBytes = 0;
            $this$putUuid.putLong(index, Long.reverseBytes(msb));
            int var10001 = index + 8;
            $i$f$reverseBytes = 0;
            var13 = $this$putUuid.putLong(var10001, Long.reverseBytes(lsb));
         }

         Intrinsics.checkNotNullExpressionValue(var13, "toLongs(...)");
         return var13;
      }
   }

   public static final long reverseBytes(long $this$reverseBytes) {
      int $i$f$reverseBytes = 0;
      return Long.reverseBytes($this$reverseBytes);
   }

   public UuidKt__UuidJVMKt() {
   }
}
