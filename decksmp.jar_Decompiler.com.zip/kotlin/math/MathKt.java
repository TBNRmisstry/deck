package kotlin.math;

import kotlin.Metadata;

@Metadata(
   mv = {2, 2, 0},
   k = 4,
   xi = 49,
   d1 = {"kotlin/math/MathKt__MathHKt", "kotlin/math/MathKt__MathJVMKt"}
)
public final class MathKt extends MathKt__MathJVMKt {
   public static final double PI = Math.PI;
   public static final double E = Math.E;

   private MathKt() {
   }
}
