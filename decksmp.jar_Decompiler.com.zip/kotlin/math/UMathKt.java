package kotlin.math;

import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.comparisons.UComparisonsKt;
import kotlin.internal.InlineOnly;

@Metadata(
   mv = {2, 2, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\u001a \u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0001H\u0087\b¢\u0006\u0004\b\u0004\u0010\u0005\u001a \u0010\u0000\u001a\u00020\u00062\u0006\u0010\u0002\u001a\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u0006H\u0087\b¢\u0006\u0004\b\u0007\u0010\b\u001a \u0010\t\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0001H\u0087\b¢\u0006\u0004\b\n\u0010\u0005\u001a \u0010\t\u001a\u00020\u00062\u0006\u0010\u0002\u001a\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u0006H\u0087\b¢\u0006\u0004\b\u000b\u0010\b¨\u0006\f"},
   d2 = {"min", "Lkotlin/UInt;", "a", "b", "min-J1ME1BU", "(II)I", "Lkotlin/ULong;", "min-eb3DHEI", "(JJ)J", "max", "max-J1ME1BU", "max-eb3DHEI", "kotlin-stdlib"}
)
public final class UMathKt {
   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final int min_J1ME1BU/* $FF was: min-J1ME1BU*/(int var0, int var1) {
      return UComparisonsKt.minOf-J1ME1BU(var0, var1);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final long min_eb3DHEI/* $FF was: min-eb3DHEI*/(long var0, long var2) {
      return UComparisonsKt.minOf-eb3DHEI(var0, var2);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final int max_J1ME1BU/* $FF was: max-J1ME1BU*/(int var0, int var1) {
      return UComparisonsKt.maxOf-J1ME1BU(var0, var1);
   }

   @SinceKotlin(
      version = "1.5"
   )
   @InlineOnly
   private static final long max_eb3DHEI/* $FF was: max-eb3DHEI*/(long var0, long var2) {
      return UComparisonsKt.maxOf-eb3DHEI(var0, var2);
   }
}
