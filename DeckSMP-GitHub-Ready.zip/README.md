# DeckSMP

Cleaned, GitHub-ready source project for the DeckSMP Minecraft plugin.

## Project structure

- `src/main/java/me/deck/decksmp/` — DeckSMP Java source
- `src/main/resources/` — plugin resources and `plugin.yml`
- `build.gradle` — Gradle build configuration
- `settings.gradle` — Gradle project settings

## Build

Install JDK 21 and run:

```bash
./gradlew build
```

On Windows:

```bat
gradlew.bat build
```

The built plugin will be in:

```text
build/libs/
```

## Important

This project was reconstructed from decompiled plugin files. Decompiled code can contain missing metadata, imperfect generics, synthetic classes, or dependencies that were originally supplied by the server/plugin environment. Treat the first build as a reconstruction that may need compilation fixes.
